from dataclasses import dataclass, field
from typing import Optional

@dataclass
class SipMessage:
    ts: float
    call_id: str
    method: str = ""
    status: Optional[int] = None
    cseq_method: str = ""
    cseq: str = ""
    src: str = ""
    dst: str = ""
    src_port: str = ""
    dst_port: str = ""
    from_uri: str = ""
    to_uri: str = ""
    user_agent: str = ""
    reason: str = ""
    branch: str = ""
    frame: str = ""
    request_line: str = ""

@dataclass
class RtpPacket:
    ts: float
    ssrc: str
    seq: Optional[int]
    rtp_ts: Optional[int]
    payload_type: str
    src: str
    dst: str
    src_port: str
    dst_port: str
    frame: str = ""
    size: Optional[int] = None

@dataclass
class Call:
    call_id: str
    messages: list[SipMessage] = field(default_factory=list)
    rtp: list[RtpPacket] = field(default_factory=list)
    sdp: list[dict] = field(default_factory=list)
    metrics: dict = field(default_factory=dict)
    anomalies: list[dict] = field(default_factory=list)
