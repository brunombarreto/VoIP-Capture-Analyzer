# Copyright (c) 2026 Bruno Barreto
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

import math
import statistics
from collections import Counter, defaultdict
from pathlib import Path
from app.services import tshark_media,  tshark
from app.services import pcap_fallback
import logging
from app.services import tshark_media

logger = logging.getLogger(__name__)
from .models import Call, SipMessage, RtpPacket

SIP_FIELDS = [
    "frame.number", "frame.time_epoch", "ip.src", "ipv6.src", "ip.dst", "ipv6.dst",
    "udp.srcport", "udp.dstport", "tcp.srcport", "tcp.dstport", "sip.Call-ID",
    "sip.Method", "sip.Status-Code", "sip.CSeq.seq", "sip.CSeq.method", "sip.from.uri",
    "sip.to.uri", "sip.User-Agent", "sip.Server", "sip.Reason", "sip.Via.branch",
    "sip.request_line", "sip.Status-Line", "sip.CSeq", "sip.From", "sip.To",
    "sip.Via", "sip.Contact", "sip.msg_hdr", "sip.msg_body",
]
RTP_FIELDS = [
    "frame.number", "frame.time_epoch", "ip.src", "ipv6.src", "ip.dst", "ipv6.dst",
    "udp.srcport", "udp.dstport", "frame.len", "rtp.ssrc", "rtp.seq", "rtp.timestamp", "rtp.p_type",
]
SDP_FIELDS = [
    "frame.number", "frame.time_epoch", "sip.Call-ID", "sdp.connection_info.address",
    "sdp.media.port", "sdp.media.type", "sdp.media.format",
    "sdp.media.format_specific_parameter", "sdp.media.attributes", "sdp.owner.address",
]
RTCP_FIELDS = [
    "frame.number", "frame.time_epoch", "ip.src", "ipv6.src", "ip.dst", "ipv6.dst",
    "udp.srcport", "udp.dstport", "rtcp.ssrc", "rtcp.cumulative.lost",
    "rtcp.fraction.lost", "rtcp.jitter", "rtcp.rtt",
]

PAYLOAD_CLOCK = {"0": 8000, "3": 8000, "4": 8000, "8": 8000, "9": 8000, "13": 8000, "18": 8000, "96": 48000}


def ffloat(v, default=None):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def fint(v, default=None):
    try:
        return int(v, 0) if isinstance(v, str) and v.lower().startswith("0x") else int(v)
    except (TypeError, ValueError):
        return default


def ip(row, key):
    return row.get(f"ip.{key}") or row.get(f"ipv6.{key}") or ""


def port(row, key):
    return row.get(f"udp.{key}port") or row.get(f"tcp.{key}port") or ""


def percentile(values, p):
    vals = sorted(v for v in values if v is not None)
    if not vals:
        return None
    if len(vals) == 1:
        return vals[0]
    k = (len(vals) - 1) * p / 100
    lo, hi = math.floor(k), math.ceil(k)
    return vals[lo] if lo == hi else vals[lo] + (vals[hi] - vals[lo]) * (k - lo)


class CaptureAnalyzer:
    def __init__(self, progress_cb=None):
        self.progress_cb = progress_cb

    async def progress(self, pct, stage, message):
        if self.progress_cb:
            await self.progress_cb(pct, stage, message)

    async def analyze(self, capture: Path) -> dict:
        await self.progress(4, "metadata", "Lendo metadados e volumetria da captura...")
        info = await tshark.capture_info(capture)
        info["protocol_inventory"] = await tshark.protocol_inventory(capture)
        await self.progress(12, "sip", "Extraindo sinalização SIP e transações...")
        sip_rows = await tshark.fields(capture, "sip", SIP_FIELDS, occurrence="a")
        # TShark remains the primary decoder.  Some captures, however, contain valid SIP
        # on UDP/5060 while the dissector/field export returns no usable rows.  In that
        # situation use the conservative pure-Python PCAP fallback instead of declaring
        # the capture to contain zero calls.
        if not sip_rows:
            sip_rows = await tshark.fields(capture, "sip", [
                "frame.number", "frame.time_epoch", "ip.src", "ipv6.src", "ip.dst", "ipv6.dst",
                "udp.srcport", "udp.dstport", "tcp.srcport", "tcp.dstport",
                "sip.Call-ID", "sip.Method", "sip.Status-Code", "sip.Status-Line", "sip.CSeq",
                "sip.From", "sip.To", "sip.Via", "sip.Contact", "sip.User-Agent", "sip.Server",
                "sip.Reason", "sip.msg_hdr", "sip.msg_body", "sip.request_line"
            ], occurrence="a")
        if not sip_rows:
            # First fallback: ask TShark for its complete JSON representation.
            # This works with pcapng, SLL/SLL2, VLANs and other link-layer types
            # that a small hand-written classic-PCAP parser cannot safely decode.
            try:
                json_rows = await tshark.json_packets(capture, "sip")
                if json_rows:
                    sip_rows = json_rows
                    logger.info("SIP recovered from TShark JSON: %d packets", len(sip_rows))
            except Exception as exc:
                logger.warning("TShark JSON SIP fallback failed: %s", exc)

        if not sip_rows:
            # Second fallback: extract UDP payloads through TShark and parse SIP
            # ourselves. This remains fully compatible with PCAPNG and unusual
            # link-layer types because TShark handles the packet framing.
            try:
                udp_rows = await tshark.raw_udp_payloads(capture, "udp.port==5060 || tcp.port==5060")
                sip_rows = pcap_fallback.extract_sip_from_tshark_udp_rows(udp_rows)
                if sip_rows:
                    logger.info("SIP recovered from TShark UDP payloads: %d packets", len(sip_rows))
            except Exception as exc:
                logger.warning("TShark UDP payload SIP fallback failed: %s", exc)

        if not sip_rows:
            # Last-resort compatibility parser. It is intentionally conservative
            # and only handles selected classic PCAP link layers.
            try:
                sip_rows = pcap_fallback.extract_sip(capture)
                info["protocol_inventory"] = pcap_fallback.inventory(capture)
            except Exception as exc:
                logger.warning("Pure-Python SIP fallback failed: %s", exc)
                info.setdefault("analysis_warnings", []).append(
                    f"Não foi possível reconstruir SIP pelo fallback: {exc}"
                )
        elif not any(r.get("sip.Call-ID") for r in sip_rows):
            try:
                raw_rows = pcap_fallback.extract_sip(capture)
                if raw_rows:
                    sip_rows = raw_rows
            except Exception as exc:
                logger.debug("Raw SIP fallback skipped: %s", exc)
        await self.progress(26, "sdp", "Extraindo SDP, codecs e endereços de mídia...")
        sdp_rows = await tshark.fields(capture, "sdp", SDP_FIELDS, occurrence="a")

        # Always keep a TShark-framed SIP/SDP recovery path. This is important for
        # captures where the SIP dissector exposes Call-ID but does not export all
        # multipart SDP fields through -T fields. TShark still handles the PCAP
        # container; Python only parses the already extracted UDP payload.
        media_sip_rows = list(sip_rows)
        try:
            sip_udp_rows = await tshark.raw_udp_payloads(capture, "udp.port==5060 || udp.port==5061")
            recovered_sip = pcap_fallback.extract_sip_from_tshark_udp_rows(sip_udp_rows)
            if recovered_sip:
                # Merge rather than replace: TShark's SIP dissector may have richer
                # headers while the payload parser preserves complete SDP bodies.
                media_sip_rows = recovered_sip
                if not sdp_rows:
                    logger.info("SDP recovered from TShark SIP UDP payloads: %d SIP packets", len(recovered_sip))
        except Exception as exc:
            logger.warning("TShark SIP payload recovery failed: %s", exc)

        if not sdp_rows:
            sdp_rows = self._sdp_rows_from_raw_sip(media_sip_rows)
        else:
            # Supplement the TShark SDP rows with raw-SIP SDP declarations when the
            # field exporter returned only partial media information.
            raw_sdp = self._sdp_rows_from_raw_sip(media_sip_rows)
            seen = {(r.get("sip.Call-ID"), r.get("sdp.media.port"), r.get("frame.number")) for r in sdp_rows}
            for row in raw_sdp:
                key = (row.get("sip.Call-ID"), row.get("sdp.media.port"), row.get("frame.number"))
                if key not in seen:
                    sdp_rows.append(row)

        await self.progress(42, "rtp", "Extraindo RTP com Decode-As nas portas negociadas...")
        rtp_rows = await tshark.fields(capture, "rtp", RTP_FIELDS, occurrence="a")
        await self.progress(50, "rtp_decode", "Aplicando Decode-As RTP/RTCP às portas de mídia do SDP...")

        # Dynamic RTP payloads are not guaranteed to be heuristically dissected by
        # TShark. Derive every negotiated audio port and explicitly Decode-As RTP.
        # This mirrors the practical Wireshark workflow while keeping the processing
        # fully automated and reproducible.
        media_ports = pcap_fallback.media_ports_from_sdp_rows(sdp_rows)
        if not media_ports:
            media_ports = pcap_fallback.media_ports_from_sip_rows(media_sip_rows)
        if not rtp_rows and media_ports:
            decode_rtp = [(p, "rtp") for p in sorted(media_ports)]
            try:
                rtp_rows = await tshark.fields_decode_as(capture, "rtp", RTP_FIELDS, decode_rtp, occurrence="a")
                if rtp_rows:
                    logger.info("RTP recovered by TShark Decode-As: %d packets ports=%s", len(rtp_rows), sorted(media_ports))
            except Exception as exc:
                logger.warning("TShark Decode-As RTP failed: %s", exc)

        await self.progress(58, "rtcp", "Extraindo relatórios RTCP e estatísticas nativas do TShark...")
        try:
            rtcp_rows = await tshark.fields(capture, "rtcp", RTCP_FIELDS, occurrence="a")
        except tshark.TSharkError:
            rtcp_rows = []
        if not rtcp_rows and media_ports:
            # Conventional RTP/RTCP pairs use RTP+1 for RTCP. Decode those ports
            # explicitly; the filter also prevents unrelated UDP traffic from being
            # classified as RTCP.
            decode_rtcp = [(p + 1, "rtcp") for p in sorted(media_ports) if p < 65535]
            try:
                rtcp_rows = await tshark.fields_decode_as(capture, "rtcp", RTCP_FIELDS, decode_rtcp, occurrence="a")
            except Exception as exc:
                logger.warning("TShark Decode-As RTCP failed: %s", exc)

        # Packet-level TShark UDP fallback remains the final media decoder. It is
        # not a PCAP parser: TShark has already framed and decoded the UDP packets.
        if (not rtp_rows or not rtcp_rows) and media_ports:
            try:
                media_filter = " || ".join(
                    f"udp.port=={p}" for p in sorted(media_ports | {p + 1 for p in media_ports if p < 65535})
                )
                udp_media_rows = await tshark.raw_udp_payloads(capture, media_filter)
                raw_rtp, raw_rtcp = pcap_fallback.parse_rtp_from_tshark_udp_rows(udp_media_rows, media_ports)
                if not rtp_rows:
                    rtp_rows = raw_rtp
                if not rtcp_rows:
                    rtcp_rows = raw_rtcp
                logger.info("Media recovered from TShark UDP payloads: RTP=%d RTCP=%d ports=%s", len(raw_rtp), len(raw_rtcp), sorted(media_ports))
            except Exception as exc:
                logger.warning("TShark UDP media fallback failed: %s", exc)

        # Native TShark stream statistics are kept as supplementary evidence.
        # They are especially useful when a stream was decoded by Wireshark's RTP
        # dissector but packet-field extraction is sparse.
        rtp_stats_text = ""
        try:
            rtp_stats_text = await tshark.rtp_stream_stats(capture, [(p, "rtp") for p in sorted(media_ports)]) if media_ports else await tshark.rtp_stream_stats(capture)
        except Exception as exc:
            logger.debug("TShark RTP stream statistics unavailable: %s", exc)
        info["rtp_tshark_stats"] = rtp_stats_text[-20000:] if rtp_stats_text else ""

        # Do not invoke the legacy physical-PCAP parser here. TShark has already
        # provided the packet framing required by all supported capture formats.
        await self.progress(68, "correlation", "Correlacionando SIP, SDP, RTP e RTCP e consolidando pernas B2BUA...")
        calls = self._build_calls(sip_rows, sdp_rows, rtp_rows)
        calls = self._merge_logical_legs(calls)
        assigned_rtp = sum(len(c.rtp) for c in calls.values())
        info["extraction"] = {
            "sip_rows": len(sip_rows), "sdp_rows": len(sdp_rows), "rtp_rows": len(rtp_rows), "rtcp_rows": len(rtcp_rows),
            "sip_reconstruction": bool(calls),
            "rtp_unassociated_packets": max(0, len(rtp_rows) - assigned_rtp),
            "sip_source": "tshark" if any(r.get("__raw_source") is None for r in sip_rows) else (sip_rows[0].get("__raw_source") if sip_rows else "none"),
            "media_source": "tshark" if any(r.get("__raw_source") is None for r in rtp_rows) else (rtp_rows[0].get("__raw_source") if rtp_rows else "none"),
        }
        self._attach_rtcp(calls, rtcp_rows)
        await self.progress(78, "metrics", "Calculando KPIs macro e métricas por chamada...")
        for call in calls.values():
            self._metrics(call)
            if not call.leg_details:
                call.leg_details = [self._leg_detail(call)]
            call.metrics["legs"] = call.leg_details
        macro = self._macro(info, calls, rtcp_rows)
        await self.progress(86, "diagnosis", "Aplicando regras de qualidade e diagnóstico...")
        self._diagnose(calls, macro)
        for call in calls.values():
            self._apply_call_state_and_score(call)
        macro["call_score_avg"] = statistics.mean([c.metrics["anomaly_score"] for c in calls.values()]) if calls else None
        macro["call_score_p95"] = percentile([c.metrics["anomaly_score"] for c in calls.values()], 95) if calls else None
        await self.progress(92, "finalize", "Consolidando evidências, severidade, confiança e estado das chamadas...")
        return {
            "capture": info,
            "macro": macro,
            "calls": [self._call_dict(c) for c in sorted(calls.values(), key=lambda x: x.metrics.get("start") or 0)],
            "rtcp": rtcp_rows,
            "methodology": {
                "loss": "Perda estimada por gaps de sequência RTP, por SSRC/direção.",
                "jitter": "Interarrival jitter calculado por timestamp RTP quando clock rate é conhecido; caso contrário, N/A.",
                "mos": "Não estimado sem parâmetros suficientes; N/A é preferível a uma falsa precisão.",
                "confidence": "Confirmado = observado diretamente; Calculado = derivado matematicamente; Provável/Possível = inferência diagnóstica.",
            },
        }

    @staticmethod
    def _header_value(raw, name):
        if not raw:
            return ""
        target = name.lower()
        for line in str(raw).replace("\r", "").split("\n"):
            if ":" in line:
                key, value = line.split(":", 1)
                if key.strip().lower() == target:
                    return value.strip()
        return ""

    @staticmethod
    def _sdp_rows_from_raw_sip(sip_rows):
        rows = []
        for row in sip_rows:
            lines = row.get("__raw_sdp_lines") or []
            if not lines:
                continue
            address = ""
            media_type = ""
            formats = ""
            media_port = ""
            attrs = []
            for line in lines:
                if line.startswith("c=IN IP4 "):
                    address = line.split(" ", 2)[2].strip()
                elif line.startswith("m="):
                    parts = line.split()
                    if len(parts) >= 4:
                        media_type, media_port, formats = parts[0][2:], parts[1], ";".join(parts[3:])
                elif line.startswith("a="):
                    attrs.append(line[2:])
            if media_port:
                rows.append({
                    "frame.number": row.get("frame.number", ""),
                    "frame.time_epoch": row.get("frame.time_epoch", ""),
                    "sip.Call-ID": row.get("sip.Call-ID", ""),
                    "sdp.connection_info.address": address,
                    "sdp.media.port": media_port,
                    "sdp.media.type": media_type or "audio",
                    "sdp.media.format": formats,
                    "sdp.media.attributes": ";".join(attrs),
                    "sdp.owner.address": address,
                    "__raw_source": "python-pcap-fallback",
                })
        return rows

    def _normalize_sip_row(self, row):
        row = dict(row)
        hdr = row.get("sip.msg_hdr") or ""
        status_line = row.get("sip.Status-Line") or ""
        cseq_raw = row.get("sip.CSeq") or self._header_value(hdr, "CSeq")
        call_id = row.get("sip.Call-ID") or self._header_value(hdr, "Call-ID") or self._header_value(hdr, "i")
        method = (row.get("sip.Method") or "").strip()
        request_line = (row.get("sip.request_line") or "").strip()
        if not method and request_line:
            method = request_line.split(" ", 1)[0].strip()
        if not method and cseq_raw:
            parts = cseq_raw.split()
            if len(parts) >= 2:
                method = parts[-1].strip()
        status = row.get("sip.Status-Code")
        if not status and status_line:
            parts = status_line.split()
            if len(parts) >= 2 and parts[1].isdigit():
                status = parts[1]
        row["sip.Call-ID"] = call_id
        row["sip.Method"] = method
        row["sip.Status-Code"] = status
        row["sip.CSeq"] = cseq_raw
        row["sip.CSeq.seq"] = row.get("sip.CSeq.seq") or (cseq_raw.split()[0] if cseq_raw else "")
        row["sip.CSeq.method"] = row.get("sip.CSeq.method") or (cseq_raw.split()[-1] if cseq_raw and len(cseq_raw.split()) >= 2 else method)
        row["sip.from.uri"] = row.get("sip.from.uri") or self._header_value(hdr, "From") or self._header_value(hdr, "f")
        row["sip.to.uri"] = row.get("sip.to.uri") or self._header_value(hdr, "To") or self._header_value(hdr, "t")
        row["sip.Via.branch"] = row.get("sip.Via.branch") or ""
        if not row["sip.Via.branch"]:
            via = self._header_value(hdr, "Via") or self._header_value(hdr, "v")
            if "branch=" in via:
                row["sip.Via.branch"] = via.split("branch=",1)[1].split(";",1)[0].strip()
        row["sip.User-Agent"] = row.get("sip.User-Agent") or self._header_value(hdr, "User-Agent")
        row["sip.Server"] = row.get("sip.Server") or self._header_value(hdr, "Server")
        row["sip.Reason"] = row.get("sip.Reason") or self._header_value(hdr, "Reason")
        return row

    def _build_calls(self, sip_rows, sdp_rows, rtp_rows):
        calls = {}
        for raw_row in sip_rows:
            row = self._normalize_sip_row(raw_row)
            cid = row.get("sip.Call-ID") or "UNKNOWN"
            msg = SipMessage(
                ts=ffloat(row.get("frame.time_epoch"), 0.0), call_id=cid,
                method=(row.get("sip.Method") or "").strip(), status=fint(row.get("sip.Status-Code")),
                cseq_method=(row.get("sip.CSeq.method") or "").strip(), cseq=(row.get("sip.CSeq.seq") or "").strip(),
                src=ip(row, "src"), dst=ip(row, "dst"), src_port=port(row, "src"), dst_port=port(row, "dst"),
                from_uri=row.get("sip.from.uri") or "", to_uri=row.get("sip.to.uri") or "",
                user_agent=row.get("sip.User-Agent") or row.get("sip.Server") or "",
                reason=row.get("sip.Reason") or "", branch=row.get("sip.Via.branch") or "",
                frame=row.get("frame.number") or "", request_line=row.get("sip.request_line") or "",
            )
            calls.setdefault(cid, Call(cid)).messages.append(msg)
        for row in sdp_rows:
            cid = row.get("sip.Call-ID") or "UNKNOWN"
            calls.setdefault(cid, Call(cid)).sdp.append(row)
        for row in rtp_rows:
            packet = RtpPacket(
                ts=ffloat(row.get("frame.time_epoch"), 0.0), ssrc=row.get("rtp.ssrc") or "",
                seq=fint(row.get("rtp.seq")), rtp_ts=fint(row.get("rtp.timestamp")),
                payload_type=row.get("rtp.p_type") or "", src=ip(row, "src"), dst=ip(row, "dst"),
                src_port=port(row, "src"), dst_port=port(row, "dst"), frame=row.get("frame.number") or "", size=fint(row.get("frame.len")),
            )
            cid = self._correlate_rtp(packet, calls)
            if cid:
                calls[cid].rtp.append(packet)
        return calls

    @staticmethod
    def _uri_user(uri):
        import re
        text = str(uri or "").lower()
        m = re.search(r"(?:sip:|sips:)([^@;>]+)", text)
        return m.group(1) if m else text

    @staticmethod
    def _first_invite(call):
        invites = sorted((m for m in call.messages if m.method.upper() == "INVITE" and m.status is None), key=lambda m: m.ts)
        return invites[0] if invites else None

    def _logical_leg_score(self, a, b):
        ia, ib = self._first_invite(a), self._first_invite(b)
        if not ia or not ib or ia.call_id == ib.call_id:
            return 0, []
        delta = abs(ia.ts - ib.ts)
        if delta > 10:
            return 0, []
        score = 0
        evidence = []
        if self._uri_user(ia.from_uri) and self._uri_user(ia.from_uri) == self._uri_user(ib.from_uri):
            score += 35; evidence.append("mesmo From")
        if self._uri_user(ia.to_uri) and self._uri_user(ia.to_uri) == self._uri_user(ib.to_uri):
            score += 35; evidence.append("mesmo To")
        if ia.src == ib.dst and ia.dst == ib.src and ia.src and ia.dst:
            score += 30; evidence.append("sinalização em sentidos opostos")
        if ia.dst_port and ib.src_port and ia.dst_port == ib.src_port:
            score += 10; evidence.append("porta SIP compatível")
        # B2BUA legs normally start almost together. A short interval is strong
        # evidence, but is deliberately not sufficient by itself.
        if delta <= 2:
            score += 10; evidence.append(f"início com {delta:.2f}s de diferença")
        return score, evidence

    def _merge_logical_legs(self, calls):
        """Consolidate multiple SIP Call-IDs that represent one B2BUA call.

        The capture can expose one Call-ID on the PBX-facing leg and another on
        the downstream leg. Treating them as separate calls inflates ASR,
        concurrency and call counts and can leave RTP attached to only one leg.
        Merging is conservative and requires a high-confidence combination of
        participants and reversed signaling path.
        """
        items = list(calls.values())
        parent = {c.call_id: c.call_id for c in items}

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(a, b):
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[rb] = ra

        for i, a in enumerate(items):
            for b in items[i + 1:]:
                score, evidence = self._logical_leg_score(a, b)
                if score >= 70:
                    union(a.call_id, b.call_id)

        groups = defaultdict(list)
        for c in items:
            groups[find(c.call_id)].append(c)

        merged = {}
        for members in groups.values():
            members.sort(key=lambda c: min((m.ts for m in c.messages), default=float("inf")))
            base = members[0]
            if len(members) == 1:
                base.leg_call_ids = [base.call_id]
                base.correlation = {"type": "single-leg", "confidence": "observed", "leg_count": 1}
                base.leg_details = [self._leg_detail(base)]
                merged[base.call_id] = base
                continue
            all_ids = [c.call_id for c in members]
            evidence = []
            for a, b in zip(members, members[1:]):
                _, ev = self._logical_leg_score(a, b)
                evidence.extend(ev)
            for other in members[1:]:
                base.messages.extend(other.messages)
                base.sdp.extend(other.sdp)
                base.rtp.extend(other.rtp)
                base.rtcp.extend(other.rtcp)
                base.anomalies.extend(other.anomalies)
            base.messages.sort(key=lambda m: m.ts)
            base.sdp.sort(key=lambda r: ffloat(r.get("frame.time_epoch"), 0) or 0)
            base.rtp.sort(key=lambda p: p.ts)
            base.leg_call_ids = all_ids
            base.correlation = {
                "type": "B2BUA/multi-leg", "confidence": "high", "leg_count": len(members),
                "call_ids": all_ids, "evidence": sorted(set(evidence)),
            }
            base.leg_details = [self._leg_detail(member) for member in members]
            merged[base.call_id] = base
        return merged

    def _leg_detail(self, call):
        """Return a stable, report-friendly snapshot of one physical SIP leg."""
        messages = sorted(call.messages, key=lambda m: m.ts)
        first = messages[0] if messages else None
        invite = self._first_invite(call)
        rtp = self._rtp_metrics(call.rtp)
        media = self._media_summary(call.sdp)
        return {
            "call_id": call.call_id,
            "from": (first.from_uri if first else ""),
            "to": (first.to_uri if first else ""),
            "signaling": {
                "src": (invite.src if invite else (first.src if first else "")),
                "src_port": (invite.src_port if invite else (first.src_port if first else "")),
                "dst": (invite.dst if invite else (first.dst if first else "")),
                "dst_port": (invite.dst_port if invite else (first.dst_port if first else "")),
            },
            "messages": len(messages),
            "rtp": rtp,
            "media": media,
            "codecs": self._codecs(call.sdp),
            "start": messages[0].ts if messages else None,
            "end": messages[-1].ts if messages else None,
        }

    def _sdp_endpoints(self, call):
        endpoints = set()
        for row in call.sdp:
            addresses = [row.get("sdp.connection_info.address"), row.get("sdp.owner.address")]
            ports = str(row.get("sdp.media.port") or "").split(";")
            for address in addresses:
                if address:
                    for raw_port in ports:
                        try:
                            endpoints.add((address, int(raw_port)))
                        except ValueError:
                            pass
        return endpoints

    def _correlate_rtp(self, packet, calls):
        candidates = []
        try:
            sp, dp = int(packet.src_port), int(packet.dst_port)
        except (TypeError, ValueError):
            sp = dp = -1
        for cid, call in calls.items():
            if not call.messages:
                continue
            start = min(m.ts for m in call.messages)
            end = max(m.ts for m in call.messages)
            if not (start - 3 <= packet.ts <= end + 60):
                continue
            endpoints = self._sdp_endpoints(call)
            media_ports = {p for _, p in endpoints}
            score = 10
            # Port-pair correlation is stronger than IP correlation because captures
            # may be anonymized or contain NAT/media-proxy address rewriting.
            for a in media_ports:
                if (sp, dp) == (a, a + 1) or (sp, dp) == (a + 1, a):
                    score = max(score, 30)
                if sp == a or dp == a:
                    score = max(score, 60)
            if ((packet.src, sp) in endpoints) or ((packet.dst, dp) in endpoints):
                score = 100
            candidates.append((score, -abs(packet.ts - start), cid))
        if not candidates:
            return None
        candidates.sort(reverse=True)
        return candidates[0][2] if candidates[0][0] >= 30 else None

    def _attach_rtcp(self, calls, rows):
        for row in rows:
            ts = ffloat(row.get("frame.time_epoch"), 0)
            candidates = []
            for cid, call in calls.items():
                if not call.messages:
                    continue
                start = min(m.ts for m in call.messages)
                end = max(m.ts for m in call.messages)
                if start - 3 <= ts <= end + 60:
                    candidates.append((abs(ts - start), cid))
            if candidates:
                candidates.sort()
                calls[candidates[0][1]].rtcp.append(row)

    def _rtp_direction_metrics(self, packets):
        """Build media intervals/gaps per IP:port direction from observed RTP."""
        by_direction = defaultdict(list)
        for packet in packets:
            by_direction[(packet.src, str(packet.src_port), packet.dst, str(packet.dst_port))].append(packet)
        directions = []
        for key, stream in sorted(by_direction.items()):
            stream.sort(key=lambda p: p.ts)
            gaps = []
            for prev, cur in zip(stream, stream[1:]):
                gap = max(0.0, cur.ts - prev.ts)
                if gap >= 1.0:
                    gaps.append({
                        "start_ts": prev.ts, "end_ts": cur.ts, "duration_s": gap,
                        "src": key[0], "src_port": key[1], "dst": key[2], "dst_port": key[3],
                    })
            directions.append({
                "src": key[0], "src_port": key[1], "dst": key[2], "dst_port": key[3],
                "packets": len(stream), "first_ts": stream[0].ts, "last_ts": stream[-1].ts,
                "duration_s": max(0.0, stream[-1].ts - stream[0].ts),
                "payload_types": sorted(set(str(p.payload_type) for p in stream)),
                "first_frame": stream[0].frame, "last_frame": stream[-1].frame,
                "gaps": gaps, "max_gap_s": max((g["duration_s"] for g in gaps), default=0.0),
            })
        return directions

    def _correlated_timeline(self, call, answer_ts=None, end_ts=None):
        """Create a compact, evidence-only SIP + RTP state timeline."""
        messages = sorted(call.messages, key=lambda m: m.ts)
        start = min((m.ts for m in messages), default=None)
        if start is None:
            return []
        events = []
        for m in messages:
            method = (m.method or "").upper()
            if method in {"REGISTER", "OPTIONS"}:
                continue
            if m.status is not None:
                label = f"SIP {m.status}"
                if m.cseq_method:
                    label += f" {m.cseq_method.upper()}"
                typ = "SIP_RESPONSE"
            elif method:
                label = f"SIP {method}"
                if m.cseq:
                    label += f" CSeq {m.cseq}"
                typ = "SIP_REQUEST"
            else:
                continue
            events.append({"ts": m.ts, "offset_s": m.ts - start, "type": typ, "label": label,
                           "frame": m.frame, "src": m.src, "dst": m.dst})

        direction_metrics = self._rtp_direction_metrics(call.rtp)
        for d in direction_metrics:
            direction = f"{d['src']}:{d['src_port']} → {d['dst']}:{d['dst_port']}"
            events.append({"ts": d["first_ts"], "offset_s": d["first_ts"] - start,
                           "type": "RTP_START", "label": f"RTP iniciou ({direction}) · {d['packets']} pacotes",
                           "src": d["src"], "dst": d["dst"]})
            if answer_ts is not None and d["first_ts"] >= answer_ts:
                delay = d["first_ts"] - answer_ts
                if delay >= 0.5:
                    events.append({"ts": d["first_ts"], "offset_s": d["first_ts"] - start,
                                   "type": "RTP_START_DELAY", "label": f"Primeiro RTP {delay:.2f}s após 200 OK ({direction})",
                                   "src": d["src"], "dst": d["dst"]})
            for gap in d["gaps"]:
                events.append({"ts": gap["start_ts"], "offset_s": gap["start_ts"] - start,
                               "type": "RTP_GAP_START", "label": f"Interrupção RTP iniciou: {gap['duration_s']:.2f}s ({direction})",
                               "src": d["src"], "dst": d["dst"]})
                events.append({"ts": gap["end_ts"], "offset_s": gap["end_ts"] - start,
                               "type": "RTP_GAP_END", "label": f"RTP retomado após {gap['duration_s']:.2f}s ({direction})",
                               "src": d["src"], "dst": d["dst"]})
            events.append({"ts": d["last_ts"], "offset_s": d["last_ts"] - start,
                           "type": "RTP_END", "label": f"Último RTP observado ({direction})",
                           "src": d["src"], "dst": d["dst"]})

        events.sort(key=lambda e: (e["ts"], 0 if e["type"].startswith("SIP") else 1, e["type"]))
        unique, seen = [], set()
        for e in events:
            key = (round(e["ts"], 6), e["type"], e["label"], e.get("frame", ""))
            if key not in seen:
                seen.add(key); unique.append(e)
        return unique

    def _sip_transaction_metrics(self, messages):
        """Correlate SIP requests with their first matching response and calculate RTT."""
        requests = [m for m in messages if m.status is None and m.method]
        responses = [m for m in messages if m.status is not None]
        transactions = []
        for req in requests:
            method = req.method.upper()
            if method in {"ACK", "CANCEL"}:
                continue
            candidates = [r for r in responses
                          if r.cseq_method.upper() == method
                          and (not req.cseq or not r.cseq or r.cseq == req.cseq)
                          and r.ts >= req.ts]
            if not candidates:
                continue
            # Prefer the response from the opposite signaling endpoint and the nearest timestamp.
            candidates.sort(key=lambda r: (0 if (r.src == req.dst and r.dst == req.src) else 1,
                                           r.ts - req.ts))
            resp = candidates[0]
            rtt_ms = max(0.0, (resp.ts - req.ts) * 1000)
            transactions.append({
                "method": method, "cseq": req.cseq, "request_ts": req.ts,
                "response_ts": resp.ts, "status": resp.status, "rtt_ms": rtt_ms,
                "request_frame": req.frame, "response_frame": resp.frame,
            })
        return transactions

    def _sdp_consistency(self, call):
        """Compare SDP-declared media endpoints with observed RTP endpoints."""
        declarations = []
        for row in call.sdp:
            if row.get("__rtcp__"):
                continue
            address = row.get("sdp.connection_info.address") or row.get("sdp.owner.address") or ""
            ports = str(row.get("sdp.media.port") or "").split(";")
            for raw in ports:
                try:
                    p = int(raw)
                except (TypeError, ValueError):
                    continue
                if address:
                    declarations.append((address, p))
        declared = sorted(set(declarations))
        observed = sorted(set((p.src, int(p.src_port)) for p in call.rtp if str(p.src_port).isdigit()) |
                          set((p.dst, int(p.dst_port)) for p in call.rtp if str(p.dst_port).isdigit()))
        if not declared:
            return {"status": "INDETERMINATE", "declared": [], "observed": observed, "mismatches": [],
                    "note": "Nenhum endpoint de mídia suficientemente identificado no SDP."}
        exact = [ep for ep in declared if ep in observed]
        # Address mismatch is useful evidence, but NAT/media-proxy designs can legitimately
        # produce different observed endpoints. Never label it as a confirmed NAT fault.
        mismatches = [ep for ep in declared if ep not in observed]
        if exact:
            status = "CONSISTENT" if not mismatches else "PARTIAL"
        else:
            status = "MISMATCH"
        return {"status": status, "declared": declared, "observed": observed, "matched": exact,
                "mismatches": mismatches,
                "note": "Divergência pode ser compatível com NAT, SBC/media proxy, symmetric RTP ou outro ponto de captura."}

    def _one_way_classification(self, rtp):
        directions = rtp.get("directions", [])
        if not directions:
            return "NO_RTP"
        if len(directions) == 1:
            return "RTP_UNILATERAL"
        durations = sorted((d.get("duration_s", 0) for d in directions), reverse=True)
        if durations and len(durations) >= 2 and durations[1] + 1 < durations[0]:
            return "RTP_ASYMMETRIC_DURATION"
        return "RTP_BIDIRECTIONAL"

    def _rtcp_metrics(self, rows):
        fractions=[]; cumulative=[]; jitters=[]; rtts=[]
        for row in rows or []:
            for key, target in (("rtcp.fraction.lost", fractions), ("rtcp.cumulative.lost", cumulative),
                                ("rtcp.jitter", jitters), ("rtcp.rtt", rtts)):
                value = ffloat(row.get(key))
                if value is not None:
                    target.append(value)
        return {
            "packets": len(rows or []),
            "fraction_lost_avg": statistics.mean(fractions) if fractions else None,
            "cumulative_lost_max": max(cumulative) if cumulative else None,
            "jitter_avg": statistics.mean(jitters) if jitters else None,
            "rtt_avg": statistics.mean(rtts) if rtts else None,
        }

    def _metrics(self, call):
        messages = sorted(call.messages, key=lambda m: m.ts)
        invite_requests = [m for m in messages if m.method.upper() == "INVITE" and m.status is None]
        initial = invite_requests[0] if invite_requests else None
        # A 401/407 challenge is part of the same call setup. Do not treat the
        # authenticated INVITE as a re-INVITE, and do not require the 200 OK to
        # have the CSeq of the very first pre-authentication INVITE.
        auth_challenge_cseqs = {
            m.cseq for m in messages
            if m.status in (401, 407) and m.cseq_method.upper() == "INVITE" and m.cseq
        }
        effective_invites = [m for m in invite_requests if m.cseq not in auth_challenge_cseqs]
        if not effective_invites:
            effective_invites = invite_requests
        effective_initial = effective_invites[0] if effective_invites else initial
        reinvites = [m for m in invite_requests if m is not effective_initial and m.cseq not in auth_challenge_cseqs]
        invite_responses = [m for m in messages if m.status is not None and m.cseq_method.upper() == "INVITE"]
        ringing = next((m for m in invite_responses if m.status in (180, 183)), None)
        answer = next((m for m in invite_responses if m.status == 200), None)
        cancel = next((m for m in messages if m.method.upper() == "CANCEL"), None)
        byes = [m for m in messages if m.method.upper() == "BYE"]
        bye = byes[-1] if byes else None
        start = initial.ts if initial else (messages[0].ts if messages else None)
        end = bye.ts if bye else (cancel.ts if cancel else (messages[-1].ts if messages else None))
        final_status = invite_responses[-1].status if invite_responses else next((m.status for m in reversed(messages) if m.status), None)
        pdd_trying = next((m.ts - start for m in invite_responses if m.status == 100), None) if start is not None else None
        pdd_progress = ringing.ts - start if start is not None and ringing else None
        pdd_answer = answer.ts - start if start is not None and answer else None
        conversation = (bye.ts - answer.ts) if answer and bye and bye.ts >= answer.ts else None
        retransmissions = self._retransmissions(messages)
        rtp = self._rtp_metrics(call.rtp)
        codecs = self._codecs(call.sdp)
        media = self._media_summary(call.sdp)
        first_rtp_ts = min((p.ts for p in call.rtp), default=None)
        last_rtp_ts = max((p.ts for p in call.rtp), default=None)
        media_start_delay = (first_rtp_ts - answer.ts) if answer and first_rtp_ts is not None and first_rtp_ts >= answer.ts else None
        media_end_gap = (end - last_rtp_ts) if end is not None and last_rtp_ts is not None and end >= last_rtp_ts else None
        rtp["first_ts"] = first_rtp_ts
        rtp["last_ts"] = last_rtp_ts
        rtp["media_start_delay_s"] = media_start_delay
        rtp["media_end_gap_s"] = media_end_gap
        rtp["direction_metrics"] = self._rtp_direction_metrics(call.rtp)
        rtp["one_way_classification"] = self._one_way_classification(rtp)
        sip_transactions = self._sip_transaction_metrics(messages)
        rtcp_metrics = self._rtcp_metrics(call.rtcp)
        sdp_consistency = self._sdp_consistency(call)
        timeline = self._correlated_timeline(call, answer.ts if answer else None, end)
        gap_events = [e for e in timeline if e["type"] == "RTP_GAP_START"]
        call.metrics = {
            "start": start, "end": end,
            "duration": end - start if start is not None and end is not None else None,
            "conversation_duration": conversation,
            "pdd_to_trying": pdd_trying, "pdd_to_progress": pdd_progress, "pdd_to_answer": pdd_answer,
            "final_status": final_status, "answered": bool(answer), "cancelled": bool(cancel), "bye": bool(bye),
            "bye_count": len(byes), "effective_invite_cseq": effective_initial.cseq if effective_initial else None,
            "authentication_challenges": len(auth_challenge_cseqs),
            "re_invites": len(reinvites), "retransmissions": retransmissions,
            "rtp": rtp, "codecs": codecs, "media": media,
            "sip_transactions": sip_transactions,
            "sip_transaction_rtt_avg_ms": statistics.mean([t["rtt_ms"] for t in sip_transactions]) if sip_transactions else None,
            "sip_transaction_rtt_p95_ms": percentile([t["rtt_ms"] for t in sip_transactions], 95),
            "rtcp": rtcp_metrics, "sdp_consistency": sdp_consistency,
            "timeline": timeline,
            "rtp_gap_count": len(gap_events),
            "rtp_gap_max_s": max((g.get("duration_s", 0.0) for d in rtp.get("direction_metrics", []) for g in d.get("gaps", [])), default=0.0),
            "sip_messages": len(messages),
            "sip_requests": len([m for m in messages if m.status is None and m.method]),
            "sip_methods": dict(Counter(m.method for m in messages if m.status is None and m.method)),
        }

    def _retransmissions(self, messages):
        seen = Counter()
        for m in messages:
            key = (m.branch, m.cseq, m.cseq_method.upper(), m.status, m.src, m.dst, m.src_port, m.dst_port)
            if any(key):
                seen[key] += 1
        return sum(max(0, n - 1) for n in seen.values())

    def _rtp_metrics(self, packets):
        if not packets:
            return {"packets": 0, "streams": 0, "loss_pct": None, "loss_packets": None,
                    "jitter_ms": None, "jitter_p95_ms": None, "delta_mean_ms": None,
                    "delta_p95_ms": None, "bitrate_kbps": None, "pps": None,
                    "one_way": False, "streams_detail": [], "timeline": []}
        by = defaultdict(list)
        for packet in packets:
            # IPs can be rewritten by anonymizers/NAT. Keep the UDP direction in the
            # stream key so packets from one media leg are not split into hundreds of
            # artificial streams when source IPs vary.
            by[(packet.ssrc, packet.src_port, packet.dst_port)].append(packet)
        streams = []
        all_jitter = []
        all_delta = []
        total_loss = 0
        expected_total = 0
        timeline = []
        for key, stream in by.items():
            stream.sort(key=lambda p: p.ts)
            seqs = [p.seq for p in stream if p.seq is not None]
            loss = 0
            if len(seqs) >= 2:
                for a, b in zip(seqs, seqs[1:]):
                    diff = (b - a) % 65536
                    if 1 < diff < 1000:
                        loss += diff - 1
            expected = len(seqs) + loss
            clock = PAYLOAD_CLOCK.get(str(stream[0].payload_type), 8000)
            jitter = []
            prev_transit = None
            rfc_jitter = None
            for prev, cur in zip(stream, stream[1:]):
                delta_ms = (cur.ts - prev.ts) * 1000
                if delta_ms >= 0:
                    all_delta.append(delta_ms)
                    gap_loss = 0
                    if prev.seq is not None and cur.seq is not None:
                        diff = (cur.seq - prev.seq) % 65536
                        if 1 < diff < 1000:
                            gap_loss = diff - 1
                    timeline.append({"ts": cur.ts, "delta_ms": delta_ms, "loss": gap_loss})
                if prev.rtp_ts is not None and cur.rtp_ts is not None:
                    transit = cur.ts * clock - cur.rtp_ts
                    if prev_transit is not None:
                        d = abs(transit - prev_transit)
                        rfc_jitter = d if rfc_jitter is None else rfc_jitter + (d - rfc_jitter) / 16
                        jitter.append(rfc_jitter * 1000 / clock)
                    prev_transit = transit
            all_jitter.extend(jitter)
            duration = max(stream[-1].ts - stream[0].ts, 0.001)
            bitrate = (sum((p.size or 0) for p in stream) * 8 / duration / 1000) if any(p.size for p in stream) else None
            stream_info = {
                "ssrc": key[0], "src": stream[0].src, "dst": stream[0].dst, "src_port": key[1], "dst_port": key[2],
                "packets": len(stream), "loss_packets": loss,
                "loss_pct": 100 * loss / expected if expected else None,
                "jitter_ms": statistics.mean(jitter) if jitter else None,
                "jitter_p95_ms": percentile(jitter, 95),
                "delta_mean_ms": statistics.mean([x for x in all_delta[-max(1, len(stream)-1):]]) if all_delta else None,
                "duration_s": duration, "pps": len(stream) / duration, "bitrate_kbps": bitrate,
                "clock_rate": clock, "payload_types": sorted(set(p.payload_type for p in stream)),
                "media_ip_port": f"{stream[0].src}:{key[1]} -> {stream[0].dst}:{key[2]}",
            }
            streams.append(stream_info)
            total_loss += loss
            expected_total += expected
        directions = {(str(p.src_port), str(p.dst_port)) for p in packets}
        has_reverse = any((b, a) in directions for a, b in directions)
        direction_stats = []
        for direction in sorted(directions):
            stream_packets = [p for p in packets if (str(p.src_port), str(p.dst_port)) == direction]
            if stream_packets:
                direction_stats.append({
                    "src": stream_packets[0].src, "dst": stream_packets[0].dst,
                    "src_port": direction[0], "dst_port": direction[1],
                    "packets": len(stream_packets),
                    "first_ts": stream_packets[0].ts, "last_ts": stream_packets[-1].ts,
                    "duration_s": max(0.0, stream_packets[-1].ts - stream_packets[0].ts),
                    "payload_types": sorted(set(str(p.payload_type) for p in stream_packets)),
                })
        return {
            "packets": len(packets), "streams": len(streams),
            "loss_pct": 100 * total_loss / expected_total if expected_total else None,
            "loss_packets": total_loss if expected_total else None,
            "jitter_ms": statistics.mean(all_jitter) if all_jitter else None,
            "jitter_p95_ms": percentile(all_jitter, 95),
            "delta_mean_ms": statistics.mean(all_delta) if all_delta else None,
            "delta_p95_ms": percentile(all_delta, 95),
            "bitrate_kbps": statistics.mean([s["bitrate_kbps"] for s in streams if s.get("bitrate_kbps") is not None]) if any(s.get("bitrate_kbps") is not None for s in streams) else None,
            "pps": len(packets) / max(packets[-1].ts - packets[0].ts, 0.001),
            "one_way": not has_reverse,
            "bidirectional": has_reverse,
            "directions": direction_stats,
            "streams_detail": streams,
            "timeline": sorted(timeline, key=lambda x: x["ts"]),
        }

    def _media_summary(self, sdp):
        declarations = []
        for row in sdp:
            if row.get("__rtcp__"):
                continue
            address = row.get("sdp.connection_info.address") or row.get("sdp.owner.address") or ""
            port_raw = row.get("sdp.media.port") or ""
            media_type = row.get("sdp.media.type") or "audio"
            formats = row.get("sdp.media.format") or ""
            attrs = row.get("sdp.media.attributes") or ""
            declarations.append({"address": address, "port": port_raw, "type": media_type, "formats": formats, "attributes": attrs})
        return declarations

    def _codecs(self, sdp):
        values = []
        for row in sdp:
            if row.get("__rtcp__"):
                continue
            attrs = str(row.get("sdp.media.attributes") or "")
            for attr in attrs.replace("\n", ";").split(";"):
                attr = attr.strip()
                if attr.startswith("rtpmap:"):
                    values.append(attr.split(":", 1)[1].strip())
            if not attrs:
                for key in ("sdp.media.format_specific_parameter", "sdp.media.format"):
                    value = row.get(key) or ""
                    values.extend(x.strip() for x in str(value).split(";") if x.strip())
        return sorted(set(values))

    def _macro(self, info, calls, rtcp):
        cs = list(calls.values())
        attempts = sum(1 for c in cs if c.messages and c.call_id != "UNKNOWN" and any(m.method.upper() == "INVITE" for m in c.messages))
        answered = sum(1 for c in cs if c.metrics.get("answered"))
        durations = [c.metrics["duration"] for c in cs if c.metrics.get("duration") is not None]
        pdd_try = [c.metrics["pdd_to_trying"] for c in cs if c.metrics.get("pdd_to_trying") is not None]
        pdd_prog = [c.metrics["pdd_to_progress"] for c in cs if c.metrics.get("pdd_to_progress") is not None]
        pdds = [c.metrics["pdd_to_answer"] for c in cs if c.metrics.get("pdd_to_answer") is not None]
        losses = [c.metrics["rtp"]["loss_pct"] for c in cs if c.metrics["rtp"].get("loss_pct") is not None]
        jitters = [c.metrics["rtp"]["jitter_ms"] for c in cs if c.metrics["rtp"].get("jitter_ms") is not None]
        rtp_bitrates = [c.metrics["rtp"].get("bitrate_kbps") for c in cs if c.metrics["rtp"].get("bitrate_kbps") is not None]
        rtp_pps = [c.metrics["rtp"].get("pps") for c in cs if c.metrics["rtp"].get("pps") is not None]
        rtp_gap_calls = sum(1 for c in cs if c.metrics.get("rtp_gap_count", 0) > 0)
        rtp_gap_events = sum(c.metrics.get("rtp_gap_count", 0) for c in cs)
        final_codes = Counter(str(c.metrics.get("final_status")) for c in cs if c.metrics.get("final_status") is not None)
        all_codes = Counter()
        all_methods = Counter()
        for c in cs:
            for m in c.messages:
                if m.status is not None:
                    all_codes[str(m.status)] += 1
                if m.status is None and m.method:
                    all_methods[m.method.upper()] += 1
        # SIP control traffic is deliberately kept outside call-attempt KPIs. REGISTER
        # and OPTIONS are useful health/keepalive evidence but are not calls.
        non_call_methods = {k: v for k, v in all_methods.items() if k not in {"INVITE", "ACK", "BYE", "CANCEL", "PRACK", "UPDATE", "INFO", "REFER", "NOTIFY", "MESSAGE", "SUBSCRIBE", "PUBLISH"}}
        classes = Counter((str(code)[0] + "xx") for code in all_codes for _ in range(all_codes[code]) if str(code).isdigit())
        codecs = Counter(codec for c in cs for codec in c.metrics.get("codecs", []))
        transaction_rtts = [t["rtt_ms"] for c in cs for t in c.metrics.get("sip_transactions", [])]
        options_requests = 0; options_responses = 0; options_success = 0; options_rtts = []
        for c in cs:
            for m in c.messages:
                if m.status is None and m.method.upper() == "OPTIONS":
                    options_requests += 1
            for t in c.metrics.get("sip_transactions", []):
                if t.get("method") == "OPTIONS":
                    options_responses += 1
                    if 200 <= int(t.get("status") or 0) < 300:
                        options_success += 1
                    options_rtts.append(t.get("rtt_ms"))
        duration = info.get("duration") or 0
        return {
            "calls": attempts, "answered": answered, "asr_pct": 100 * answered / attempts if attempts else None,
            "ner_pct": None, "duration_avg_s": statistics.mean(durations) if durations else None,
            "pdd_trying_avg_s": statistics.mean(pdd_try) if pdd_try else None,
            "pdd_progress_avg_s": statistics.mean(pdd_prog) if pdd_prog else None,
            "pdd_avg_s": statistics.mean(pdds) if pdds else None,
            "pdd_min_s": min(pdds) if pdds else None, "pdd_max_s": max(pdds) if pdds else None,
            "loss_avg_pct": statistics.mean(losses) if losses else None, "loss_p95_pct": percentile(losses, 95),
            "jitter_avg_ms": statistics.mean(jitters) if jitters else None, "jitter_p95_ms": percentile(jitters, 95),
            "rtp_bitrate_avg_kbps": statistics.mean(rtp_bitrates) if rtp_bitrates else None,
            "rtp_bitrate_p95_kbps": percentile(rtp_bitrates, 95),
            "rtp_pps_avg": statistics.mean(rtp_pps) if rtp_pps else None,
            "rtp_pps_p95": percentile(rtp_pps, 95),
            "one_way_calls": sum(1 for c in cs if c.metrics["rtp"].get("one_way")),
            "rtp_calls": sum(1 for c in cs if c.metrics["rtp"].get("packets", 0) > 0),
            "rtp_gap_calls": rtp_gap_calls, "rtp_gap_events": rtp_gap_events,
            "rtp_gap_max_s": max((c.metrics.get("rtp_gap_max_s", 0.0) for c in cs), default=0.0),
            "response_codes": dict(final_codes),
            "all_response_codes": dict(all_codes),
            "response_classes": dict(classes),
            "codecs": dict(codecs),
            "sip_methods": dict(all_methods),
            "control_methods": non_call_methods,
            "register_packets": all_methods.get("REGISTER", 0),
            "options_packets": all_methods.get("OPTIONS", 0),
            "rtcp_reports": len(rtcp), "rtcp_fraction_lost_avg": statistics.mean([x for c in cs for x in [c.metrics.get("rtcp",{}).get("fraction_lost_avg")] if x is not None]) if any(c.metrics.get("rtcp",{}).get("fraction_lost_avg") is not None for c in cs) else None,
            "sip_retransmissions": sum(c.metrics.get("retransmissions", 0) for c in cs),
            "sip_transaction_rtt_avg_ms": statistics.mean(transaction_rtts) if transaction_rtts else None,
            "sip_transaction_rtt_p95_ms": percentile(transaction_rtts,95),
            "options_health": {"requests": options_requests, "responses": options_responses, "success": options_success, "success_pct": 100*options_success/options_requests if options_requests else None, "rtt_avg_ms": statistics.mean([x for x in options_rtts if x is not None]) if options_rtts else None},
            "re_invites": sum(c.metrics.get("re_invites", 0) for c in cs),
            "pps": info.get("packets", 0) / duration if duration else None,
            "bps": info.get("bytes", 0) * 8 / duration if duration else None,
            "mos_estimated": None, "mos_note": "N/A: não há dados suficientes para uma estimativa defensável.",
            "concurrent_peak": self._concurrent_peak(cs),
            "rtp_unassociated_packets": info.get("extraction", {}).get("rtp_unassociated_packets", 0),
            "protocol_inventory": {
                "sip_packets": info.get("protocol_inventory", {}).get("counts", {}).get("sip", 0),
                "sdp_packets": info.get("protocol_inventory", {}).get("counts", {}).get("sdp", 0),
                "rtp_packets": info.get("protocol_inventory", {}).get("counts", {}).get("rtp", 0),
                "rtcp_packets": info.get("protocol_inventory", {}).get("counts", {}).get("rtcp", 0),
            },
        }

    def _concurrent_peak(self, calls):
        events = []
        for c in calls:
            start = c.metrics.get("start")
            end = c.metrics.get("end")
            if start is not None:
                events.append((start, 1))
            if end is not None:
                events.append((end, -1))
        active = peak = 0
        for _, delta in sorted(events, key=lambda x: (x[0], -x[1])):
            active += delta
            peak = max(peak, active)
        return peak

    def _add_anomaly(self, call, severity, confidence, code, finding, impact, recommendation, evidence=None):
        call.anomalies.append({"severity": severity, "confidence": confidence, "code": code,
                               "finding": finding, "impact": impact, "recommendation": recommendation,
                               "evidence": evidence or {}})

    def _diagnose(self, calls, macro):
        for call in calls.values():
            m = call.metrics
            r = m["rtp"]
            if m.get("retransmissions", 0) >= 3:
                self._add_anomaly(call, "medium", "high", "SIP_RETRANSMISSION",
                    f"Foram observadas {m['retransmissions']} retransmissões/duplicações aparentes em transações SIP.",
                    "Pode indicar perda, atraso ou ausência de resposta no caminho de sinalização.",
                    "Correlacionar timestamps com RTT de transações SIP, perda de pacotes e estado de PBX/SBC/firewall.")
            if m.get("pdd_to_answer") is not None and m["pdd_to_answer"] > 3:
                self._add_anomaly(call, "medium", "high", "HIGH_PDD",
                    f"PDD até atendimento de {m['pdd_to_answer']:.2f}s, acima do limiar operacional de 3s.",
                    "Aumento do tempo percebido para estabelecimento da chamada.",
                    "Investigar resposta SIP, roteamento, latência e tempo de terminação.")
            if r.get("loss_pct") is not None and r["loss_pct"] > 1:
                sev = "high" if r["loss_pct"] > 3 else "medium"
                self._add_anomaly(call, sev, "high", "RTP_LOSS",
                    f"Perda RTP estimada de {r['loss_pct']:.2f}%.",
                    "Pode causar áudio picotado, gaps e degradação perceptível.",
                    "Correlacionar com jitter, delta, QoS/DSCP e utilização do enlace no intervalo do evento.")
            if r.get("jitter_ms") is not None and r["jitter_ms"] > 30:
                self._add_anomaly(call, "medium", "calculated", "RTP_JITTER",
                    f"Jitter interarrival calculado de {r['jitter_ms']:.2f}ms, acima do limiar operacional de 30ms.",
                    "Pode provocar variação de reprodução e atuação de jitter buffer.",
                    "Investigar congestionamento, filas, QoS e assimetria de caminho.")
            if m.get("rtp_gap_count", 0) > 0:
                max_gap = m.get("rtp_gap_max_s", 0.0)
                sev = "high" if max_gap >= 5 else "medium"
                self._add_anomaly(call, sev, "high", "RTP_MEDIA_GAP",
                    f"Foram observadas {m.get('rtp_gap_count', 0)} interrupções RTP com duração mínima de 1s; maior intervalo observado: {max_gap:.2f}s.",
                    "Indica ausência prolongada de pacotes RTP em pelo menos uma direção no ponto de captura e pode ser compatível com áudio interrompido.",
                    "Correlacionar o início/fim do intervalo com SIP/SDP, NAT, firewall, SBC/media proxy, QoS e mudanças de rota.",
                    {"timeline_events": [e for e in m.get("timeline", []) if e.get("type") in {"RTP_GAP_START", "RTP_GAP_END"}]})
            if r.get("one_way"):
                self._add_anomaly(call, "high", "high", "ONE_WAY_RTP",
                    "RTP foi observado em apenas um sentido no ponto de captura.",
                    "Compatível com áudio unidirecional; a conclusão funcional depende do ponto de captura.",
                    "Validar SDP, NAT, firewall, SBC/media proxy e presença do fluxo inverso em outro ponto da rede.")
            elif len(r.get("directions", [])) >= 2:
                ds = sorted(r["directions"], key=lambda x: x["packets"], reverse=True)
                dominant = ds[0]
                reverse = ds[1]
                if reverse.get("duration_s", 0) + 1 < dominant.get("duration_s", 0):
                    gap = dominant.get("last_ts", 0) - reverse.get("last_ts", 0)
                    self._add_anomaly(call, "high", "high", "RTP_DIRECTION_GAP",
                        f"O fluxo RTP reverso terminou aproximadamente {gap:.2f}s antes do fluxo dominante.",
                        "Compatível com perda de áudio em um sentido após o início da conversação, caso o ponto de captura cubra ambos os lados.",
                        "Correlacionar o instante do desaparecimento do RTP reverso com NAT, firewall, SBC/media proxy e mudanças de rota.",
                        {"dominant_last_ts": dominant.get("last_ts"), "reverse_last_ts": reverse.get("last_ts"), "gap_s": gap})
            if m.get("answered") and r.get("packets", 0) == 0:
                self._add_anomaly(call, "high", "high", "NO_RTP_AFTER_ANSWER",
                    "A chamada foi atendida, mas nenhum pacote RTP foi associado ao Call-ID.",
                    "Indica possível falha de estabelecimento de mídia ou limitação do ponto de captura.",
                    "Validar SDP e buscar o stream RTP pelo IP/porta anunciados no SDP.")
            elif m.get("answered") and r.get("media_start_delay_s") is not None and r["media_start_delay_s"] > 2:
                sev = "high" if r["media_start_delay_s"] > 5 else "medium"
                self._add_anomaly(call, sev, "calculated", "RTP_START_DELAY",
                    f"O primeiro RTP observado ocorreu {r['media_start_delay_s']:.2f}s após o atendimento.",
                    "Pode indicar atraso na abertura da mídia, negociação tardia, firewall/NAT ou encaminhamento de mídia.",
                    "Correlacionar o primeiro RTP com 200 OK/ACK, SDP, SBC/media proxy, NAT e regras de firewall.",
                    {"answer_ts": answer.ts if answer else None, "first_rtp_ts": r.get("first_ts"), "delay_s": r["media_start_delay_s"]})
            if m.get("answered") and r.get("media_end_gap_s") is not None and r["media_end_gap_s"] > 2:
                sev = "high" if r["media_end_gap_s"] > 10 else "medium"
                self._add_anomaly(call, sev, "calculated", "RTP_END_GAP",
                    f"O RTP deixou de ser observado {r['media_end_gap_s']:.2f}s antes do encerramento da chamada.",
                    "Compatível com interrupção ou ausência de mídia antes do BYE/CANCEL, desde que o ponto de captura cubra o caminho relevante.",
                    "Correlacionar o instante do último RTP com BYE, re-INVITE/SDP, NAT, firewall, SBC/media proxy e mudanças de rota.",
                    {"last_rtp_ts": r.get("last_ts"), "end_ts": m.get("end"), "gap_s": r["media_end_gap_s"]})
            sdp = m.get("sdp_consistency", {})
            if sdp.get("status") == "MISMATCH":
                self._add_anomaly(call, "medium", "calculated", "SDP_RTP_MISMATCH",
                    "Os endpoints de mídia anunciados no SDP não coincidem com os endpoints RTP observados.",
                    "Pode indicar NAT, SBC/media proxy, symmetric RTP ou captura fora do caminho completo da mídia.",
                    "Validar os endereços/portas anunciados no SDP e correlacionar com o ponto de captura, NAT, SBC/media proxy e firewall.",
                    {"declared": sdp.get("declared", []), "observed": sdp.get("observed", [])})
            elif sdp.get("status") == "PARTIAL":
                self._add_anomaly(call, "low", "calculated", "SDP_RTP_PARTIAL_MATCH",
                    "Parte dos endpoints de mídia anunciados no SDP não foi observada como endpoint RTP na captura.",
                    "A divergência pode ser legítima em arquiteturas com media proxy/NAT ou decorrer de um ponto de captura parcial.",
                    "Validar os endpoints RTP esperados por perna antes de concluir falha de mídia.",
                    {"declared": sdp.get("declared", []), "observed": sdp.get("observed", [])})
            if m.get("rtcp", {}).get("fraction_lost_avg") is not None and m["rtcp"]["fraction_lost_avg"] > 0:
                self._add_anomaly(call, "medium", "observed", "RTCP_LOSS_REPORT",
                    f"RTCP reportou fraction lost médio de {m['rtcp']['fraction_lost_avg']:.2f}%.",
                    "O RTCP fornece evidência adicional de perda reportada pelo receptor.",
                    "Comparar a perda reportada pelo RTCP com a perda calculada a partir da sequência RTP e identificar a direção do relatório.")
            if m.get("sip_transaction_rtt_avg_ms") is not None and m["sip_transaction_rtt_avg_ms"] > 1000:
                self._add_anomaly(call, "medium", "calculated", "SIP_TRANSACTION_RTT",
                    f"RTT médio das transações SIP de {m['sip_transaction_rtt_avg_ms']:.0f} ms.",
                    "Pode indicar atraso de sinalização ou processamento elevado no caminho SIP.",
                    "Correlacionar RTT por método/CSeq com retransmissões, latência e capacidade de PBX/SBC/firewall.")
            if m.get("answered") and m.get("rtp", {}).get("first_ts") is not None:
                delay = m["rtp"].get("media_start_delay_s")
                if delay is not None and delay >= 0.5:
                    # Already represented as an anomaly for delays above 2s; this lower threshold
                    # is intentionally informational and does not duplicate the finding.
                    pass

            if m.get("final_status") in (488, 606):
                self._add_anomaly(call, "high", "high", "MEDIA_NEGOTIATION_FAILURE",
                    f"A transação INVITE terminou com código {m['final_status']}.",
                    "A chamada pode ter falhado por incompatibilidade de mídia ou política de terminação.",
                    "Comparar ofertas SDP, codecs e atributos de mídia nos dois lados.")
        macro["degraded_calls"] = sum(1 for c in calls.values() if c.anomalies)
        macro["critical_calls"] = sum(1 for c in calls.values() if any(a["severity"] == "high" for a in c.anomalies))
        sip_decoded = macro.get("protocol_inventory", {}).get("sip_packets", 0)
        if not calls and sip_decoded:
            macro["health"] = "INCONCLUSIVO"
            macro["health_reason"] = "TShark identificou pacotes SIP, porém nenhuma transação/Call-ID pôde ser reconstruída."
        else:
            macro["health"] = "CRÍTICO" if macro["critical_calls"] else ("ATENÇÃO" if macro["degraded_calls"] else "BOM")

    def _apply_call_state_and_score(self, call):
        """Derive a conservative call state and an application-specific health score.

        The state is reconstructed only from SIP evidence available in the capture.
        The score is a product metric (not an RFC/Wireshark standard): it starts at
        100 and deducts points for diagnosed anomalies, capped at zero.
        """
        m = call.metrics
        final = m.get("final_status")
        if m.get("cancelled"):
            state = "CANCELLED"
            state_reason = "CANCEL observado antes da conclusão normal da chamada."
        elif m.get("answered"):
            state = "COMPLETED" if m.get("bye") else "ESTABLISHED"
            state_reason = "200 OK do INVITE observado; BYE observado." if m.get("bye") else "200 OK do INVITE observado; encerramento SIP não observado."
        elif isinstance(final, int) and 400 <= final <= 699:
            state = "FAILED"
            state_reason = f"INVITE terminou com resposta final {final}."
        elif m.get("final_status") is not None:
            state = "TERMINATED"
            state_reason = f"Último código SIP observado: {final}."
        elif m.get("start") is not None:
            state = "INCOMPLETE"
            state_reason = "Há sinalização SIP, mas não foi possível determinar um estado final confiável."
        else:
            state = "UNKNOWN"
            state_reason = "Dados insuficientes para reconstrução do estado."

        deductions = {"high": 25, "medium": 12, "low": 5}
        score = max(0, 100 - sum(deductions.get(str(a.get("severity", "")).lower(), 0) for a in call.anomalies))
        if score >= 90:
            classification = "EXCELENTE"
        elif score >= 75:
            classification = "BOM"
        elif score >= 50:
            classification = "ATENÇÃO"
        else:
            classification = "CRÍTICO"
        m["call_state"] = state
        m["call_state_reason"] = state_reason
        m["anomaly_score"] = score
        m["anomaly_classification"] = classification

    def _call_dict(self, call):
        messages = sorted(call.messages, key=lambda m: m.ts)
        first = messages[0] if messages else None
        return {
            "call_id": call.call_id, "from": first.from_uri if first else "", "to": first.to_uri if first else "",
            "leg_call_ids": call.leg_call_ids or [call.call_id], "correlation": call.correlation or {"type": "single-leg", "confidence": "observed", "leg_count": 1},
            "legs": call.leg_details or [self._leg_detail(call)],
            "start": call.metrics.get("start"), "end": call.metrics.get("end"),
            "messages": [m.__dict__ for m in messages], "metrics": call.metrics,
            "timeline": call.metrics.get("timeline", []), "anomalies": call.anomalies,
        }
