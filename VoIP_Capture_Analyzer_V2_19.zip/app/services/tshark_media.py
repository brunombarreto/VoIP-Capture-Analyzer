# Copyright (c) 2026 Bruno Barreto
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

"""TShark-only media extraction.

The analyzer never parses the physical PCAP/PCAPNG container itself.
TShark/Wireshark remains responsible for packet dissection. This module
only interprets JSON/field output emitted by TShark.
"""
from __future__ import annotations

import asyncio
import json
import logging
import shutil
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def _find_fields(obj: Any, names: set[str]) -> list[Any]:
    out = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k in names:
                out.append(v)
            out.extend(_find_fields(v, names))
    elif isinstance(obj, list):
        for x in obj:
            out.extend(_find_fields(x, names))
    return out


async def _run_tshark(capture: str, display_filter: str, fields: list[str]) -> list[dict[str, Any]]:
    tshark = shutil.which("tshark") or "tshark"
    cmd = [tshark, "-n", "-r", capture, "-Y", display_filter,
           "-T", "json", "--disable-protocol", "tcp"]
    # Keep the command simple and portable. JSON already contains decoded fields.
    proc = await asyncio.create_subprocess_exec(
        *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await proc.communicate()
    if proc.returncode != 0:
        msg = stderr.decode("utf-8", "replace").strip()
        raise RuntimeError(f"TShark failed ({proc.returncode}): {msg}")
    if not stdout.strip():
        return []
    try:
        data = json.loads(stdout.decode("utf-8", "replace"))
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Invalid TShark JSON output: {exc}") from exc
    return data if isinstance(data, list) else []


async def extract_rtp_rtcp(capture: str, media_sip_rows=None):
    """Extract RTP/RTCP using TShark only.

    First asks the RTP/RTCP dissectors directly. If no RTP is decoded, derive
    media UDP ports from the already extracted SDP and ask TShark for UDP JSON,
    allowing the caller to inspect payloads without parsing the PCAP container.
    """
    try:
        rtp = await _run_tshark(capture, "rtp", [])
    except Exception as exc:
        logger.warning("TShark RTP dissector failed: %s", exc)
        rtp = []

    try:
        rtcp = await _run_tshark(capture, "rtcp", [])
    except Exception as exc:
        logger.warning("TShark RTCP dissector failed: %s", exc)
        rtcp = []

    # Return raw TShark records. Higher layers should normalize fields.
    if rtp or rtcp:
        logger.info("Media recovered from TShark dissectors: RTP=%d RTCP=%d", len(rtp), len(rtcp))
        return rtp, rtcp

    # No RTP dissector result: derive candidate media ports from SDP rows.
    ports: set[str] = set()
    for row in media_sip_rows or []:
        text = json.dumps(row, ensure_ascii=False)
        for m in __import__("re").finditer(r"(?:m=audio|media_port|rtp_port|udp_port)[^0-9]{0,30}([0-9]{2,5})", text, __import__("re").I):
            p = m.group(1)
            if 1024 <= int(p) <= 65535:
                ports.add(p)

    if not ports:
        logger.warning("No RTP/RTCP ports could be derived from SIP/SDP; no packet-container fallback will be used.")
        return [], []

    filt = " or ".join(f"udp.port == {p}" for p in sorted(ports))
    try:
        udp = await _run_tshark(capture, filt, [])
        logger.info("Media fallback recovered %d UDP frames from SDP-derived ports=%s", len(udp), ",".join(sorted(ports)))
        return udp, []
    except Exception as exc:
        logger.warning("TShark UDP media fallback failed: %s", exc)
        return [], []
