# Copyright (c) 2026 Bruno Barreto
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

from pydantic import BaseModel, Field
from typing import Any

class Progress(BaseModel):
    job_id: str
    percent: int = Field(ge=0, le=100)
    stage: str
    message: str
    status: str = "running"

class JobStatus(BaseModel):
    job_id: str
    filename: str
    status: str
    percent: int
    stage: str
    message: str
    error: str | None = None
    report: dict[str, Any] | None = None
