# Copyright (c) 2026 Bruno Barreto
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

from app.analyzers.engine import CaptureAnalyzer
from app.analyzers.models import Call, SipMessage


def test_call_state_completed_without_anomaly():
    c = Call("abc")
    c.messages = [
        SipMessage(1.0, "abc", method="INVITE", cseq="1", cseq_method="INVITE"),
        SipMessage(2.0, "abc", status=200, cseq="1", cseq_method="INVITE"),
        SipMessage(5.0, "abc", method="BYE", cseq="2", cseq_method="BYE"),
    ]
    c.metrics = {"answered": True, "bye": True, "cancelled": False, "final_status": 200, "start": 1.0}
    CaptureAnalyzer._apply_call_state_and_score(CaptureAnalyzer, c)
    assert c.metrics["call_state"] == "COMPLETED"
    assert c.metrics["anomaly_score"] == 100
    assert c.metrics["anomaly_classification"] == "EXCELENTE"


def test_call_state_failed_and_score_reduces_for_anomaly():
    c = Call("abc")
    c.metrics = {"answered": False, "bye": False, "cancelled": False, "final_status": 486, "start": 1.0}
    c.anomalies = [{"severity": "high"}, {"severity": "medium"}]
    CaptureAnalyzer._apply_call_state_and_score(CaptureAnalyzer, c)
    assert c.metrics["call_state"] == "FAILED"
    assert c.metrics["anomaly_score"] == 63
    assert c.metrics["anomaly_classification"] == "ATENÇÃO"


def test_v217_report_logo_asset_exists():
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    assert (root / "app" / "static" / "voip-capture-analyzer-logo.png").exists()
    assert (root / "app" / "static" / "voip-capture-analyzer-mark.png").exists()
    report = (root / "app" / "templates" / "report.html").read_text(encoding="utf-8")
    assert "static/voip-capture-analyzer-logo.png" in report
