# Copyright (c) 2026 Bruno Barreto
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

from app.analyzers.engine import CaptureAnalyzer
from app.analyzers.models import Call, SipMessage, RtpPacket


def test_correlated_timeline_marks_rtp_gap_and_ignores_control_methods():
    a = CaptureAnalyzer()
    call = Call("CALL-A")
    call.messages = [
        SipMessage(10.0, "CALL-A", method="INVITE", cseq="1", cseq_method="INVITE", src="10.0.0.1", dst="10.0.0.2"),
        SipMessage(11.0, "CALL-A", status=200, cseq="1", cseq_method="INVITE", src="10.0.0.2", dst="10.0.0.1"),
        SipMessage(15.0, "CALL-A", method="OPTIONS", cseq="2", cseq_method="OPTIONS", src="10.0.0.2", dst="10.0.0.1"),
        SipMessage(20.0, "CALL-A", method="BYE", cseq="3", cseq_method="BYE", src="10.0.0.2", dst="10.0.0.1"),
    ]
    call.rtp = [
        RtpPacket(11.1, "0x1", 1, 1, "8", "10.0.0.1", "10.0.0.2", "10000", "11000", size=172),
        RtpPacket(11.12, "0x1", 2, 161, "8", "10.0.0.1", "10.0.0.2", "10000", "11000", size=172),
        RtpPacket(13.5, "0x1", 3, 321, "8", "10.0.0.1", "10.0.0.2", "10000", "11000", size=172),
    ]
    a._metrics(call)
    timeline = call.metrics["timeline"]
    types = [e["type"] for e in timeline]
    assert "SIP_REQUEST" in types
    assert "SIP_RESPONSE" in types
    assert "RTP_START" in types
    assert "RTP_GAP_START" in types
    assert "RTP_GAP_END" in types
    assert all("OPTIONS" not in e["label"] for e in timeline)
    assert call.metrics["rtp_gap_count"] == 1
    assert abs(call.metrics["rtp_gap_max_s"] - 2.38) < 0.001
