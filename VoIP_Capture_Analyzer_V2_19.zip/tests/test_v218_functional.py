# Copyright (c) 2026 Bruno Barreto
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

from app.analyzers.engine import CaptureAnalyzer
from app.analyzers.models import Call, SipMessage, RtpPacket


def test_v218_sip_transaction_rtt():
    c = CaptureAnalyzer()
    msgs = [
        SipMessage(1.0, "abc", method="INVITE", cseq="1", cseq_method="INVITE", src="10.0.0.1", dst="10.0.0.2"),
        SipMessage(1.08, "abc", status=100, cseq="1", cseq_method="INVITE", src="10.0.0.2", dst="10.0.0.1"),
        SipMessage(2.0, "abc", status=200, cseq="1", cseq_method="INVITE", src="10.0.0.2", dst="10.0.0.1"),
    ]
    tx = c._sip_transaction_metrics(msgs)
    assert len(tx) == 1
    assert tx[0]["status"] == 100
    assert round(tx[0]["rtt_ms"], 1) == 80.0


def test_v218_sdp_rtp_consistency():
    c = CaptureAnalyzer()
    call = Call("abc")
    call.sdp = [{"sdp.connection_info.address": "10.0.0.10", "sdp.media.port": "18000", "sdp.media.type": "audio"}]
    call.rtp = [RtpPacket(2.0, "1", 1, 1, "8", "10.0.0.10", "10.0.0.20", "18000", "19000")]
    result = c._sdp_consistency(call)
    assert result["status"] == "CONSISTENT"


def test_v218_one_way_classification():
    c = CaptureAnalyzer()
    assert c._one_way_classification({"directions": []}) == "NO_RTP"
    assert c._one_way_classification({"directions": [{"duration_s": 10}]}) == "RTP_UNILATERAL"
    assert c._one_way_classification({"directions": [{"duration_s": 10}, {"duration_s": 10}]}) == "RTP_BIDIRECTIONAL"


def test_v219_rtp_bandwidth_metrics_are_exposed():
    c = CaptureAnalyzer()
    call = Call("abc")
    call.rtp = [
        RtpPacket(1.0, "1", 1, 1, "8", "10.0.0.1", "10.0.0.2", "10000", "20000", size=200),
        RtpPacket(1.02, "1", 2, 161, "8", "10.0.0.1", "10.0.0.2", "10000", "20000", size=200),
        RtpPacket(1.04, "1", 3, 321, "8", "10.0.0.1", "10.0.0.2", "10000", "20000", size=200),
    ]
    result = c._rtp_metrics(call.rtp)
    assert result["bitrate_kbps"] is not None
    assert result["pps"] > 0


def test_v219_footer_and_bandwidth_ui():
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    html = (root / "app" / "templates" / "index.html").read_text(encoding="utf-8")
    report = (root / "app" / "templates" / "report.html").read_text(encoding="utf-8")
    js = (root / "app" / "static" / "app.js").read_text(encoding="utf-8")
    assert 'id="licenseFooter"' in html
    assert 'VoIP Capture Analyzer V2.19' in html
    assert 'href="/LICENSE"' in report
    assert 'voip-capture-analyzer-mark.png' in report
    assert 'rtp_bandwidth' in report
    assert 'rtp_bandwidth' in js
