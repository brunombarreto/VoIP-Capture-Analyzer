# VoIP Capture Analyzer — V2.10

## Objetivo

A V2.10 evolui a correlação da V2.8.1 para representar uma chamada lógica quando a captura contém múltiplas pernas SIP, cenário comum em PABX/SBC/B2BUA.

## Principais mudanças

- Consolidação conservadora de Call-IDs diferentes que representam a mesma chamada B2BUA.
- Evidências da consolidação: mesmo From/To, sinalização em sentidos opostos, proximidade temporal e compatibilidade de portas SIP.
- Uma chamada lógica passa a contar como uma única tentativa no ASR, simultaneidade e demais KPIs.
- RTP observado nas diferentes pernas é consolidado na chamada lógica.
- Tratamento correto de INVITE inicial que recebe 401/407: o INVITE autenticado não é tratado como re-INVITE e o 200 OK de uma transação INVITE posterior pode responder pela mesma chamada.
- Encerramento considera o último BYE observado, importante quando as pernas de um B2BUA encerram em instantes diferentes.
- Relatórios PDF/DOCX exibem quantidade de pernas, Call-IDs e evidências da correlação.
- REGISTER e OPTIONS continuam visíveis como tráfego de controle, mas não entram como tentativas de chamada.

## Limites

A consolidação é deliberadamente conservadora. Ela não usa somente igualdade de From/To ou somente proximidade temporal; exige uma combinação forte de evidências para reduzir o risco de juntar chamadas paralelas.
