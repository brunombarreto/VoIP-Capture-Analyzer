# VoIP Capture Analyzer V2.10

## Objetivo

A V2.10 evolui a correlação introduzida na V2.10 para apresentar, além da chamada lógica consolidada, as **pernas físicas SIP/mídia** que compõem a chamada.

## Principais mudanças

- Preserva cada Call-ID como uma perna individual após a correlação B2BUA.
- Exibe por perna os endpoints de sinalização, quantidade de RTP, streams, perda e jitter.
- Exibe direções RTP com IP/porta de origem e destino, duração, quantidade de pacotes e payload types.
- Mantém REGISTER e OPTIONS fora das métricas de chamadas.
- Mantém autenticação 401/407 como parte do estabelecimento da mesma chamada.
- Mantém TShark como mecanismo primário de decodificação da captura.
- Mantém consolidação de RTP na chamada lógica para KPIs macro.
- Relatório HTML/PDF/DOCX passa a mostrar a visão lógica e a visão por perna.

## Interpretação

Uma chamada B2BUA pode possuir Call-IDs diferentes em cada lado. A chamada lógica continua sendo contabilizada uma única vez, enquanto as pernas permitem investigar assimetria de sinalização e mídia.

## Testes

```text
4 passed
```
