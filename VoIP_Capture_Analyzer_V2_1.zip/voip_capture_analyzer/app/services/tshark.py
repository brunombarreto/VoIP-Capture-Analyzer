import asyncio
import csv
import io
import json

_FIELD_CACHE: set[str] | None = None
from pathlib import Path
from typing import Iterable
from app.config import TSHARK_BIN, ANALYSIS_TIMEOUT_SECONDS

class TSharkError(RuntimeError):
    pass

async def run_tshark(args: list[str], timeout: int = ANALYSIS_TIMEOUT_SECONDS) -> tuple[str, str]:
    try:
        proc = await asyncio.create_subprocess_exec(
            TSHARK_BIN, *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except FileNotFoundError as exc:
        raise TSharkError(f"TShark não encontrado: {TSHARK_BIN}") from exc
    try:
        out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError as exc:
        proc.kill()
        await proc.wait()
        raise TSharkError(f"TShark excedeu o tempo limite de {timeout}s") from exc
    stdout = out.decode(errors="replace")
    stderr = err.decode(errors="replace")
    if proc.returncode != 0:
        raise TSharkError(stderr[-8000:] or f"TShark retornou código {proc.returncode}")
    return stdout, stderr

async def check_tshark() -> str:
    out, _ = await run_tshark(["--version"], timeout=20)
    return out.splitlines()[0] if out else "unknown"


async def available_fields() -> set[str]:
    global _FIELD_CACHE
    if _FIELD_CACHE is not None:
        return _FIELD_CACHE
    out, _ = await run_tshark(["-G", "fields"], timeout=60)
    fields = set()
    for line in out.splitlines():
        parts = line.split("\t")
        if len(parts) >= 2 and parts[0] == "F":
            fields.add(parts[1])
    _FIELD_CACHE = fields
    return fields

async def fields(capture: Path, display_filter: str, field_list: Iterable[str], occurrence: str = "f") -> list[dict[str, str]]:
    available = await available_fields()
    selected = [field for field in field_list if field in available]
    if not selected:
        return []
    args = [
        "-n", "-r", str(capture), "-Y", display_filter,
        "-T", "fields", "-E", "header=y", "-E", "separator=\\t",
        "-E", "quote=d", "-E", f"occurrence={occurrence}", "-E", "aggregator=;",
    ]
    for field in selected:
        args += ["-e", field]
    out, _ = await run_tshark(args)
    if not out.strip():
        return []
    reader = csv.DictReader(io.StringIO(out), delimiter="\t", quotechar='"')
    return [dict(row) for row in reader]

async def capture_info(capture: Path) -> dict:
    out, _ = await run_tshark([
        "-n", "-r", str(capture), "-T", "fields",
        "-e", "frame.number", "-e", "frame.time_epoch", "-e", "frame.len",
    ], timeout=300)
    first_ts = last_ts = None
    packets = bytes_total = 0
    for line in out.splitlines():
        parts = line.split("\t")
        if len(parts) < 2:
            continue
        try:
            ts = float(parts[1])
        except (TypeError, ValueError):
            continue
        try:
            size = int(parts[2]) if len(parts) > 2 and parts[2] else 0
        except (TypeError, ValueError):
            size = 0
        first_ts = ts if first_ts is None else first_ts
        last_ts = ts
        packets += 1
        bytes_total += size
    duration = max((last_ts - first_ts) if first_ts is not None and last_ts is not None else 0.0, 0.0)
    return {
        "packets": packets,
        "bytes": bytes_total,
        "first_ts": first_ts,
        "last_ts": last_ts,
        "duration": duration,
    }
