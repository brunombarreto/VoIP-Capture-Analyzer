from datetime import datetime
from io import BytesIO
import base64
from pathlib import Path
from jinja2 import Environment, FileSystemLoader, select_autoescape
from docx import Document
from docx.shared import Inches, Pt
from weasyprint import HTML
from app.config import REPORT_DIR

TEMPLATE_DIR = Path(__file__).resolve().parent.parent / "templates"

def fmt(v, suffix="", decimals=2):
    if v is None:
        return "N/A"
    if isinstance(v, float):
        return f"{v:.{decimals}f}{suffix}"
    return f"{v}{suffix}"

def build_context(data, charts, filename):
    return {
        "data": data, "charts": charts, "filename": filename,
        "generated": datetime.now().astimezone().strftime("%d/%m/%Y %H:%M:%S"), "fmt": fmt,
    }

def render_html(data, charts, filename):
    env = Environment(loader=FileSystemLoader(str(TEMPLATE_DIR)), autoescape=select_autoescape(["html", "xml"]))
    return env.get_template("report.html").render(**build_context(data, charts, filename))

def export_pdf(html, job_id):
    path = REPORT_DIR / f"{job_id}.pdf"
    HTML(string=html, base_url=str(TEMPLATE_DIR.parent)).write_pdf(str(path))
    return path

def export_docx(data, charts, filename, job_id):
    path = REPORT_DIR / f"{job_id}.docx"
    doc = Document()
    sec = doc.sections[0]
    sec.top_margin = Inches(.55); sec.bottom_margin = Inches(.55); sec.left_margin = Inches(.65); sec.right_margin = Inches(.65)
    styles = doc.styles
    styles["Normal"].font.name = "Arial"; styles["Normal"].font.size = Pt(9.5)
    doc.add_heading("VoIP Capture Analyzer", 0)
    doc.add_paragraph("Relatório Técnico Profissional de Análise de Tráfego SIP e RTP")
    doc.add_paragraph(f"Captura: {filename} | Gerado em: {datetime.now().astimezone():%d/%m/%Y %H:%M:%S}")

    doc.add_heading("1. Resumo Executivo", 1)
    doc.add_paragraph(f"Saúde geral: {data['macro'].get('health','N/A')}")
    t = doc.add_table(rows=1, cols=3); t.style = "Light Shading Accent 1"
    for i,h in enumerate(["KPI","Valor","Interpretação"]): t.rows[0].cells[i].text = h
    rows = [
        ("Chamadas", fmt(data['macro'].get('calls')), "Tentativas com INVITE inicial"),
        ("ASR", fmt(data['macro'].get('asr_pct'), "%"), "Chamadas com 200 OK do INVITE inicial"),
        ("PDD médio", fmt(data['macro'].get('pdd_avg_s'), " s"), "INVITE até 200 OK"),
        ("Jitter médio", fmt(data['macro'].get('jitter_avg_ms'), " ms"), "Jitter RTP calculado quando clock rate disponível"),
        ("Perda média", fmt(data['macro'].get('loss_avg_pct'), "%"), "Perda estimada por sequência RTP"),
        ("RTP unilateral", fmt(data['macro'].get('one_way_calls')), "Chamadas com fluxo observado em um único sentido"),
    ]
    for row in rows:
        cells = t.add_row().cells
        for i,v in enumerate(row): cells[i].text = v

    doc.add_heading("2. Metodologia", 1)
    doc.add_paragraph("A análise utiliza TShark em subprocessos assíncronos e separa evidências observadas, métricas calculadas e inferências diagnósticas. Métricas que não podem ser obtidas com segurança são apresentadas como N/A.")
    doc.add_paragraph("Limiar operacional: PDD > 3s, jitter > 30ms e perda RTP > 1% geram alerta. Esses limites são critérios operacionais da aplicação, não limites universais de todos os ambientes.")

    doc.add_heading("3. Análise Macro", 1)
    cap = data["capture"]
    doc.add_paragraph(f"Pacotes: {cap.get('packets',0)} | Bytes: {cap.get('bytes',0)} | Duração: {fmt(cap.get('duration'),' s')} | PPS: {fmt(data['macro'].get('pps'))} | Bitrate: {fmt((data['macro'].get('bps') or 0)/1000,' kbps')}")
    chart_titles = [("response_codes","Códigos SIP"),("pdd","PDD"),("loss_jitter","Perda × Jitter"),("jitter_calls","Jitter por chamada"),("loss_calls","Perda por chamada"),("codecs","Codecs"),("concurrency","Chamadas simultâneas"),("quality_matrix","Matriz de qualidade"),("sip_timing","Tempos SIP")]
    for name,title in chart_titles:
        if name in charts:
            doc.add_heading(title, 2)
            raw = base64.b64decode(charts[name].split(",",1)[1])
            doc.add_picture(BytesIO(raw), width=Inches(6.5))

    doc.add_heading("4. Diagnóstico Consolidado", 1)
    doc.add_paragraph(f"Chamadas com anomalias: {data['macro'].get('degraded_calls',0)} | Chamadas críticas: {data['macro'].get('critical_calls',0)} | Pico de simultaneidade: {data['macro'].get('concurrent_peak',0)}")

    doc.add_heading("5. Análise Micro", 1)
    for index, call in enumerate(data["calls"], 1):
        doc.add_heading(f"5.{index}. {call['call_id']}", 2)
        m = call["metrics"]; r = m["rtp"]
        doc.add_paragraph(f"From: {call['from'] or 'N/A'} | To: {call['to'] or 'N/A'} | Status: {m.get('final_status') or 'N/A'}")
        doc.add_paragraph(f"Duração: {fmt(m.get('duration'),' s')} | Conversação: {fmt(m.get('conversation_duration'),' s')} | PDD: {fmt(m.get('pdd_to_answer'),' s')} | SIP messages: {m.get('sip_messages',0)}")
        doc.add_paragraph(f"RTP: {r.get('packets',0)} pacotes | Streams: {r.get('streams',0)} | Perda: {fmt(r.get('loss_pct'),'%')} | Jitter: {fmt(r.get('jitter_ms'),' ms')} | Jitter p95: {fmt(r.get('jitter_p95_ms'),' ms')}")
        if call["anomalies"]:
            for anomaly in call["anomalies"]:
                doc.add_paragraph(f"[{anomaly['severity'].upper()} / {anomaly['confidence']}] {anomaly['finding']} Impacto: {anomaly['impact']} Recomendação: {anomaly['recommendation']}", style="List Bullet")
        else:
            doc.add_paragraph("Não foram detectadas anomalias segundo as regras operacionais implementadas.")

    doc.add_heading("6. Recomendações", 1)
    doc.add_paragraph("Priorizar chamadas com perda RTP, RTP unilateral, ausência de mídia após atendimento, retransmissões SIP e PDD elevado. Correlacionar os timestamps com interfaces de rede, SBC/PBX, firewall, QoS/DSCP e utilização de enlaces antes de afirmar causa raiz definitiva.")
    doc.add_heading("7. Limitações e Reprodutibilidade", 1)
    doc.add_paragraph("As métricas representam o ponto de captura. Uma captura unilateral não prova, sozinha, a experiência do endpoint remoto. RTP não associado a Call-ID é tratado conservadoramente. MOS/NER não são inventados quando não há dados suficientes. Os campos TShark dependem da versão do Wireshark instalada.")
    doc.save(path)
    return path
