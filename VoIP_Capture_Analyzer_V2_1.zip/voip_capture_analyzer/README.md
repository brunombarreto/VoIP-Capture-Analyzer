# VoIP Capture Analyzer V2

Dashboard Web para análise de capturas `.cap`, `.pcap` e `.pcapng`, com FastAPI, WebSockets, TShark, gráficos e exportação PDF/DOCX.

## V2 — correção e robustez do frontend

Esta versão corrige a integração Alpine.js que fazia o navegador apresentar:

```text
Alpine Expression Error: pick is not defined
Uncaught ReferenceError: pick is not defined
```

O componente agora é registrado de forma explícita com `Alpine.data('app', ...)` dentro do evento `alpine:init`, e a página utiliza `x-data="app"`. Isso evita depender da resolução de uma função global `app()` pelo avaliador de expressões do Alpine.

Também foram adicionados:

- tratamento de erros no upload;
- validação da extensão no navegador;
- mensagens de progresso mais claras;
- tratamento de falha do WebSocket;
- fallback de consulta do status do job;
- tratamento de respostas HTTP não-JSON;
- `x-cloak` para evitar flashes de componentes ocultos;
- teste configurado para importar o pacote `app` diretamente com pytest.

## Execução

```bash
python3.11 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# confirme a instalação do TShark
tshark --version

IP=$(hostname -I | awk '{print $1}')
uvicorn app.main:app --host "$IP" --port 8000
```

Acesse:

```text
http://IP_DO_SERVIDOR:8000
```

## Testes

```bash
pytest -q
```

## Docker

```bash
docker compose up --build
```

## Observação

O TShark deve estar instalado no host/container e disponível no `PATH`, ou configurado pela variável `TSHARK_BIN`.
