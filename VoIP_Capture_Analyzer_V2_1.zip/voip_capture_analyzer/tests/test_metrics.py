from app.analyzers.engine import percentile


def test_percentile():
    assert percentile([1, 2, 3, 4, 5], 95) == 4.8


def test_empty_percentile():
    assert percentile([], 95) is None
