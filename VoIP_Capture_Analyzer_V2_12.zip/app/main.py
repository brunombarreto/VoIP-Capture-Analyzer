# Copyright (c) 2026 Bruno Barreto
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

import asyncio
import logging
import uuid
import zipfile
from pathlib import Path

from fastapi import FastAPI, UploadFile, File, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, FileResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.requests import Request

from app.config import BASE_DIR, UPLOAD_DIR, REPORT_DIR, MAX_UPLOAD_MB, VERSION
from app.services.jobs import JobManager
from app.services.tshark import check_tshark
from app.analyzers.engine import CaptureAnalyzer
from app.services.charts import make_charts
from app.services.report import render_html, export_pdf, export_docx

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
logger = logging.getLogger("voip-capture-analyzer")

app = FastAPI(title="VoIP Capture Analyzer", version=VERSION, docs_url="/docs", redoc_url="/redoc")
templates = Jinja2Templates(directory=str(Path(__file__).parent / "templates"))
app.mount("/static", StaticFiles(directory=str(Path(__file__).parent / "static")), name="static")
jobs = JobManager()
ALLOWED = {".cap", ".pcap", ".pcapng"}

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse(request=request, name="index.html", context={"version": VERSION})

@app.get("/api/health")
async def health():
    try:
        version = await check_tshark()
        return {"ok": True, "version": version}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}

@app.post("/api/analyze")
async def analyze(file: UploadFile = File(...)):
    filename = file.filename or "capture.pcap"
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED:
        raise HTTPException(400, "Formato não suportado. Use .cap, .pcap ou .pcapng.")
    job_id = uuid.uuid4().hex
    await jobs.create(job_id, filename)
    target = UPLOAD_DIR / f"{job_id}{ext}"
    size = 0
    try:
        with target.open("wb") as output:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > MAX_UPLOAD_MB * 1024 * 1024:
                    target.unlink(missing_ok=True)
                    raise HTTPException(413, f"Arquivo excede o limite de {MAX_UPLOAD_MB} MB.")
                output.write(chunk)
    finally:
        await file.close()
    asyncio.create_task(run_job(job_id, target))
    return {"job_id": job_id, "status": "queued"}

async def run_job(job_id: str, capture: Path):
    try:
        async def progress(percent, stage, message):
            await jobs.update(job_id, percent, stage, message)
        analyzer = CaptureAnalyzer(progress)
        data = await analyzer.analyze(capture)
        await jobs.update(job_id, 94, "charts", "Gerando gráficos técnicos...")
        charts = make_charts(data, job_id)
        await jobs.update(job_id, 97, "report", "Montando relatório executivo e técnico...")
        original_filename = jobs.jobs[job_id].filename
        html = render_html(data, charts, original_filename)
        pdf = export_pdf(html, job_id)
        docx = export_docx(data, charts, original_filename, job_id)
        report = {"data": data, "charts": charts, "files": {"pdf": pdf.name, "docx": docx.name}}
        jobs.jobs[job_id].report = report
        await jobs.update(job_id, 100, "completed", "Análise concluída.", status="completed", report=report)
    except Exception as exc:
        logger.exception("Job %s failed", job_id)
        jobs.jobs[job_id].error = str(exc)
        await jobs.update(job_id, 100, "error", "Falha durante a análise.", status="error", error=str(exc))

@app.get("/api/jobs/{job_id}")
async def get_job(job_id: str):
    job = jobs.jobs.get(job_id)
    if not job:
        raise HTTPException(404, "Job não encontrado")
    return {
        "job_id": job.job_id, "filename": job.filename, "status": job.status,
        "percent": job.percent, "stage": job.stage, "message": job.message,
        "error": job.error, "report": job.report,
    }

@app.get("/LICENSE", response_class=PlainTextResponse)
async def license_file():
    return (BASE_DIR / "LICENSE").read_text(encoding="utf-8")

@app.get("/CONTRIBUTING.md", response_class=PlainTextResponse)
async def contributing_file():
    return (BASE_DIR / "CONTRIBUTING.md").read_text(encoding="utf-8")

@app.get("/download/source")
async def download_source():
    """Build and return a clean source archive for the current application version."""
    archive = REPORT_DIR / f"VoIP_Capture_Analyzer_V{VERSION.replace('.', '_')}.zip"
    skip_dirs = {".git", ".venv", "__pycache__", ".pytest_cache", "data"}
    skip_names = {archive.name}
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in BASE_DIR.rglob("*"):
            if not path.is_file():
                continue
            rel = path.relative_to(BASE_DIR)
            if any(part in skip_dirs for part in rel.parts) or path.name in skip_names:
                continue
            zf.write(path, rel.as_posix())
    return FileResponse(archive, filename=archive.name, media_type="application/zip")

@app.get("/api/jobs/{job_id}/download/{kind}")
async def download(job_id: str, kind: str, mode: str = "download"):
    if kind not in {"pdf", "docx"}:
        raise HTTPException(400, "Formato inválido")
    path = REPORT_DIR / f"{job_id}.{kind}"
    if not path.exists():
        raise HTTPException(404, "Relatório ainda não disponível")
    disposition = "inline" if mode == "open" else "attachment"
    media_type = "application/pdf" if kind == "pdf" else "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    return FileResponse(path, filename=f"voip_capture_analyzer_{job_id}.{kind}", media_type=media_type, content_disposition_type=disposition)

@app.websocket("/ws/{job_id}")
async def websocket(ws: WebSocket, job_id: str):
    await ws.accept()
    if job_id not in jobs.jobs:
        await ws.send_json({"status": "error", "error": "Job não encontrado"})
        await ws.close()
        return
    queue = await jobs.subscribe(job_id)
    try:
        while True:
            message = await queue.get()
            await ws.send_json(message)
            if message.get("status") in {"completed", "error"}:
                break
    except WebSocketDisconnect:
        pass
    finally:
        await jobs.unsubscribe(job_id, queue)
