# VoIP Capture Analyzer

Web dashboard for static `.cap`, `.pcap` and `.pcapng` captures. It uses FastAPI/Uvicorn, asyncio subprocesses and `tshark` to extract SIP/RTP/RTCP evidence, calculates macro/micro KPIs, generates technical charts, and exports HTML-derived PDF and styled DOCX reports.

## Requirements

- Python 3.11+
- Wireshark/TShark installed and available as `tshark` in PATH
- Native libraries required by WeasyPrint on some Linux distributions

## Run

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell
# .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

Open `http://localhost:8000`.

## TShark validation

```bash
tshark --version
tshark -G fields | grep -E 'sip\.|rtp\.|rtcp\.' | head
```

## Architecture

```text
Browser
  │ HTTP upload / WebSocket progress
  ▼
FastAPI
  ├── Job Manager (async)
  ├── Capture Analyzer
  │     ├── metadata pass
  │     ├── SIP pass
  │     ├── RTP pass
  │     └── RTCP / expert pass
  ├── KPI + diagnosis engine
  ├── Chart engine (Matplotlib)
  └── Report engine
        ├── HTML
        ├── PDF / WeasyPrint
        └── DOCX / python-docx
```

## Design principles

- Facts directly observed in packets are separated from calculated metrics and inferred diagnoses.
- Metrics unavailable from the capture are reported as `N/A` rather than invented.
- Diagnosis rules produce severity and confidence.
- The report contains executive and technical views, per-call details, evidence, methodology, limitations and reproducibility commands.
- File processing is isolated in a per-job workspace.

## Production notes

This is a complete runnable reference implementation, not a multi-tenant SaaS deployment. For production use, add authentication, quotas, antivirus/content scanning, retention policies, object storage, a queue such as Celery/RQ/Arq, database persistence, reverse-proxy limits, and container sandboxing for untrusted PCAPs.
