import asyncio
from dataclasses import dataclass, field
from typing import Any

@dataclass
class Job:
    job_id: str
    filename: str
    status: str = "queued"
    percent: int = 0
    stage: str = "queued"
    message: str = "Aguardando processamento"
    error: str | None = None
    report: dict[str, Any] | None = None
    subscribers: set[asyncio.Queue] = field(default_factory=set)

class JobManager:
    def __init__(self):
        self.jobs: dict[str, Job] = {}
        self.lock = asyncio.Lock()

    async def create(self, job_id: str, filename: str) -> Job:
        async with self.lock:
            job = Job(job_id=job_id, filename=filename)
            self.jobs[job_id] = job
            return job

    async def update(self, job_id: str, percent: int, stage: str, message: str, status: str = "running", **extra):
        job = self.jobs[job_id]
        job.percent, job.stage, job.message, job.status = percent, stage, message, status
        for q in list(job.subscribers):
            await q.put({"job_id": job_id, "percent": percent, "stage": stage, "message": message, "status": status, **extra})

    async def subscribe(self, job_id: str):
        q = asyncio.Queue()
        job = self.jobs[job_id]
        job.subscribers.add(q)
        await q.put({"job_id": job_id, "percent": job.percent, "stage": job.stage, "message": job.message, "status": job.status})
        return q

    async def unsubscribe(self, job_id: str, q: asyncio.Queue):
        job = self.jobs.get(job_id)
        if job:
            job.subscribers.discard(q)
