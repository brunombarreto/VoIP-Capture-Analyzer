import asyncio
import csv
import io
import json
import os
from pathlib import Path
from typing import Iterable
from app.config import TSHARK_BIN

class TSharkError(RuntimeError):
    pass

async def run_tshark(args: list[str], timeout: int = 900) -> tuple[str, str]:
    proc = await asyncio.create_subprocess_exec(
        TSHARK_BIN, *args,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        proc.kill()
        await proc.wait()
        raise TSharkError("TShark excedeu o tempo limite")
    if proc.returncode != 0:
        raise TSharkError(err.decode(errors="replace")[-5000:])
    return out.decode(errors="replace"), err.decode(errors="replace")

async def check_tshark() -> str:
    out, _ = await run_tshark(["--version"], timeout=20)
    return out.splitlines()[0] if out else "unknown"

async def fields(capture: Path, display_filter: str, field_list: Iterable[str]) -> list[dict[str, str]]:
    args = ["-n", "-r", str(capture), "-Y", display_filter, "-T", "fields", "-E", "header=y", "-E", "separator=\\t", "-E", "quote=d", "-E", "occurrence=f"]
    for f in field_list:
        args += ["-e", f]
    out, _ = await run_tshark(args)
    reader = csv.DictReader(io.StringIO(out), delimiter="\t", quotechar='"')
    return [dict(row) for row in reader]

async def metadata(capture: Path) -> dict:
    args = ["-n", "-r", str(capture), "-T", "jsonraw", "-c", "1"]
    try:
        out, _ = await run_tshark(args, timeout=60)
        first = json.loads(out)[0] if out.strip() else {}
        return first
    except Exception:
        return {}

async def capture_info(capture: Path) -> dict:
    out, _ = await run_tshark(["-n", "-r", str(capture), "-T", "fields", "-e", "frame.time_epoch", "-e", "frame.len"], timeout=120)
    first_ts = last_ts = None
    packets = bytes_total = 0
    for line in out.splitlines():
        parts = line.split("\t")
        if not parts: continue
        try: ts = float(parts[0])
        except Exception: continue
        try: size = int(parts[1]) if len(parts) > 1 and parts[1] else 0
        except Exception: size = 0
        first_ts = ts if first_ts is None else first_ts
        last_ts = ts
        packets += 1
        bytes_total += size
    duration = (last_ts - first_ts) if first_ts is not None and last_ts is not None else 0
    return {"packets": packets, "bytes": bytes_total, "first_ts": first_ts, "last_ts": last_ts, "duration": duration}
