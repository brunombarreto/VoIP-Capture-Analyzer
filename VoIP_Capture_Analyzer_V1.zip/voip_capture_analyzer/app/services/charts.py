import base64, io
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def img_data(fig):
    b=io.BytesIO(); fig.tight_layout(); fig.savefig(b,format="png",dpi=150,bbox_inches="tight"); plt.close(fig)
    return "data:image/png;base64,"+base64.b64encode(b.getvalue()).decode()

def make_charts(data):
    macro=data["macro"]; calls=data["calls"]
    charts={}
    # Response codes
    codes=macro.get("response_codes",{})
    fig,ax=plt.subplots(figsize=(7,4));
    if codes: ax.bar(list(codes),list(codes.values()))
    ax.set_title("Distribuição de códigos de resposta SIP"); ax.set_xlabel("Código"); ax.set_ylabel("Chamadas"); charts["response_codes"]=img_data(fig)
    # Quality scatter
    xs=[]; ys=[]; labels=[]
    for c in calls:
        x=c["metrics"]["rtp"].get("loss_pct"); y=c["metrics"]["rtp"].get("jitter_ms")
        if x is not None and y is not None: xs.append(x); ys.append(y); labels.append(c["call_id"][:12])
    fig,ax=plt.subplots(figsize=(7,4));
    if xs: ax.scatter(xs,ys,alpha=.7)
    ax.set_title("Perda RTP × Jitter"); ax.set_xlabel("Perda estimada (%)"); ax.set_ylabel("Jitter/variação de chegada (ms)"); charts["loss_jitter"]=img_data(fig)
    # PDD
    vals=[c["metrics"].get("pdd_to_answer") for c in calls if c["metrics"].get("pdd_to_answer") is not None]
    fig,ax=plt.subplots(figsize=(7,4));
    if vals: ax.hist(vals,bins=min(12,max(4,len(vals))))
    ax.set_title("Distribuição de PDD até atendimento"); ax.set_xlabel("Segundos"); ax.set_ylabel("Chamadas"); charts["pdd"]=img_data(fig)
    # Jitter per call
    labels=[]; vals=[]
    for c in calls:
        v=c["metrics"]["rtp"].get("jitter_ms")
        if v is not None: labels.append(c["call_id"][:10]); vals.append(v)
    fig,ax=plt.subplots(figsize=(9,4));
    if vals: ax.bar(labels,vals); ax.tick_params(axis="x",rotation=60)
    ax.set_title("Jitter por chamada"); ax.set_ylabel("ms"); charts["jitter_calls"]=img_data(fig)
    # Loss per call
    labels=[]; vals=[]
    for c in calls:
        v=c["metrics"]["rtp"].get("loss_pct")
        if v is not None: labels.append(c["call_id"][:10]); vals.append(v)
    fig,ax=plt.subplots(figsize=(9,4));
    if vals: ax.bar(labels,vals); ax.tick_params(axis="x",rotation=60)
    ax.set_title("Perda RTP por chamada"); ax.set_ylabel("% estimado"); charts["loss_calls"]=img_data(fig)
    # Codecs
    codecs=macro.get("codecs",{})
    fig,ax=plt.subplots(figsize=(7,4));
    if codecs: ax.bar(list(codecs)[:15],list(codecs.values())[:15]); ax.tick_params(axis="x",rotation=45)
    ax.set_title("Distribuição de codecs / payloads SDP"); ax.set_ylabel("Ocorrências"); charts["codecs"]=img_data(fig)
    return charts
