from datetime import datetime, timezone
from io import BytesIO
import base64
from pathlib import Path
from jinja2 import Environment, FileSystemLoader, select_autoescape
from docx import Document
from docx.shared import Inches, Pt
from weasyprint import HTML
from app.config import REPORT_DIR

TEMPLATE_DIR=Path(__file__).resolve().parent.parent/"templates"

def fmt(v, suffix="", decimals=2):
    if v is None: return "N/A"
    if isinstance(v,float): return f"{v:.{decimals}f}{suffix}"
    return f"{v}{suffix}"

def build_context(data, charts, filename):
    return {"data":data,"charts":charts,"filename":filename,"generated":datetime.now(timezone.utc).astimezone().strftime("%d/%m/%Y %H:%M:%S"),"fmt":fmt}

def render_html(data, charts, filename):
    env=Environment(loader=FileSystemLoader(str(TEMPLATE_DIR)),autoescape=select_autoescape(["html","xml"]))
    return env.get_template("report.html").render(**build_context(data,charts,filename))

def export_pdf(html, job_id):
    path=REPORT_DIR/f"{job_id}.pdf"; HTML(string=html,base_url=str(TEMPLATE_DIR.parent)).write_pdf(str(path)); return path

def export_docx(data, charts, filename, job_id):
    path=REPORT_DIR/f"{job_id}.docx"; d=Document(); sec=d.sections[0]; sec.top_margin=Inches(.55); sec.bottom_margin=Inches(.55)
    d.add_heading("VoIP Capture Analyzer",0); d.add_paragraph("Relatório Técnico Profissional de Análise SIP/RTP")
    d.add_paragraph(f"Captura: {filename} | Gerado em: {datetime.now().astimezone():%d/%m/%Y %H:%M:%S}")
    d.add_heading("1. Resumo Executivo",1); d.add_paragraph(f"Saúde geral: {data['macro'].get('health','N/A')}")
    t=d.add_table(rows=1, cols=3); t.style="Light Shading Accent 1"
    for i,h in enumerate(["KPI","Valor","Interpretação"]): t.rows[0].cells[i].text=h
    rows=[("Chamadas",fmt(data['macro'].get('calls')),"Tentativas identificadas"),("ASR",fmt(data['macro'].get('asr_pct'),"%"),"Chamadas com 200 OK de INVITE"),("PDD médio",fmt(data['macro'].get('pdd_avg_s')," s"),"INVITE até 200 OK"),("Jitter médio",fmt(data['macro'].get('jitter_avg_ms')," ms"),"Métrica/estimativa baseada no tráfego RTP observado"),("Perda média",fmt(data['macro'].get('loss_avg_pct'),"%"),"Perda estimada por sequência RTP")]
    for row in rows:
        cells=t.add_row().cells
        for i,v in enumerate(row): cells[i].text=v
    d.add_heading("2. Metodologia e Limitações",1); d.add_paragraph("Os fatos observados foram separados de métricas calculadas e inferências diagnósticas. Métricas indisponíveis no PCAP são apresentadas como N/A. A análise RTP é limitada ao ponto de captura e à identificação dos streams realizada pelo TShark.")
    d.add_heading("3. Análise Macro",1)
    for name,title in [("response_codes","Códigos SIP"),("pdd","PDD"),("loss_jitter","Perda × Jitter"),("jitter_calls","Jitter por chamada"),("loss_calls","Perda por chamada"),("codecs","Codecs")]:
        if name in charts:
            d.add_heading(title,2)
            raw=base64.b64decode(charts[name].split(",",1)[1])
            d.add_picture(BytesIO(raw), width=Inches(6.5))
    d.add_heading("4. Análise Micro",1)
    for c in data['calls']:
        d.add_heading(c['call_id'],2); d.add_paragraph(f"From: {c['from']} | To: {c['to']}")
        m=c['metrics']; r=m['rtp']; d.add_paragraph(f"Duração: {fmt(m.get('duration'),' s')} | PDD: {fmt(m.get('pdd_to_answer'),' s')} | RTP: {r.get('packets',0)} pacotes | Perda: {fmt(r.get('loss_pct'),'%')} | Jitter: {fmt(r.get('jitter_ms'),' ms')}")
        for a in c['anomalies']: d.add_paragraph(f"[{a['severity'].upper()} / {a['confidence']}] {a['finding']} Recomendação: {a['recommendation']}", style="List Bullet")
    d.add_heading("5. Reprodutibilidade",1); d.add_paragraph("A análise utiliza TShark com filtros SIP, SDP, RTP e RTCP. Os comandos e filtros podem ser reproduzidos no ambiente de análise, desde que os mesmos campos estejam disponíveis na versão instalada do Wireshark/TShark.")
    d.save(path); return path
