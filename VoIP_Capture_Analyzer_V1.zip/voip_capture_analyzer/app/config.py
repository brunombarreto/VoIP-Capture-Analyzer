from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = DATA_DIR / "uploads"
REPORT_DIR = DATA_DIR / "reports"
CHART_DIR = DATA_DIR / "charts"
for p in (UPLOAD_DIR, REPORT_DIR, CHART_DIR):
    p.mkdir(parents=True, exist_ok=True)

TSHARK_BIN = os.getenv("TSHARK_BIN", "tshark")
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "500"))
RETENTION_HOURS = int(os.getenv("RETENTION_HOURS", "24"))
