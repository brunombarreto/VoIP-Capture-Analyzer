import math
import statistics
from collections import Counter, defaultdict
from pathlib import Path
from app.services import tshark
from .models import Call, SipMessage, RtpPacket

SIP_FIELDS = [
    "frame.number", "frame.time_epoch", "ip.src", "ipv6.src", "ip.dst", "ipv6.dst",
    "udp.srcport", "udp.dstport", "tcp.srcport", "tcp.dstport", "sip.Call-ID",
    "sip.Method", "sip.Status-Code", "sip.CSeq.seq", "sip.CSeq.method", "sip.from.uri",
    "sip.to.uri", "sip.User-Agent", "sip.Server", "sip.Reason", "sip.request_line"
]
RTP_FIELDS = [
    "frame.number", "frame.time_epoch", "ip.src", "ipv6.src", "ip.dst", "ipv6.dst",
    "udp.srcport", "udp.dstport", "rtp.ssrc", "rtp.seq", "rtp.timestamp", "rtp.p_type"
]
SDP_FIELDS = [
    "frame.number", "frame.time_epoch", "sip.Call-ID", "sdp.connection_info.address",
    "sdp.media.port", "sdp.media.type", "sdp.media.format", "sdp.media.format_specific_parameter",
    "sdp.media.attributes", "sdp.owner.address"
]
RTCP_FIELDS = [
    "frame.number", "frame.time_epoch", "ip.src", "ip.dst", "udp.srcport", "udp.dstport",
    "rtcp.ssrc", "rtcp.cumulative.lost", "rtcp.fraction.lost", "rtcp.jitter", "rtcp.rtt"
]


def ffloat(v, default=None):
    try: return float(v)
    except Exception: return default

def fint(v, default=None):
    try: return int(v, 0) if isinstance(v, str) and v.startswith("0x") else int(v)
    except Exception: return default

def ip(row, key): return row.get(f"ip.{key}") or row.get(f"ipv6.{key}") or ""
def port(row, key): return row.get(f"udp.{key}port") or row.get(f"tcp.{key}port") or ""

def percentile(values, p):
    vals = sorted(v for v in values if v is not None)
    if not vals: return None
    if len(vals) == 1: return vals[0]
    k = (len(vals)-1) * p/100
    lo, hi = math.floor(k), math.ceil(k)
    if lo == hi: return vals[lo]
    return vals[lo] + (vals[hi]-vals[lo])*(k-lo)

class CaptureAnalyzer:
    def __init__(self, progress_cb=None):
        self.progress_cb = progress_cb

    async def progress(self, pct, stage, message):
        if self.progress_cb: await self.progress_cb(pct, stage, message)

    async def analyze(self, capture: Path) -> dict:
        await self.progress(5, "metadata", "Lendo metadados e volumetria da captura...")
        info = await tshark.capture_info(capture)
        await self.progress(15, "sip", "Extraindo sinalização SIP...")
        sip_rows = await tshark.fields(capture, "sip", SIP_FIELDS)
        await self.progress(32, "sdp", "Extraindo sessões SDP e negociação de mídia...")
        sdp_rows = await tshark.fields(capture, "sdp", SDP_FIELDS)
        await self.progress(48, "rtp", "Extraindo streams RTP...")
        rtp_rows = await tshark.fields(capture, "rtp", RTP_FIELDS)
        await self.progress(62, "rtcp", "Extraindo informações RTCP disponíveis...")
        try: rtcp_rows = await tshark.fields(capture, "rtcp", RTCP_FIELDS)
        except Exception: rtcp_rows = []
        await self.progress(72, "correlation", "Correlacionando Call-ID, SIP, SDP e RTP...")
        calls = self._build_calls(sip_rows, sdp_rows, rtp_rows)
        macro = self._macro(info, calls, rtcp_rows)
        await self.progress(82, "diagnosis", "Aplicando regras de qualidade e diagnóstico...")
        self._diagnose(calls, macro)
        await self.progress(90, "finalize", "Consolidando evidências e indicadores...")
        return {"capture": info, "macro": macro, "calls": [self._call_dict(c) for c in calls.values()], "rtcp": rtcp_rows}

    def _build_calls(self, sip_rows, sdp_rows, rtp_rows):
        calls = {}
        for r in sip_rows:
            cid = r.get("sip.Call-ID") or "UNKNOWN"
            m = SipMessage(
                ts=ffloat(r.get("frame.time_epoch"), 0), call_id=cid,
                method=r.get("sip.Method") or "", status=fint(r.get("sip.Status-Code")),
                cseq_method=r.get("sip.CSeq.method") or "", cseq=r.get("sip.CSeq.seq") or "",
                src=ip(r,"src"), dst=ip(r,"dst"), src_port=port(r,"src"), dst_port=port(r,"dst"),
                from_uri=r.get("sip.from.uri") or "", to_uri=r.get("sip.to.uri") or "",
                user_agent=r.get("sip.User-Agent") or r.get("sip.Server") or "",
                reason=r.get("sip.Reason") or "", frame=r.get("frame.number") or ""
            )
            calls.setdefault(cid, Call(cid)).messages.append(m)
        for r in sdp_rows:
            cid = r.get("sip.Call-ID") or "UNKNOWN"
            calls.setdefault(cid, Call(cid)).sdp.append(r)
        for r in rtp_rows:
            cid = self._guess_call_for_rtp(r, calls)
            if cid:
                calls[cid].rtp.append(RtpPacket(
                    ts=ffloat(r.get("frame.time_epoch"),0), ssrc=r.get("rtp.ssrc") or "",
                    seq=fint(r.get("rtp.seq")), rtp_ts=fint(r.get("rtp.timestamp")),
                    payload_type=r.get("rtp.p_type") or "", src=ip(r,"src"), dst=ip(r,"dst"),
                    src_port=port(r,"src"), dst_port=port(r,"dst"), frame=r.get("frame.number") or ""
                ))
        for c in calls.values(): self._metrics(c)
        return calls

    def _guess_call_for_rtp(self, r, calls):
        if not calls: return None
        ts = ffloat(r.get("frame.time_epoch"), 0)
        candidates = []
        for cid,c in calls.items():
            if not c.messages: continue
            start, end = min(m.ts for m in c.messages), max(m.ts for m in c.messages)
            if start - 2 <= ts <= end + 30: candidates.append((abs(ts-start), cid))
        return min(candidates)[1] if candidates else None

    def _metrics(self, c: Call):
        msgs = sorted(c.messages, key=lambda x:x.ts)
        invites = [m for m in msgs if m.method == "INVITE" and m.cseq_method != "INVITE"]
        if not invites: invites = [m for m in msgs if m.method == "INVITE"][:1]
        initial = invites[0] if invites else None
        answer = next((m for m in msgs if m.status == 200 and (m.cseq_method == "INVITE" or m.method == "INVITE")), None)
        ringing = next((m for m in msgs if m.status in (180,183) and m.cseq_method == "INVITE"), None)
        cancel = next((m for m in msgs if m.method == "CANCEL"), None)
        bye = next((m for m in msgs if m.method == "BYE"), None)
        start = initial.ts if initial else (msgs[0].ts if msgs else None)
        end = (bye.ts if bye else (cancel.ts if cancel else (msgs[-1].ts if msgs else None)))
        conv = (bye.ts-answer.ts) if answer and bye else None
        pdd_ring = (ringing.ts-initial.ts) if initial and ringing else None
        pdd_answer = (answer.ts-initial.ts) if initial and answer else None
        retrans = 0
        seen = Counter()
        for m in msgs:
            key=(m.method,m.status,m.cseq,m.src,m.dst)
            seen[key]+=1
        retrans=sum(v-1 for v in seen.values() if v>1)
        rtp_metrics=self._rtp_metrics(c.rtp)
        c.metrics = {
            "start": start, "end": end, "duration": (end-start if start is not None and end is not None else None),
            "conversation_duration": conv, "pdd_to_progress": pdd_ring, "pdd_to_answer": pdd_answer,
            "final_status": answer.status if answer else (next((m.status for m in reversed(msgs) if m.status), None)),
            "answered": bool(answer), "cancelled": bool(cancel), "bye": bool(bye),
            "retransmissions": retrans, "rtp": rtp_metrics,
            "codecs": self._codecs(c.sdp), "media_declarations": c.sdp,
        }

    def _rtp_metrics(self, packets):
        if not packets: return {"packets":0,"streams":0,"loss_pct":None,"jitter_ms":None,"jitter_p95_ms":None,"bitrate_kbps":None,"one_way":True}
        by = defaultdict(list)
        for p in packets: by[(p.ssrc,p.src,p.dst,p.src_port,p.dst_port)].append(p)
        streams=[]; all_jitter=[]; total_loss=0; expected_total=0
        for key,ps in by.items():
            ps=sorted(ps,key=lambda x:x.ts)
            seqs=[p.seq for p in ps if p.seq is not None]
            loss=0
            if len(seqs)>=2:
                diffs=[]
                for a,b in zip(seqs,seqs[1:]):
                    d=(b-a)%65536
                    if d>1: loss += d-1
                expected=len(seqs)+loss
            else: expected=len(seqs)
            jitter=[]
            for a,b in zip(ps,ps[1:]):
                delta=abs((b.ts-a.ts)*1000)
                if delta: jitter.append(delta)
            # This is an arrival-delta proxy, not RFC 3550 interarrival jitter.
            all_jitter.extend(jitter)
            total_loss += loss; expected_total += expected
            dur=max(ps[-1].ts-ps[0].ts,0.001)
            bitrate=sum(0 for _ in ps) / dur
            streams.append({"ssrc":key[0],"src":key[1],"dst":key[2],"src_port":key[3],"dst_port":key[4],"packets":len(ps),"estimated_loss":loss,"loss_pct":(100*loss/expected if expected else None),"arrival_delta_mean_ms":statistics.mean(jitter) if jitter else None,"arrival_delta_p95_ms":percentile(jitter,95),"duration":dur,"pps":len(ps)/dur,"codec_payload_types":sorted(set(p.payload_type for p in ps))})
        endpoints={(p.src,p.dst) for p in packets}
        return {"packets":len(packets),"streams":len(streams),"loss_pct":(100*total_loss/expected_total if expected_total else None),"jitter_ms":statistics.mean(all_jitter) if all_jitter else None,"jitter_p95_ms":percentile(all_jitter,95),"bitrate_kbps":None,"one_way":len(endpoints)<2,"streams_detail":streams}

    def _codecs(self, sdp):
        vals=[]
        for r in sdp:
            for key in ("sdp.media.format_specific_parameter","sdp.media.format"):
                v=r.get(key)
                if v: vals.append(v)
        return vals

    def _macro(self, info, calls, rtcp):
        cs=list(calls.values())
        answered=sum(1 for c in cs if c.metrics.get("answered"))
        attempts=sum(1 for c in cs if c.call_id != "UNKNOWN")
        durations=[c.metrics["duration"] for c in cs if c.metrics.get("duration") is not None]
        pdds=[c.metrics["pdd_to_answer"] for c in cs if c.metrics.get("pdd_to_answer") is not None]
        losses=[c.metrics["rtp"]["loss_pct"] for c in cs if c.metrics["rtp"].get("loss_pct") is not None]
        jitters=[c.metrics["rtp"]["jitter_ms"] for c in cs if c.metrics["rtp"].get("jitter_ms") is not None]
        codes=Counter(str(c.metrics.get("final_status")) for c in cs if c.metrics.get("final_status"))
        codecs=Counter(v for c in cs for v in c.metrics.get("codecs",[]) if v)
        duration=info.get("duration") or 0
        return {"calls":attempts,"answered":answered,"asr_pct":100*answered/attempts if attempts else None,"duration_avg_s":statistics.mean(durations) if durations else None,"pdd_avg_s":statistics.mean(pdds) if pdds else None,"pdd_min_s":min(pdds) if pdds else None,"pdd_max_s":max(pdds) if pdds else None,"loss_avg_pct":statistics.mean(losses) if losses else None,"loss_p95_pct":percentile(losses,95),"jitter_avg_ms":statistics.mean(jitters) if jitters else None,"jitter_p95_ms":percentile(jitters,95),"one_way_calls":sum(1 for c in cs if c.metrics["rtp"].get("one_way")),"response_codes":dict(codes),"codecs":dict(codecs),"rtcp_reports":len(rtcp),"pps":(info.get("packets",0)/duration if duration else None),"bps":(info.get("bytes",0)*8/duration if duration else None),"mos_estimated":None,"ner_pct":None}

    def _diagnose(self, calls, macro):
        for c in calls.values():
            m=c.metrics; r=m["rtp"]
            if m.get("retransmissions",0)>=3:
                c.anomalies.append({"severity":"medium","confidence":"high","code":"SIP_RETRANSMISSION","finding":f"Identificadas {m['retransmissions']} duplicações/retransmissões aparentes de mensagens SIP.","impact":"Pode indicar perda, atraso ou resposta insuficiente no caminho de sinalização.","recommendation":"Correlacionar timestamps, RTT de transações SIP e métricas de rede no ponto de captura."})
            if m.get("pdd_to_answer") is not None and m["pdd_to_answer"]>3:
                c.anomalies.append({"severity":"medium","confidence":"high","code":"HIGH_PDD","finding":f"PDD até atendimento de {m['pdd_to_answer']:.2f}s.","impact":"Aumento do tempo percebido para estabelecimento da chamada.","recommendation":"Investigar latência de sinalização, roteamento e tempo de resposta do elemento de terminação."})
            if r.get("loss_pct") is not None and r["loss_pct"]>1:
                c.anomalies.append({"severity":"high" if r['loss_pct']>3 else "medium","confidence":"high","code":"RTP_LOSS","finding":f"Perda RTP estimada de {r['loss_pct']:.2f}%.","impact":"Pode causar áudio picotado, gaps e degradação de qualidade.","recommendation":"Correlacionar com jitter/delta, utilização de link e QoS/DSCP; validar o trecho de rede no horário do evento."})
            if r.get("one_way"):
                c.anomalies.append({"severity":"high","confidence":"high","code":"ONE_WAY_RTP","finding":"RTP foi observado em apenas um sentido no ponto de captura.","impact":"Compatível com áudio unidirecional, embora o ponto de captura possa limitar a conclusão.","recommendation":"Validar SDP, NAT, firewall, SBC/media proxy e existência de RTP no sentido oposto em outros pontos da rede."})
        macro["degraded_calls"]=sum(1 for c in calls.values() if c.anomalies)
        macro["critical_calls"]=sum(1 for c in calls.values() if any(a["severity"]=="high" for a in c.anomalies))
        macro["health"]="CRÍTICO" if macro["critical_calls"] else ("ATENÇÃO" if macro["degraded_calls"] else "BOM")

    def _call_dict(self,c):
        msgs=sorted(c.messages,key=lambda x:x.ts)
        return {"call_id":c.call_id,"from":msgs[0].from_uri if msgs else "","to":msgs[0].to_uri if msgs else "","start":c.metrics.get("start"),"end":c.metrics.get("end"),"messages":[m.__dict__ for m in msgs],"metrics":c.metrics,"anomalies":c.anomalies}
