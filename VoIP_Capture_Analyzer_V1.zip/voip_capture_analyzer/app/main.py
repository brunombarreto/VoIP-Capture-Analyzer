import asyncio, os, uuid, shutil
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.templating import Jinja2Templates
from starlette.requests import Request
from app.config import UPLOAD_DIR, REPORT_DIR, MAX_UPLOAD_MB
from app.services.jobs import JobManager
from app.services.tshark import TSharkError, check_tshark
from app.analyzers.engine import CaptureAnalyzer
from app.services.charts import make_charts
from app.services.report import render_html, export_pdf, export_docx

app=FastAPI(title="VoIP Capture Analyzer", version="1.0.0")
templates=Jinja2Templates(directory=str(Path(__file__).parent/"templates"))
jobs=JobManager()
ALLOWED={".cap",".pcap",".pcapng"}

@app.get("/",response_class=HTMLResponse)
async def index(request: Request): return templates.TemplateResponse("index.html",{"request":request})

@app.get("/api/health")
async def health():
    try: tshark_version=await check_tshark(); ok=True
    except Exception as e: tshark_version=str(e); ok=False
    return {"ok":ok,"tshark":tshark_version}

@app.post("/api/analyze")
async def analyze(file: UploadFile=File(...)):
    ext=Path(file.filename or "").suffix.lower()
    if ext not in ALLOWED: raise HTTPException(400,"Formato não suportado. Use .cap, .pcap ou .pcapng.")
    job_id=uuid.uuid4().hex; job=await jobs.create(job_id,file.filename or f"capture{ext}")
    target=UPLOAD_DIR/f"{job_id}{ext}"
    size=0
    with target.open("wb") as out:
        while chunk:=await file.read(1024*1024):
            size += len(chunk)
            if size>MAX_UPLOAD_MB*1024*1024:
                target.unlink(missing_ok=True); raise HTTPException(413,f"Arquivo excede {MAX_UPLOAD_MB} MB.")
            out.write(chunk)
    asyncio.create_task(run_job(job_id,target))
    return {"job_id":job_id,"status":"queued"}

async def run_job(job_id: str, capture: Path):
    try:
        async def cb(p,s,m): await jobs.update(job_id,p,s,m)
        analyzer=CaptureAnalyzer(cb)
        data=await analyzer.analyze(capture)
        await jobs.update(job_id,94,"charts","Gerando gráficos técnicos...")
        charts=make_charts(data)
        await jobs.update(job_id,97,"report","Montando relatório...",)
        html=render_html(data,charts,capture.name)
        pdf=export_pdf(html,job_id); docx=export_docx(data,charts,capture.name,job_id)
        report={"data":data,"charts":charts,"files":{"pdf":pdf.name,"docx":docx.name}}
        jobs.jobs[job_id].report=report
        await jobs.update(job_id,100,"completed","Análise concluída.",status="completed",report=report)
    except Exception as e:
        jobs.jobs[job_id].error=str(e)
        await jobs.update(job_id,100,"error","Falha durante a análise.",status="error",error=str(e))

@app.get("/api/jobs/{job_id}")
async def get_job(job_id:str):
    job=jobs.jobs.get(job_id)
    if not job: raise HTTPException(404,"Job não encontrado")
    return {"job_id":job.job_id,"filename":job.filename,"status":job.status,"percent":job.percent,"stage":job.stage,"message":job.message,"error":job.error,"report":job.report}

@app.get("/api/jobs/{job_id}/download/{kind}")
async def download(job_id:str,kind:str):
    if kind not in ("pdf","docx"): raise HTTPException(400,"Formato inválido")
    path=REPORT_DIR/f"{job_id}.{kind}"
    if not path.exists(): raise HTTPException(404,"Relatório ainda não disponível")
    return FileResponse(path,filename=f"voip_capture_analyzer_{job_id}.{kind}")

@app.websocket("/ws/{job_id}")
async def websocket(ws:WebSocket,job_id:str):
    await ws.accept()
    if job_id not in jobs.jobs:
        await ws.send_json({"status":"error","error":"Job não encontrado"}); await ws.close(); return
    q=await jobs.subscribe(job_id)
    try:
        while True:
            msg=await q.get(); await ws.send_json(msg)
            if msg.get("status") in ("completed","error"): break
    except WebSocketDisconnect: pass
    finally: await jobs.unsubscribe(job_id,q)
