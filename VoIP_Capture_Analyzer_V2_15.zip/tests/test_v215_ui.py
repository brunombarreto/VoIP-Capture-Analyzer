# Copyright (c) 2026 Bruno Barreto
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_v215_version_and_help_menu():
    config = (ROOT / "app" / "config.py").read_text(encoding="utf-8")
    html = (ROOT / "app" / "templates" / "index.html").read_text(encoding="utf-8")
    assert 'VERSION = "2.15.0"' in config
    assert "Dashboard SIP / SDP / RTP / RTCP · V2.15" in html
    assert "Como utilizar" in html
    assert "Download - V2.15" in html
    assert "TShark OK" not in html


def test_v215_internal_job_id_is_not_displayed_as_call_id():
    js = (ROOT / "app" / "static" / "app.js").read_text(encoding="utf-8")
    assert "function displayCallId(callId)" in js
    assert "value === String(state.job ?? '')" in js
