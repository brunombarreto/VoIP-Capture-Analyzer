# Copyright (c) 2026 Bruno Barreto
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

import base64
import io
from collections import Counter
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def img_data(fig):
    buf = io.BytesIO()
    fig.tight_layout()
    fig.savefig(buf, format="png", dpi=150, bbox_inches="tight")
    plt.close(fig)
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def empty(ax, message="Sem dados suficientes"):
    ax.text(0.5, 0.5, message, ha="center", va="center", transform=ax.transAxes)


def endpoint_label(ip, port=None):
    """Format an IP/port pair for technical charts without horizontal overlap."""
    address = str(ip or "?")
    port_text = str(port or "")
    # Keep the complete address, but put the port on a separate line.
    return f"{address}\n:{port_text}" if port_text else address


def make_charts(data, job_id=None):
    macro = data["macro"]
    calls = data["calls"]
    charts = {}

    codes = macro.get("all_response_codes") or macro.get("response_codes", {})
    fig, ax = plt.subplots(figsize=(7, 4))
    if codes:
        ax.bar(list(codes.keys()), list(codes.values()))
    else:
        empty(ax)
    ax.set_title("Distribuição de códigos de resposta SIP")
    ax.set_xlabel("Código")
    ax.set_ylabel("Chamadas")
    charts["response_codes"] = img_data(fig)

    methods = macro.get("sip_methods", {})
    fig, ax = plt.subplots(figsize=(8, 4))
    if methods:
        keys = list(methods.keys())
        ax.bar(keys, [methods[k] for k in keys]); ax.tick_params(axis="x", rotation=35)
    else:
        empty(ax)
    ax.set_title("Métodos SIP observados")
    ax.set_xlabel("Método")
    ax.set_ylabel("Pacotes")
    charts["sip_methods"] = img_data(fig)

    pdds = [c["metrics"].get("pdd_to_answer") for c in calls if c["metrics"].get("pdd_to_answer") is not None]
    fig, ax = plt.subplots(figsize=(7, 4))
    if pdds:
        ax.hist(pdds, bins=min(12, max(4, len(pdds))))
    else:
        empty(ax)
    ax.set_title("Distribuição de PDD até atendimento")
    ax.set_xlabel("Segundos")
    ax.set_ylabel("Chamadas")
    charts["pdd"] = img_data(fig)

    losses, jitters = [], []
    for c in calls:
        loss = c["metrics"]["rtp"].get("loss_pct")
        jitter = c["metrics"]["rtp"].get("jitter_ms")
        if loss is not None and jitter is not None:
            losses.append(loss); jitters.append(jitter)
    fig, ax = plt.subplots(figsize=(7, 4))
    if losses:
        ax.scatter(losses, jitters, alpha=0.75)
    else:
        empty(ax)
    ax.set_title("Perda RTP × Jitter")
    ax.set_xlabel("Perda estimada (%)")
    ax.set_ylabel("Jitter RTP (ms)")
    charts["loss_jitter"] = img_data(fig)

    labels = [c["call_id"][:14] for c in calls if c["metrics"]["rtp"].get("jitter_ms") is not None]
    vals = [c["metrics"]["rtp"]["jitter_ms"] for c in calls if c["metrics"]["rtp"].get("jitter_ms") is not None]
    fig, ax = plt.subplots(figsize=(9, 4))
    if vals:
        ax.bar(labels, vals); ax.tick_params(axis="x", rotation=60)
    else:
        empty(ax)
    ax.set_title("Jitter por chamada")
    ax.set_ylabel("ms")
    charts["jitter_calls"] = img_data(fig)

    labels = [c["call_id"][:14] for c in calls if c["metrics"]["rtp"].get("loss_pct") is not None]
    vals = [c["metrics"]["rtp"]["loss_pct"] for c in calls if c["metrics"]["rtp"].get("loss_pct") is not None]
    fig, ax = plt.subplots(figsize=(9, 4))
    if vals:
        ax.bar(labels, vals); ax.tick_params(axis="x", rotation=60)
    else:
        empty(ax)
    ax.set_title("Perda RTP por chamada")
    ax.set_ylabel("% estimado")
    charts["loss_calls"] = img_data(fig)

    codecs = macro.get("codecs", {})
    fig, ax = plt.subplots(figsize=(7, 4))
    if codecs:
        keys = list(codecs)[:15]
        ax.bar(keys, [codecs[k] for k in keys]); ax.tick_params(axis="x", rotation=45)
    else:
        empty(ax)
    ax.set_title("Distribuição de codecs / payloads SDP")
    ax.set_ylabel("Ocorrências")
    charts["codecs"] = img_data(fig)

    # Temporal concurrency profile.
    events = []
    for c in calls:
        if c.get("start") is not None:
            events.append((c["start"], 1))
        if c.get("end") is not None:
            events.append((c["end"], -1))
    fig, ax = plt.subplots(figsize=(9, 4))
    if events:
        events.sort(key=lambda x: (x[0], -x[1]))
        active = 0; xs = []; ys = []
        for ts, delta in events:
            active += delta; xs.append(ts - events[0][0]); ys.append(active)
        ax.step(xs, ys, where="post")
    else:
        empty(ax)
    ax.set_title("Chamadas simultâneas ao longo da captura")
    ax.set_xlabel("Tempo desde o início (s)")
    ax.set_ylabel("Chamadas simultâneas")
    charts["concurrency"] = img_data(fig)

    # Quality matrix.
    fig, ax = plt.subplots(figsize=(7, 5))
    xs=[]; ys=[]; labels=[]
    for c in calls:
        x=c["metrics"]["rtp"].get("loss_pct"); y=c["metrics"]["rtp"].get("jitter_ms")
        if x is not None and y is not None:
            xs.append(x); ys.append(y); labels.append(c["call_id"][:8])
    if xs:
        ax.scatter(xs, ys, alpha=.75)
        for x,y,label in zip(xs,ys,labels): ax.annotate(label,(x,y),fontsize=7,xytext=(4,4),textcoords="offset points")
        ax.axvline(1, linestyle="--"); ax.axvline(3, linestyle="--"); ax.axhline(20, linestyle="--"); ax.axhline(30, linestyle="--")
    else:
        empty(ax)
    ax.set_title("Matriz de qualidade: perda × jitter")
    ax.set_xlabel("Perda RTP (%)")
    ax.set_ylabel("Jitter RTP (ms)")
    charts["quality_matrix"] = img_data(fig)

    # SIP timing summary.
    vals=[]; labels=[]
    for c in calls:
        for key, label in (("pdd_to_trying","100 Trying"),("pdd_to_progress","180/183"),("pdd_to_answer","200 OK")):
            v=c["metrics"].get(key)
            if v is not None:
                vals.append(v); labels.append(label)
    fig, ax = plt.subplots(figsize=(8,4))
    if vals:
        ax.boxplot(vals)
        ax.set_xticklabels(["SIP timing"])
    else:
        empty(ax)
    ax.set_title("Distribuição dos tempos de estabelecimento SIP")
    ax.set_ylabel("Segundos")
    charts["sip_timing"] = img_data(fig)

    # SIP ladder diagrams for the first six calls. This is deliberately compact
    # so it remains readable in PDF/DOCX as well as in the web dashboard.
    for idx, call in enumerate(calls[:6], 1):
        msgs = call.get("messages", [])[:18]
        nodes = []
        for m in msgs:
            for n in (m.get("src") or "?", m.get("dst") or "?"):
                if n not in nodes:
                    nodes.append(n)
        if len(nodes) < 2 or not msgs:
            continue
        fig, ax = plt.subplots(figsize=(11, max(5, len(msgs) * 0.48)))
        positions = {n: i for i, n in enumerate(nodes)}
        for n, x in positions.items():
            ax.plot([x, x], [0, len(msgs)+1], linestyle=":", linewidth=0.8)
            # IP and port are deliberately separated to remain readable.
            node_port = ""
            for m in msgs:
                if m.get("src") == n and m.get("src_port"):
                    node_port = m.get("src_port"); break
                if m.get("dst") == n and m.get("dst_port"):
                    node_port = m.get("dst_port"); break
            ax.text(x, len(msgs)+0.45, endpoint_label(n, node_port), ha="center", va="bottom", fontsize=8)
        for row, m in enumerate(msgs, start=1):
            src, dst = m.get("src") or "?", m.get("dst") or "?"
            x1, x2 = positions[src], positions[dst]
            status = m.get("status")
            label = (str(status) if status else (m.get("method") or "SIP"))
            if m.get("cseq"):
                label += f" CSeq {m['cseq']}"
            ax.annotate("", xy=(x2, len(msgs)-row+1), xytext=(x1, len(msgs)-row+1),
                        arrowprops={"arrowstyle": "->", "linewidth": 0.9})
            ax.text((x1+x2)/2, len(msgs)-row+1+0.14, label, ha="center", fontsize=7)
        ax.set_xlim(-0.7, max(positions.values())+0.7); ax.set_ylim(0, len(msgs)+1.25)
        ax.set_title(f"Fluxo SIP — chamada {idx} — {call.get('call_id','')[:24]}")
        ax.axis("off")
        charts[f"call_flow_{idx}"] = img_data(fig)

    # Correlated SIP + RTP timeline. SIP events are plotted against the same
    # relative clock used by RTP state changes/gaps, making media interruptions
    # visually comparable with signaling events.
    for idx, call in enumerate(calls[:6], 1):
        timeline = call.get("timeline") or call.get("metrics", {}).get("timeline", [])
        if not timeline:
            continue
        base = min(float(e.get("offset_s", 0.0)) for e in timeline)
        sip = [e for e in timeline if str(e.get("type", "")).startswith("SIP_")]
        media = [e for e in timeline if str(e.get("type", "")).startswith("RTP_")]
        fig, ax = plt.subplots(figsize=(12, 5.8))
        # SIP events occupy the upper band; RTP events occupy the lower band.
        if sip:
            xs = [float(e.get("offset_s", 0.0)) - base for e in sip]
            ax.scatter(xs, [1.0] * len(xs), marker="o", s=28, label="SIP")
            for x, e in zip(xs, sip):
                label = str(e.get("label", ""))
                # Keep long endpoint details readable without stacking labels.
                ax.annotate(label[:28], (x, 1.0), xytext=(0, 9), textcoords="offset points", fontsize=6, rotation=35, ha="left")
        if media:
            xs = [float(e.get("offset_s", 0.0)) - base for e in media]
            ax.scatter(xs, [0.0] * len(xs), marker="|", s=80, label="RTP")
            for x, e in zip(xs, media):
                if e.get("type") in {"RTP_GAP_START", "RTP_GAP_END", "RTP_START_DELAY"}:
                    ax.annotate(str(e.get("label", ""))[:34], (x, 0.0), xytext=(0, -18), textcoords="offset points", fontsize=6, rotation=35, ha="left")
        ax.set_yticks([0.0, 1.0]); ax.set_yticklabels(["RTP / mídia", "SIP / sinalização"])
        ax.set_xlabel("Tempo desde o início da chamada (s)")
        ax.set_title(f"Linha do tempo correlacionada SIP + RTP — chamada {idx}")
        ax.grid(axis="x", linestyle=":", linewidth=0.5)
        charts[f"sip_rtp_timeline_{idx}"] = img_data(fig)

    # Detailed RTP timeline for the most relevant calls (up to six). The data is
    # generated from packet-level evidence, not synthetic samples.
    for idx, call in enumerate(calls[:6], 1):
        timeline = call.get("metrics", {}).get("rtp", {}).get("timeline", [])
        if not timeline:
            continue
        base = timeline[0]["ts"]
        xs = [(p["ts"] - base) for p in timeline]
        ys = [p.get("delta_ms", 0) for p in timeline]
        lost = [p for p in timeline if p.get("loss", 0)]
        fig, ax = plt.subplots(figsize=(9, 4))
        ax.plot(xs, ys, linewidth=0.8)
        if lost:
            ax.scatter([(p["ts"]-base) for p in lost], [p.get("delta_ms",0) for p in lost], marker="x", s=24)
        ax.set_title(f"RTP — delta entre pacotes — chamada {idx}")
        ax.set_xlabel("Tempo desde início do RTP (s)")
        ax.set_ylabel("Delta (ms)")
        charts[f"rtp_timeline_{idx}"] = img_data(fig)

    return charts
