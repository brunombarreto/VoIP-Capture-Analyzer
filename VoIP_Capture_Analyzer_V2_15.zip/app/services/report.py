# Copyright (c) 2026 Bruno Barreto
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

from datetime import datetime
from io import BytesIO
import base64
from pathlib import Path
from jinja2 import Environment, FileSystemLoader, select_autoescape
from docx import Document
from docx.shared import Inches, Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from weasyprint import HTML
from app.config import REPORT_DIR, VERSION

TEMPLATE_DIR = Path(__file__).resolve().parent.parent / "templates"

GLOSSARY = [
    ("SIP", "Protocolo de sinalização usado para iniciar, modificar e encerrar sessões VoIP."),
    ("SDP", "Descrição da sessão negociada no SIP, incluindo codec, IP e portas de mídia."),
    ("RTP", "Protocolo usado para transportar mídia em tempo real, como áudio."),
    ("RTCP", "Protocolo complementar ao RTP, usado para informações de controle e qualidade."),
    ("ASR", "Answer-Seizure Ratio; proporção de tentativas que chegam a atendimento."),
    ("PDD", "Post Dial Delay; tempo entre o início efetivo da tentativa e o atendimento, conforme a definição operacional do Analyzer."),
    ("Jitter", "Variação do intervalo de chegada dos pacotes RTP."),
    ("Bitrate", "Taxa média de bits transmitidos por unidade de tempo."),
    ("Codec", "Algoritmo/formato utilizado para codificar e decodificar áudio."),
    ("B2BUA", "Back-to-Back User Agent; elemento que mantém duas ou mais pernas SIP relacionadas a uma chamada lógica."),
    ("SBC", "Session Border Controller; elemento que controla e protege sessões VoIP entre domínios."),
    ("PBX", "Central telefônica privada responsável por funções de telefonia e encaminhamento."),
    ("Firewall", "Controle de segurança que permite ou bloqueia tráfego conforme regras configuradas."),
    ("QoS", "Quality of Service; mecanismos para priorização e tratamento de tráfego."),
    ("DSCP", "Campo usado para marcar a prioridade ou classe de serviço de pacotes IP."),
    ("SSRC", "Identificador de uma fonte de sincronização RTP."),
    ("Payload Type", "Identificador do formato ou carga RTP transportada pelo pacote."),
    ("Call-ID", "Identificador SIP usado para relacionar mensagens de uma sessão ou diálogo."),
    ("Re-INVITE", "Novo INVITE dentro de uma sessão já estabelecida, frequentemente usado para alteração de SDP ou estado da sessão."),
    ("One-way RTP", "Situação em que a captura evidencia mídia RTP em apenas um sentido."),
]

def add_hyperlink(paragraph, text, url):
    part = paragraph.part
    r_id = part.relate_to(url, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink", is_external=True)
    hyperlink = OxmlElement("w:hyperlink")
    hyperlink.set(qn("r:id"), r_id)
    run = OxmlElement("w:r")
    rPr = OxmlElement("w:rPr")
    color = OxmlElement("w:color"); color.set(qn("w:val"), "2563EB")
    underline = OxmlElement("w:u"); underline.set(qn("w:val"), "single")
    rPr.append(color); rPr.append(underline)
    run.append(rPr)
    text_el = OxmlElement("w:t"); text_el.text = text
    run.append(text_el); hyperlink.append(run)
    paragraph._p.append(hyperlink)
    return hyperlink

def fmt(v, suffix="", decimals=2):
    if v is None:
        return "N/A"
    if isinstance(v, float):
        return f"{v:.{decimals}f}{suffix}"
    return f"{v}{suffix}"

def build_context(data, charts, filename):
    return {
        "data": data, "charts": charts, "filename": filename,
        "generated": datetime.now().astimezone().strftime("%d/%m/%Y %H:%M:%S"), "fmt": fmt, "version": VERSION, "glossary": GLOSSARY,
    }

def render_html(data, charts, filename):
    env = Environment(loader=FileSystemLoader(str(TEMPLATE_DIR)), autoescape=select_autoescape(["html", "xml"]))
    return env.get_template("report.html").render(**build_context(data, charts, filename))

def export_pdf(html, job_id):
    path = REPORT_DIR / f"{job_id}.pdf"
    HTML(string=html, base_url=str(TEMPLATE_DIR.parent)).write_pdf(str(path))
    return path

def export_docx(data, charts, filename, job_id):
    path = REPORT_DIR / f"{job_id}.docx"
    doc = Document()
    sec = doc.sections[0]
    sec.top_margin = Inches(.55); sec.bottom_margin = Inches(.55); sec.left_margin = Inches(.65); sec.right_margin = Inches(.65)
    styles = doc.styles
    styles["Normal"].font.name = "Arial"; styles["Normal"].font.size = Pt(9.5)
    footer = sec.footer.paragraphs[0]
    footer.alignment = 1
    footer.add_run("Copyright (c) 2026 ").font.size = Pt(8)
    add_hyperlink(footer, "Bruno Barreto", "https://linktr.ee/brunombarreto")
    doc.add_heading("VoIP Capture Analyzer", 0)
    doc.add_paragraph(f"Versão: V{VERSION}")
    doc.add_paragraph("Relatório Técnico Profissional de Análise de Tráfego SIP e RTP")
    doc.add_paragraph(f"Captura: {filename} | Gerado em: {datetime.now().astimezone():%d/%m/%Y %H:%M:%S}")

    doc.add_heading("1. Resumo Executivo", 1)
    doc.add_paragraph(f"Saúde geral: {data['macro'].get('health','N/A')}")
    if data["macro"].get("health_reason"):
        doc.add_paragraph(f"Observação: {data['macro']['health_reason']}")
    t = doc.add_table(rows=1, cols=3); t.style = "Light Shading Accent 1"
    for i,h in enumerate(["KPI","Valor","Interpretação"]): t.rows[0].cells[i].text = h
    rows = [
        ("Chamadas", fmt(data['macro'].get('calls')), "Tentativas com INVITE inicial"),
        ("ASR", fmt(data['macro'].get('asr_pct'), "%"), "Chamadas com 200 OK do INVITE inicial"),
        ("PDD médio", fmt(data['macro'].get('pdd_avg_s'), " s"), "INVITE até 200 OK"),
        ("Jitter médio", fmt(data['macro'].get('jitter_avg_ms'), " ms"), "Jitter RTP calculado quando clock rate disponível"),
        ("Perda média", fmt(data['macro'].get('loss_avg_pct'), "%"), "Perda estimada por sequência RTP"),
        ("RTP unilateral", fmt(data['macro'].get('one_way_calls')), "Chamadas com fluxo observado em um único sentido"),
    ]
    for row in rows:
        cells = t.add_row().cells
        for i,v in enumerate(row): cells[i].text = v

    doc.add_heading("2. Metodologia", 1)
    doc.add_paragraph("A análise utiliza TShark em subprocessos assíncronos e separa evidências observadas, métricas calculadas e inferências diagnósticas. Métricas que não podem ser obtidas com segurança são apresentadas como N/A.")
    doc.add_paragraph("Limiar operacional: PDD > 3s, jitter > 30ms e perda RTP > 1% geram alerta. Esses limites são critérios operacionais da aplicação, não limites universais de todos os ambientes.")

    doc.add_heading("3. Análise Macro", 1)
    cap = data["capture"]
    doc.add_paragraph(f"Inventário de protocolos: SIP {data['macro'].get('protocol_inventory',{}).get('sip_packets',0)} | SDP {data['macro'].get('protocol_inventory',{}).get('sdp_packets',0)} | RTP {data['macro'].get('protocol_inventory',{}).get('rtp_packets',0)} | RTCP {data['macro'].get('protocol_inventory',{}).get('rtcp_packets',0)} | RTP não associado {data['macro'].get('rtp_unassociated_packets',0)}")
    doc.add_paragraph(f"Tráfego SIP de controle: REGISTER={data['macro'].get('register_packets',0)} | OPTIONS={data['macro'].get('options_packets',0)}. Esses pacotes não são contabilizados como tentativas de chamada.")
    doc.add_paragraph(f"Interrupções RTP: {data['macro'].get('rtp_gap_events',0)} evento(s) em {data['macro'].get('rtp_gap_calls',0)} chamada(s); maior intervalo observado: {fmt(data['macro'].get('rtp_gap_max_s'),' s')}.")
    doc.add_paragraph(f"Pacotes: {cap.get('packets',0)} | Bytes: {cap.get('bytes',0)} | Duração: {fmt(cap.get('duration'),' s')} | PPS: {fmt(data['macro'].get('pps'))} | Bitrate: {fmt((data['macro'].get('bps') or 0)/1000,' kbps')}")
    chart_titles = [("response_codes","Códigos SIP observados"),("sip_methods","Métodos SIP"),("pdd","PDD"),("loss_jitter","Perda × Jitter"),("jitter_calls","Jitter por chamada"),("loss_calls","Perda por chamada"),("codecs","Codecs"),("concurrency","Chamadas simultâneas"),("quality_matrix","Matriz de qualidade"),("sip_timing","Tempos SIP")]
    for name,title in chart_titles:
        if name in charts:
            doc.add_heading(title, 2)
            raw = base64.b64decode(charts[name].split(",",1)[1])
            doc.add_picture(BytesIO(raw), width=Inches(6.5))

    for idx in range(1, 7):
        for name, title in ((f"call_flow_{idx}", f"Fluxo SIP — chamada {idx}"), (f"rtp_timeline_{idx}", f"Linha do tempo RTP — chamada {idx}"), (f"sip_rtp_timeline_{idx}", f"Linha do tempo correlacionada SIP + RTP — chamada {idx}")):
            if name in charts:
                doc.add_heading(title, 2)
                raw = base64.b64decode(charts[name].split(",",1)[1])
                doc.add_picture(BytesIO(raw), width=Inches(6.5))

    doc.add_heading("4. Diagnóstico Consolidado", 1)
    doc.add_paragraph(f"Chamadas com anomalias: {data['macro'].get('degraded_calls',0)} | Chamadas críticas: {data['macro'].get('critical_calls',0)} | Pico de simultaneidade: {data['macro'].get('concurrent_peak',0)}")

    doc.add_heading("5. Análise Micro", 1)
    for index, call in enumerate(data["calls"], 1):
        doc.add_heading(f"5.{index}. {call['call_id']}", 2)
        m = call["metrics"]; r = m["rtp"]
        corr = call.get("correlation", {})
        doc.add_paragraph(f"From: {call['from'] or 'N/A'} | To: {call['to'] or 'N/A'} | Status: {m.get('final_status') or 'N/A'}")
        doc.add_paragraph(f"Correlação: {corr.get('type', 'single-leg')} | Pernas: {corr.get('leg_count', 1)} | Call-IDs: {', '.join(call.get('leg_call_ids', [call['call_id']]))}")
        legs = call.get("legs", [])
        if legs:
            doc.add_paragraph("Pernas SIP / mídia")
            lt = doc.add_table(rows=1, cols=7); lt.style = "Light Shading Accent 1"
            for i,h in enumerate(["Leg","Call-ID","Sinalização","RTP","Streams","Perda","Jitter"]): lt.rows[0].cells[i].text = h
            for li, leg in enumerate(legs, 1):
                cells = lt.add_row().cells
                sig = leg.get("signaling", {})
                r = leg.get("rtp", {})
                vals = [str(li), leg.get("call_id", ""), f"{sig.get('src','')}:{sig.get('src_port','')} → {sig.get('dst','')}:{sig.get('dst_port','')}", str(r.get("packets",0)), str(r.get("streams",0)), fmt(r.get("loss_pct"), "%"), fmt(r.get("jitter_ms"), " ms")]
                for i,v in enumerate(vals): cells[i].text = v
        if corr.get("evidence"):
            doc.add_paragraph("Evidências da correlação: " + "; ".join(corr["evidence"]))
        doc.add_paragraph(f"Duração: {fmt(m.get('duration'),' s')} | Conversação: {fmt(m.get('conversation_duration'),' s')} | PDD: {fmt(m.get('pdd_to_answer'),' s')} | SIP messages: {m.get('sip_messages',0)}")
        doc.add_paragraph(f"RTP: {r.get('packets',0)} pacotes | Streams: {r.get('streams',0)} | Perda: {fmt(r.get('loss_pct'),'%')} | Jitter: {fmt(r.get('jitter_ms'),' ms')} | Jitter p95: {fmt(r.get('jitter_p95_ms'),' ms')}")
        if r.get("directions"):
            doc.add_paragraph("Direções RTP observadas")
            dt = doc.add_table(rows=1, cols=5); dt.style = "Light Shading Accent 1"
            for i,h in enumerate(["Origem","Destino","Pacotes","Duração","Payload"]): dt.rows[0].cells[i].text = h
            for d in r["directions"]:
                cells = dt.add_row().cells
                vals = [f"{d.get('src','')}:{d.get('src_port','')}", f"{d.get('dst','')}:{d.get('dst_port','')}", str(d.get('packets',0)), fmt(d.get('duration_s'),' s'), ", ".join(d.get('payload_types',[]))]
                for i,v in enumerate(vals): cells[i].text = v
        timeline = call.get("timeline") or m.get("timeline") or []
        if timeline:
            doc.add_paragraph("Linha do tempo correlacionada SIP + RTP")
            tt = doc.add_table(rows=1, cols=3); tt.style = "Light Shading Accent 1"
            for i,h in enumerate(["Tempo","Evento","Detalhe"]): tt.rows[0].cells[i].text = h
            for e in timeline[:40]:
                cells = tt.add_row().cells
                cells[0].text = fmt(e.get("offset_s"), " s")
                cells[1].text = str(e.get("type", ""))
                cells[2].text = str(e.get("label", ""))
        if call["anomalies"]:
            for anomaly in call["anomalies"]:
                doc.add_paragraph(f"[{anomaly['severity'].upper()} / {anomaly['confidence']}] {anomaly['finding']} Impacto: {anomaly['impact']} Recomendação: {anomaly['recommendation']}", style="List Bullet")
        else:
            doc.add_paragraph("Não foram detectadas anomalias segundo as regras operacionais implementadas.")

    doc.add_heading("6. Recomendações", 1)
    doc.add_paragraph("Priorizar chamadas com perda RTP, RTP unilateral, ausência de mídia após atendimento, retransmissões SIP e PDD elevado. Correlacionar os timestamps com interfaces de rede, SBC/PBX, firewall, QoS/DSCP e utilização de enlaces antes de afirmar causa raiz definitiva.")
    doc.add_heading("7. Limitações e Reprodutibilidade", 1)
    doc.add_paragraph("As métricas representam o ponto de captura. Uma captura unilateral não prova, sozinha, a experiência do endpoint remoto. RTP não associado a Call-ID é tratado conservadoramente. MOS/NER não são inventados quando não há dados suficientes. Os campos TShark dependem da versão do Wireshark instalada.")
    doc.add_heading("8. Glossário", 1)
    gt = doc.add_table(rows=1, cols=2); gt.style = "Light Shading Accent 1"
    gt.rows[0].cells[0].text = "Termo"; gt.rows[0].cells[1].text = "Explicação"
    for term, definition in GLOSSARY:
        cells = gt.add_row().cells
        cells[0].text = term
        cells[1].text = definition
    cp = doc.add_paragraph()
    cp.add_run("Copyright (c) 2026 ")
    add_hyperlink(cp, "Bruno Barreto", "https://linktr.ee/brunombarreto")
    doc.save(path)
    return path
