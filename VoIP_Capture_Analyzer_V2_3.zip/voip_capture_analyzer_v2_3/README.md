# VoIP Capture Analyzer v2.2

V2.2 mantém o backend SIP/SDP/RTP/RTCP da V2 e substitui o frontend Alpine por JavaScript vanilla servido como arquivo estático. Isso elimina problemas de escopo/ordem de execução de Alpine (`voipAnalyzer is not defined`, `pick is not defined`, `upload is not defined`).

A aplicação usa FastAPI/Uvicorn, WebSocket, TShark, Matplotlib, WeasyPrint e python-docx.

## Execução

```bash
python3.11 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
tshark --version
IP=$(hostname -I | awk '{print $1}')
uvicorn app.main:app --host "$IP" --port 8000
```

Acesse `http://IP:8000`.

## Frontend

O JavaScript está em `app/static/app.js` e é servido por FastAPI em `/static/app.js`. Não há dependência de Alpine para o funcionamento do upload, WebSocket ou dashboard.
