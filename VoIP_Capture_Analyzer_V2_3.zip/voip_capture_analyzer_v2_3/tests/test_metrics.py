from app.analyzers.engine import CaptureAnalyzer


def test_raw_sip_header_normalization():
    analyzer = CaptureAnalyzer()
    row = {
        "frame.number": "10",
        "frame.time_epoch": "100.0",
        "sip.msg_hdr": "Via: SIP/2.0/UDP 10.0.0.1:5060;branch=z9hG4bKabc\r\nFrom: <sip:100@pbx>\r\nTo: <sip:200@pbx>\r\nCall-ID: abc123@pbx\r\nCSeq: 42 INVITE\r\nUser-Agent: TestUA\r\n",
        "sip.Status-Line": "",
    }
    normalized = analyzer._normalize_sip_row(row)
    assert normalized["sip.Call-ID"] == "abc123@pbx"
    assert normalized["sip.Method"] == "INVITE"
    assert normalized["sip.CSeq.seq"] == "42"
    assert normalized["sip.CSeq.method"] == "INVITE"
    assert normalized["sip.from.uri"] == "<sip:100@pbx>"
    assert normalized["sip.to.uri"] == "<sip:200@pbx>"
    assert normalized["sip.Via.branch"] == "z9hG4bKabc"


def test_raw_sip_response_normalization():
    analyzer = CaptureAnalyzer()
    row = {
        "frame.number": "20",
        "frame.time_epoch": "101.0",
        "sip.msg_hdr": "Call-ID: abc123@pbx\r\nCSeq: 42 INVITE\r\n",
        "sip.Status-Line": "SIP/2.0 200 OK",
    }
    normalized = analyzer._normalize_sip_row(row)
    assert normalized["sip.Call-ID"] == "abc123@pbx"
    assert normalized["sip.Status-Code"] == "200"
    assert normalized["sip.CSeq.seq"] == "42"
    assert normalized["sip.CSeq.method"] == "INVITE"
