from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = DATA_DIR / "uploads"
REPORT_DIR = DATA_DIR / "reports"
CHART_DIR = DATA_DIR / "charts"
for path in (UPLOAD_DIR, REPORT_DIR, CHART_DIR):
    path.mkdir(parents=True, exist_ok=True)

TSHARK_BIN = os.getenv("TSHARK_BIN", "tshark")
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "500"))
ANALYSIS_TIMEOUT_SECONDS = int(os.getenv("ANALYSIS_TIMEOUT_SECONDS", "1800"))
