from pydantic import BaseModel, Field
from typing import Any

class Progress(BaseModel):
    job_id: str
    percent: int = Field(ge=0, le=100)
    stage: str
    message: str
    status: str = "running"

class JobStatus(BaseModel):
    job_id: str
    filename: str
    status: str
    percent: int
    stage: str
    message: str
    error: str | None = None
    report: dict[str, Any] | None = None
