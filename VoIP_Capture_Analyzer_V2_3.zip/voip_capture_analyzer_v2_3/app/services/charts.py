import base64
import io
from collections import Counter
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def img_data(fig):
    buf = io.BytesIO()
    fig.tight_layout()
    fig.savefig(buf, format="png", dpi=150, bbox_inches="tight")
    plt.close(fig)
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def empty(ax, message="Sem dados suficientes"):
    ax.text(0.5, 0.5, message, ha="center", va="center", transform=ax.transAxes)


def make_charts(data, job_id=None):
    macro = data["macro"]
    calls = data["calls"]
    charts = {}

    codes = macro.get("response_codes", {})
    fig, ax = plt.subplots(figsize=(7, 4))
    if codes:
        ax.bar(list(codes.keys()), list(codes.values()))
    else:
        empty(ax)
    ax.set_title("Distribuição de códigos de resposta SIP")
    ax.set_xlabel("Código")
    ax.set_ylabel("Chamadas")
    charts["response_codes"] = img_data(fig)

    pdds = [c["metrics"].get("pdd_to_answer") for c in calls if c["metrics"].get("pdd_to_answer") is not None]
    fig, ax = plt.subplots(figsize=(7, 4))
    if pdds:
        ax.hist(pdds, bins=min(12, max(4, len(pdds))))
    else:
        empty(ax)
    ax.set_title("Distribuição de PDD até atendimento")
    ax.set_xlabel("Segundos")
    ax.set_ylabel("Chamadas")
    charts["pdd"] = img_data(fig)

    losses, jitters = [], []
    for c in calls:
        loss = c["metrics"]["rtp"].get("loss_pct")
        jitter = c["metrics"]["rtp"].get("jitter_ms")
        if loss is not None and jitter is not None:
            losses.append(loss); jitters.append(jitter)
    fig, ax = plt.subplots(figsize=(7, 4))
    if losses:
        ax.scatter(losses, jitters, alpha=0.75)
    else:
        empty(ax)
    ax.set_title("Perda RTP × Jitter")
    ax.set_xlabel("Perda estimada (%)")
    ax.set_ylabel("Jitter RTP (ms)")
    charts["loss_jitter"] = img_data(fig)

    labels = [c["call_id"][:14] for c in calls if c["metrics"]["rtp"].get("jitter_ms") is not None]
    vals = [c["metrics"]["rtp"]["jitter_ms"] for c in calls if c["metrics"]["rtp"].get("jitter_ms") is not None]
    fig, ax = plt.subplots(figsize=(9, 4))
    if vals:
        ax.bar(labels, vals); ax.tick_params(axis="x", rotation=60)
    else:
        empty(ax)
    ax.set_title("Jitter por chamada")
    ax.set_ylabel("ms")
    charts["jitter_calls"] = img_data(fig)

    labels = [c["call_id"][:14] for c in calls if c["metrics"]["rtp"].get("loss_pct") is not None]
    vals = [c["metrics"]["rtp"]["loss_pct"] for c in calls if c["metrics"]["rtp"].get("loss_pct") is not None]
    fig, ax = plt.subplots(figsize=(9, 4))
    if vals:
        ax.bar(labels, vals); ax.tick_params(axis="x", rotation=60)
    else:
        empty(ax)
    ax.set_title("Perda RTP por chamada")
    ax.set_ylabel("% estimado")
    charts["loss_calls"] = img_data(fig)

    codecs = macro.get("codecs", {})
    fig, ax = plt.subplots(figsize=(7, 4))
    if codecs:
        keys = list(codecs)[:15]
        ax.bar(keys, [codecs[k] for k in keys]); ax.tick_params(axis="x", rotation=45)
    else:
        empty(ax)
    ax.set_title("Distribuição de codecs / payloads SDP")
    ax.set_ylabel("Ocorrências")
    charts["codecs"] = img_data(fig)

    # Temporal concurrency profile.
    events = []
    for c in calls:
        if c.get("start") is not None:
            events.append((c["start"], 1))
        if c.get("end") is not None:
            events.append((c["end"], -1))
    fig, ax = plt.subplots(figsize=(9, 4))
    if events:
        events.sort(key=lambda x: (x[0], -x[1]))
        active = 0; xs = []; ys = []
        for ts, delta in events:
            active += delta; xs.append(ts - events[0][0]); ys.append(active)
        ax.step(xs, ys, where="post")
    else:
        empty(ax)
    ax.set_title("Chamadas simultâneas ao longo da captura")
    ax.set_xlabel("Tempo desde o início (s)")
    ax.set_ylabel("Chamadas simultâneas")
    charts["concurrency"] = img_data(fig)

    # Quality matrix.
    fig, ax = plt.subplots(figsize=(7, 5))
    xs=[]; ys=[]; labels=[]
    for c in calls:
        x=c["metrics"]["rtp"].get("loss_pct"); y=c["metrics"]["rtp"].get("jitter_ms")
        if x is not None and y is not None:
            xs.append(x); ys.append(y); labels.append(c["call_id"][:8])
    if xs:
        ax.scatter(xs, ys, alpha=.75)
        for x,y,label in zip(xs,ys,labels): ax.annotate(label,(x,y),fontsize=7,xytext=(4,4),textcoords="offset points")
        ax.axvline(1, linestyle="--"); ax.axvline(3, linestyle="--"); ax.axhline(20, linestyle="--"); ax.axhline(30, linestyle="--")
    else:
        empty(ax)
    ax.set_title("Matriz de qualidade: perda × jitter")
    ax.set_xlabel("Perda RTP (%)")
    ax.set_ylabel("Jitter RTP (ms)")
    charts["quality_matrix"] = img_data(fig)

    # SIP timing summary.
    vals=[]; labels=[]
    for c in calls:
        for key, label in (("pdd_to_trying","100 Trying"),("pdd_to_progress","180/183"),("pdd_to_answer","200 OK")):
            v=c["metrics"].get(key)
            if v is not None:
                vals.append(v); labels.append(label)
    fig, ax = plt.subplots(figsize=(8,4))
    if vals:
        ax.boxplot(vals)
        ax.set_xticklabels(["SIP timing"])
    else:
        empty(ax)
    ax.set_title("Distribuição dos tempos de estabelecimento SIP")
    ax.set_ylabel("Segundos")
    charts["sip_timing"] = img_data(fig)
    return charts
