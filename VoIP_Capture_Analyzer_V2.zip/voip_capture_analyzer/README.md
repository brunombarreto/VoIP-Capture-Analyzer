# VoIP Capture Analyzer — V2

Dashboard Web para análise de arquivos estáticos `.cap`, `.pcap` e `.pcapng`, com FastAPI, WebSocket, TShark, Matplotlib, WeasyPrint e python-docx.

## Principais capacidades

- Upload via navegador com Drag & Drop.
- Progresso em tempo real via WebSocket.
- Extração de SIP, SDP, RTP e RTCP por TShark.
- Correlação conservadora de RTP com Call-ID usando janela temporal e IP/porta declarados no SDP.
- Reconstrução de transações SIP e distinção de INVITE inicial/re-INVITE.
- PDD dividido em INVITE→100, INVITE→180/183 e INVITE→200.
- Retransmissões/duplicações aparentes por branch/CSeq/endpoint.
- RTP por SSRC/direção: sequência, perda estimada, jitter interarrival quando clock rate é inferível, delta, PPS e duração.
- Detecção de RTP unilateral e ausência de RTP após atendimento.
- KPIs macro: ASR, PDD, jitter, perda, RTCP, codecs, retransmissões e pico de simultaneidade.
- Diagnóstico automático com severidade e confiança.
- Dashboard com gráficos técnicos.
- PDF e DOCX.

## Correção do erro da V1

A V1 usava a forma posicional antiga do `TemplateResponse`. A V2 utiliza a API atual:

```python
return templates.TemplateResponse(
    request=request,
    name="index.html",
    context={}
)
```

Isso evita o `TypeError: unhashable type: 'dict'` observado com versões atuais do Starlette.

## Instalação

```bash
python3.11 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Verifique:

```bash
tshark --version
```

Execute:

```bash
IP=$(hostname -I | awk '{print $1}')
uvicorn app.main:app --host "$IP" --port 8000
```

Acesse:

```text
http://IP_DO_SERVIDOR:8000
```

## Observações técnicas

1. O ponto de captura define o limite das conclusões.
2. MOS/NER não são inventados sem dados suficientes.
3. A perda RTP é estimada por gaps de sequência.
4. O jitter segue o cálculo de interarrival quando o clock rate é conhecido; isso não deve ser confundido com um valor RTCP reportado pelo endpoint.
5. O TShark pode alterar disponibilidade/nomenclatura de campos entre versões; valide `tshark -G fields` no servidor.
6. Para produção, recomenda-se autenticação, quotas, retenção, antivírus/sandbox, armazenamento externo, fila persistente e isolamento de arquivos PCAP não confiáveis.
