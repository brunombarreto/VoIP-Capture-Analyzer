"""Pure-Python compatibility parser used only when TShark SIP/RTP extraction is incomplete.
It understands classic pcap files with Linux cooked v1 (SLL) or Ethernet and IPv4/UDP.
It intentionally keeps raw packet evidence conservative; TShark remains the primary decoder.
"""
from __future__ import annotations
import re, socket, struct
from pathlib import Path

SIP_START = re.compile(rb"^(?:[A-Z][A-Z0-9_-]{1,15} sip:|SIP/2\.0 )")


def _header(headers: dict[str, str], *names: str) -> str:
    for name in names:
        v = headers.get(name.lower())
        if v is not None:
            return v
    return ""


def parse_sip_payload(payload: bytes) -> dict | None:
    if not SIP_START.match(payload):
        return None
    text = payload.decode("latin1", "replace")
    head = text.split("\r\n\r\n", 1)[0].split("\n\n", 1)[0]
    body = ""
    if "\r\n\r\n" in text:
        body = text.split("\r\n\r\n", 1)[1]
    elif "\n\n" in text:
        body = text.split("\n\n", 1)[1]
    headers: dict[str, str] = {}
    for line in head.replace("\r", "").split("\n")[1:]:
        if ":" in line:
            k, v = line.split(":", 1)
            headers[k.strip().lower()] = v.strip()
    first = head.replace("\r", "").split("\n", 1)[0].strip()
    method = ""
    status = ""
    request_line = ""
    if first.startswith("SIP/2.0 "):
        parts = first.split()
        if len(parts) >= 2 and parts[1].isdigit():
            status = parts[1]
    else:
        request_line = first
        method = first.split(" ", 1)[0]
    cseq = _header(headers, "cseq")
    cseq_parts = cseq.split()
    if not method and len(cseq_parts) >= 2:
        method = cseq_parts[-1]
    call_id = _header(headers, "call-id", "i")
    via = _header(headers, "via", "v")
    branch = ""
    m = re.search(r"(?:^|;)branch=([^;\s]+)", via)
    if m:
        branch = m.group(1)
    from_uri = _header(headers, "from", "f")
    to_uri = _header(headers, "to", "t")
    # Extract SDP lines from the body without assuming valid MIME framing beyond Content-Type.
    sdp_lines = []
    for line in body.replace("\x00", "").replace("\r", "").split("\n"):
        if re.match(r"^[vostmcai]=", line):
            sdp_lines.append(line.strip())
    return {
        "call_id": call_id,
        "method": method,
        "status": status,
        "cseq": cseq,
        "cseq_seq": cseq_parts[0] if cseq_parts else "",
        "cseq_method": cseq_parts[-1] if len(cseq_parts) >= 2 else method,
        "from": from_uri,
        "to": to_uri,
        "via": via,
        "branch": branch,
        "contact": _header(headers, "contact", "m"),
        "user_agent": _header(headers, "user-agent"),
        "server": _header(headers, "server"),
        "reason": _header(headers, "reason"),
        "request_line": request_line,
        "sdp": sdp_lines,
        "body": body,
    }


def iter_udp_packets(capture: Path):
    data = capture.read_bytes()
    if len(data) < 24:
        return
    magic = struct.unpack_from("<I", data, 0)[0]
    if magic == 0xA1B2C3D4:
        endian = "<"
    elif magic == 0xD4C3B2A1:
        endian = ">"
    else:
        raise ValueError("Formato PCAP clássico não reconhecido")
    _, _, _, _, _, _, network = struct.unpack_from(endian + "IHHIIII", data, 0)
    # Network 113 = Linux cooked capture v1; 1 = Ethernet.
    off = 24
    frame = 0
    while off + 16 <= len(data):
        ts_s, ts_u, incl, _ = struct.unpack_from(endian + "IIII", data, off)
        off += 16
        pkt = data[off:off + incl]
        off += incl
        frame += 1
        if network == 113:
            if len(pkt) < 16:
                continue
            ethertype = struct.unpack_from("!H", pkt, 14)[0]
            l2 = 16
        elif network == 1:
            if len(pkt) < 14:
                continue
            ethertype = struct.unpack_from("!H", pkt, 12)[0]
            l2 = 14
        else:
            continue
        if ethertype != 0x0800 or len(pkt) < l2 + 20:
            continue
        ihl = (pkt[l2] & 0x0F) * 4
        if ihl < 20 or len(pkt) < l2 + ihl:
            continue
        proto = pkt[l2 + 9]
        if proto != 17 or len(pkt) < l2 + ihl + 8:
            continue
        src = socket.inet_ntoa(pkt[l2 + 12:l2 + 16])
        dst = socket.inet_ntoa(pkt[l2 + 16:l2 + 20])
        sp, dp = struct.unpack_from("!HH", pkt, l2 + ihl)
        payload = pkt[l2 + ihl + 8:]
        yield {
            "frame": str(frame),
            "ts": ts_s + ts_u / 1_000_000.0,
            "src": src, "dst": dst, "src_port": str(sp), "dst_port": str(dp),
            "payload": payload, "frame_len": incl,
        }


def extract_sip_from_tshark_udp_rows(rows: list[dict]) -> list[dict]:
    """Reconstruct SIP rows from TShark UDP payload fields; works for PCAP and PCAPNG."""
    result = []
    for p in rows:
        raw = p.get("udp.payload") or ""
        try:
            payload = bytes.fromhex(raw.replace(":", ""))
        except ValueError:
            continue
        parsed = parse_sip_payload(payload)
        if not parsed or not parsed.get("call_id"):
            continue
        result.append({
            "frame.number": p.get("frame.number", ""),
            "frame.time_epoch": p.get("frame.time_epoch", ""),
            "ip.src": p.get("ip.src") or p.get("ipv6.src", ""),
            "ip.dst": p.get("ip.dst") or p.get("ipv6.dst", ""),
            "udp.srcport": p.get("udp.srcport", ""),
            "udp.dstport": p.get("udp.dstport", ""),
            "sip.Call-ID": parsed["call_id"], "sip.Method": parsed["method"],
            "sip.Status-Code": parsed["status"], "sip.CSeq": parsed["cseq"],
            "sip.CSeq.seq": parsed["cseq_seq"], "sip.CSeq.method": parsed["cseq_method"],
            "sip.from.uri": parsed["from"], "sip.to.uri": parsed["to"],
            "sip.User-Agent": parsed["user_agent"], "sip.Server": parsed["server"],
            "sip.Reason": parsed["reason"], "sip.Via.branch": parsed["branch"],
            "sip.request_line": parsed["request_line"], "sip.From": parsed["from"],
            "sip.To": parsed["to"], "sip.Via": parsed["via"], "sip.Contact": parsed["contact"],
            "__raw_sdp_lines": parsed["sdp"], "__raw_source": "tshark-udp-payload-fallback",
        })
    return result


def extract_sip(capture: Path) -> list[dict]:
    rows = []
    for p in iter_udp_packets(capture):
        parsed = parse_sip_payload(p["payload"])
        if not parsed or not parsed["call_id"]:
            continue
        row = {
            "frame.number": p["frame"], "frame.time_epoch": str(p["ts"]),
            "ip.src": p["src"], "ip.dst": p["dst"],
            "udp.srcport": p["src_port"], "udp.dstport": p["dst_port"],
            "sip.Call-ID": parsed["call_id"], "sip.Method": parsed["method"],
            "sip.Status-Code": parsed["status"], "sip.CSeq": parsed["cseq"],
            "sip.CSeq.seq": parsed["cseq_seq"], "sip.CSeq.method": parsed["cseq_method"],
            "sip.from.uri": parsed["from"], "sip.to.uri": parsed["to"],
            "sip.User-Agent": parsed["user_agent"], "sip.Server": parsed["server"],
            "sip.Reason": parsed["reason"], "sip.Via.branch": parsed["branch"],
            "sip.request_line": parsed["request_line"], "sip.From": parsed["from"],
            "sip.To": parsed["to"], "sip.Via": parsed["via"], "sip.Contact": parsed["contact"],
            "__raw_sdp_lines": parsed["sdp"], "__raw_source": "python-pcap-fallback",
        }
        rows.append(row)
    return rows


def parse_sdp_endpoints(sip_rows: list[dict]) -> dict[str, set[tuple[str, int]]]:
    result: dict[str, set[tuple[str, int]]] = {}
    for row in sip_rows:
        cid = row.get("sip.Call-ID") or ""
        lines = row.get("__raw_sdp_lines") or []
        if not cid or not lines:
            continue
        addr = ""
        for line in lines:
            if line.startswith("c=IN IP4 "):
                addr = line.split(" ", 2)[2].strip()
            elif line.startswith("m=audio "):
                parts = line.split()
                if len(parts) >= 2:
                    try:
                        result.setdefault(cid, set()).add((addr, int(parts[1])))
                    except ValueError:
                        pass
    return result


def extract_rtp(capture: Path, sip_rows: list[dict]) -> tuple[list[dict], list[dict]]:
    """Extract RTP/RTCP using SDP media ports. IP matching is optional because anonymized captures may rewrite IPs."""
    media_by_call: dict[str, set[int]] = {}
    for cid, endpoints in parse_sdp_endpoints(sip_rows).items():
        for _, port in endpoints:
            media_by_call.setdefault(cid, set()).add(port)
    # Also accept m=audio ports directly from SIP bodies if addresses are unavailable.
    port_pairs: dict[tuple[int, int], set[str]] = {}
    for row in sip_rows:
        cid = row.get("sip.Call-ID") or ""
        for line in row.get("__raw_sdp_lines") or []:
            if line.startswith("m=audio "):
                parts = line.split()
                if len(parts) >= 2:
                    try:
                        p = int(parts[1])
                        media_by_call.setdefault(cid, set()).add(p)
                    except ValueError:
                        pass
    all_ports = set(p for ps in media_by_call.values() for p in ps)
    rtp = []
    rtcp = []
    for p in iter_udp_packets(capture):
        sp, dp = int(p["src_port"]), int(p["dst_port"])
        if sp not in all_ports and dp not in all_ports and sp - 1 not in all_ports and dp - 1 not in all_ports:
            continue
        payload = p["payload"]
        if len(payload) < 8 or (payload[0] >> 6) != 2:
            continue
        pt = payload[1] & 0x7F
        # RTCP packet types occupy 192..223.  The first byte/version and PT are sufficient here.
        if 192 <= payload[1] <= 223:
            rtcp.append({
                "frame.number": p["frame"], "frame.time_epoch": str(p["ts"]),
                "ip.src": p["src"], "ip.dst": p["dst"], "udp.srcport": p["src_port"], "udp.dstport": p["dst_port"],
                "rtcp.ssrc": str(struct.unpack_from("!I", payload, 4)[0]) if len(payload) >= 8 else "",
                "rtcp.packet_type": str(payload[1]), "__raw_source": "python-pcap-fallback",
            })
            continue
        if len(payload) < 12:
            continue
        # Exclude obvious RTCP by payload type even when the dissector sees a colliding value.
        if pt >= 72 and pt <= 76:
            # Static RTP PT 72-76 are RTCP overlap values; in this capture they are RTCP SR/RR packets.
            continue
        seq = struct.unpack_from("!H", payload, 2)[0]
        rtp_ts = struct.unpack_from("!I", payload, 4)[0]
        ssrc = struct.unpack_from("!I", payload, 8)[0]
        rtp.append({
            "frame.number": p["frame"], "frame.time_epoch": str(p["ts"]),
            "ip.src": p["src"], "ip.dst": p["dst"], "udp.srcport": p["src_port"], "udp.dstport": p["dst_port"],
            "rtp.ssrc": str(ssrc), "rtp.seq": str(seq), "rtp.timestamp": str(rtp_ts), "rtp.p_type": str(pt),
            "__raw_source": "python-pcap-fallback",
        })
    return rtp, rtcp


def inventory(capture: Path) -> dict:
    counts = {"sip": 0, "sdp": 0, "rtp": 0, "rtcp": 0, "udp": 0, "tcp": 0}
    sip = extract_sip(capture)
    counts["sip"] = len(sip)
    counts["sdp"] = sum(1 for r in sip if r.get("__raw_sdp_lines"))
    rtp, rtcp = extract_rtp(capture, sip)
    counts["rtp"] = len(rtp)
    counts["rtcp"] = len(rtcp)
    for p in iter_udp_packets(capture):
        counts["udp"] += 1
    return {"counts": counts, "source": "python-pcap-fallback"}
