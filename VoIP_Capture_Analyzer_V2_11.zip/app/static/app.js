// Copyright (c) 2026 Bruno Barreto
// This source code is licensed under the MIT license found in the
// LICENSE file in the root directory of this source tree.

(function () {
  'use strict';

  const state = {
    file: null,
    busy: false,
    progress: 0,
    message: '',
    job: null,
    report: null,
    tab: 'exec',
    stages: [
      { p: 4, t: 'Metadados' }, { p: 12, t: 'SIP' }, { p: 26, t: 'SDP' }, { p: 42, t: 'RTP' },
      { p: 58, t: 'RTCP' }, { p: 68, t: 'Correlação' }, { p: 86, t: 'Diagnóstico' }, { p: 97, t: 'Relatório' }
    ],
    chartNames: ['response_codes', 'pdd', 'loss_jitter', 'jitter_calls', 'loss_calls', 'codecs', 'concurrency', 'quality_matrix', 'sip_timing']
  };

  const $ = (id) => document.getElementById(id);
  const els = {};

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>'"]/g, (c) => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', "'":'&#39;', '"':'&quot;' })[c]);
  }

  function fmt(value, suffix = '') {
    if (value === null || value === undefined || value === '') return 'N/A';
    const n = Number(value);
    return Number.isFinite(n) ? n.toFixed(2) + suffix : 'N/A';
  }

  function setBusy(value) {
    state.busy = value;
    els.analyzeButton.disabled = !state.file || value;
    els.analyzeButton.textContent = value ? 'Processando...' : 'Analisar captura';
  }

  function setProgress(percent, message) {
    state.progress = Math.max(0, Math.min(100, Number(percent) || 0));
    state.message = message || state.message;
    els.progressPercent.textContent = state.progress + '%';
    els.progressMessage.textContent = state.message;
    els.progressBar.style.width = state.progress + '%';
    renderStages();
  }

  function renderStages() {
    els.stages.innerHTML = state.stages.map(s => {
      const active = state.progress >= s.p;
      return `<div class="text-center text-[10px] ${active ? 'text-cyan-400' : 'text-slate-600'}"><div class="h-2 rounded ${active ? 'bg-cyan-700' : 'bg-slate-800'}"></div><div class="mt-1">${escapeHtml(s.t)}</div></div>`;
    }).join('');
  }

  function setFile(file) {
    if (!file) return;
    const name = (file.name || '').toLowerCase();
    if (!['.cap', '.pcap', '.pcapng'].some(ext => name.endsWith(ext))) {
      alert('Formato não suportado. Selecione um arquivo .cap, .pcap ou .pcapng.');
      return;
    }
    state.file = file;
    state.report = null;
    state.job = null;
    els.fileName.textContent = file.name;
    els.selectionMessage.textContent = `Arquivo selecionado: ${file.name} (${formatBytes(file.size)})`;
    els.reportSection.classList.add('hidden');
    els.progressSection.classList.add('hidden');
    setBusy(false);
    setProgress(0, 'Arquivo selecionado. Clique em “Analisar captura”.');
  }

  function formatBytes(bytes) {
    if (!Number.isFinite(bytes)) return '';
    if (bytes < 1024) return bytes + ' B';
    const units = ['KB', 'MB', 'GB', 'TB'];
    let n = bytes / 1024, i = 0;
    while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
    return n.toFixed(2) + ' ' + units[i];
  }

  async function checkHealth() {
    try {
      const response = await fetch('/api/health', { cache: 'no-store' });
      const data = await response.json();
      if (data.ok) {
        els.healthBadge.textContent = 'TShark OK';
        els.healthBadge.className = 'text-xs px-3 py-1 rounded-full bg-emerald-900 text-emerald-300';
        els.healthBadge.title = data.version || '';
      } else {
        els.healthBadge.textContent = 'TShark indisponível';
        els.healthBadge.className = 'text-xs px-3 py-1 rounded-full bg-amber-900 text-amber-300';
        els.healthBadge.title = data.error || '';
      }
    } catch (error) {
      els.healthBadge.textContent = 'Backend indisponível';
      els.healthBadge.className = 'text-xs px-3 py-1 rounded-full bg-red-900 text-red-300';
      els.healthBadge.title = error.message;
    }
  }

  async function upload() {
    if (!state.file || state.busy) return;
    setBusy(true);
    els.progressSection.classList.remove('hidden');
    els.reportSection.classList.add('hidden');
    setProgress(1, 'Enviando arquivo para o servidor...');

    try {
      const fd = new FormData();
      fd.append('file', state.file, state.file.name);
      const response = await fetch('/api/analyze', { method: 'POST', body: fd });
      let data = {};
      try { data = await response.json(); } catch (_) {}
      if (!response.ok) throw new Error(data.detail || `Falha no upload (HTTP ${response.status}).`);
      state.job = data.job_id;
      setProgress(2, 'Arquivo recebido. Iniciando análise...');
      await connectWebSocket(state.job);
    } catch (error) {
      console.error(error);
      setProgress(state.progress, error.message || 'Falha durante o envio.');
      alert(error.message || 'Falha durante o envio.');
      setBusy(false);
    }
  }

  function connectWebSocket(jobId) {
    return new Promise((resolve, reject) => {
      const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${protocol}//${location.host}/ws/${encodeURIComponent(jobId)}`);
      let settled = false;
      let fallbackTimer = null;

      const done = (fn, value) => {
        if (settled) return;
        settled = true;
        if (fallbackTimer) clearTimeout(fallbackTimer);
        fn(value);
      };

      ws.onopen = () => setProgress(state.progress, 'Conectado ao processamento em tempo real.');
      ws.onmessage = async (event) => {
        try {
          const data = JSON.parse(event.data);
          setProgress(data.percent, data.message);
          if (data.status === 'completed') {
            try {
              await loadReport(jobId);
              setProgress(100, 'Análise concluída com sucesso.');
              setBusy(false);
              ws.close();
              done(resolve);
            } catch (error) {
              ws.close();
              done(reject, error);
            }
          } else if (data.status === 'error') {
            ws.close();
            setBusy(false);
            done(reject, new Error(data.error || data.message || 'Falha durante a análise.'));
          }
        } catch (error) {
          done(reject, error);
        }
      };
      ws.onerror = () => {
        fallbackTimer = setTimeout(() => pollJob(jobId, resolve, reject), 250);
      };
      ws.onclose = () => {
        if (!settled) fallbackTimer = setTimeout(() => pollJob(jobId, resolve, reject), 250);
      };
    });
  }

  async function pollJob(jobId, resolve, reject) {
    if (!state.busy) return;
    try {
      const job = await getJob(jobId);
      setProgress(job.percent, job.message);
      if (job.status === 'completed') {
        await loadReport(jobId);
        setProgress(100, 'Análise concluída com sucesso.');
        setBusy(false);
        resolve();
        return;
      }
      if (job.status === 'error') {
        setBusy(false);
        reject(new Error(job.error || job.message || 'Falha durante a análise.'));
        return;
      }
      setTimeout(() => pollJob(jobId, resolve, reject), 750);
    } catch (error) {
      setBusy(false);
      reject(error);
    }
  }

  async function getJob(jobId) {
    const response = await fetch(`/api/jobs/${encodeURIComponent(jobId)}`, { cache: 'no-store' });
    if (!response.ok) throw new Error(`Não foi possível consultar o job (HTTP ${response.status}).`);
    return response.json();
  }

  async function loadReport(jobId) {
    const job = await getJob(jobId);
    if (job.status === 'error') throw new Error(job.error || job.message || 'Falha durante a análise.');
    if (!job.report) throw new Error('O processamento terminou, mas o relatório não foi encontrado.');
    state.report = job.report;
    renderReport();
  }

  function renderReport() {
    const data = state.report.data || {};
    const macro = data.macro || {};
    const kpis = [
      ['Saúde', macro.health ?? 'N/A'], ['Chamadas', macro.calls ?? 0], ['ASR', fmt(macro.asr_pct, '%')],
      ['PDD médio', fmt(macro.pdd_avg_s, ' s')], ['Jitter p95', fmt(macro.jitter_p95_ms, ' ms')],
      ['Perda média', fmt(macro.loss_avg_pct, '%')], ['RTP unilateral', macro.one_way_calls ?? 0], ['Pico simultâneo', macro.concurrent_peak ?? 0]
    ];
    els.kpis.innerHTML = kpis.map(k => `<div class="bg-slate-900 border border-slate-800 rounded-xl p-5"><div class="text-xs text-slate-400">${escapeHtml(k[0])}</div><div class="text-2xl font-bold mt-2">${escapeHtml(k[1])}</div></div>`).join('');

    els.tabExec.innerHTML = `<h2 class="text-2xl font-bold mb-3">Resumo Executivo</h2><p class="text-slate-300 mb-6">${escapeHtml(`A captura foi classificada como ${macro.health ?? 'N/A'}. Foram identificadas ${macro.calls ?? 0} tentativas, ASR de ${fmt(macro.asr_pct, '%')}, ${macro.degraded_calls ?? 0} chamadas com anomalias e ${macro.critical_calls ?? 0} chamadas críticas. O pico de simultaneidade observado foi ${macro.concurrent_peak ?? 0}.`)}</p><div class="grid lg:grid-cols-2 gap-6">${state.chartNames.map(name => dataUrl(state.report.charts?.[name]) ? `<img src="${dataUrl(state.report.charts[name])}" alt="${escapeHtml(name)}" class="rounded-xl bg-white p-2 w-full">` : '').join('')}</div>`;

    const calls = Array.isArray(data.calls) ? data.calls : [];
    els.tabCalls.innerHTML = `<h2 class="text-2xl font-bold mb-4">Chamadas</h2><div class="overflow-auto"><table class="w-full text-sm"><thead><tr class="border-b border-slate-700 text-left"><th class="p-3">Call-ID</th><th class="p-3">Status</th><th class="p-3">Duração</th><th class="p-3">PDD</th><th class="p-3">Perda</th><th class="p-3">Jitter</th><th class="p-3">Anomalias</th></tr></thead><tbody>${calls.map(c => { const m=c.metrics||{}, r=m.rtp||{}; return `<tr class="border-b border-slate-800 hover:bg-slate-800/50"><td class="p-3 font-mono text-xs">${escapeHtml(c.call_id)}</td><td class="p-3">${escapeHtml(m.final_status ?? 'N/A')}</td><td class="p-3">${escapeHtml(fmt(m.duration,' s'))}</td><td class="p-3">${escapeHtml(fmt(m.pdd_to_answer,' s'))}</td><td class="p-3">${escapeHtml(fmt(r.loss_pct,'%'))}</td><td class="p-3">${escapeHtml(fmt(r.jitter_ms,' ms'))}</td><td class="p-3">${Array.isArray(c.anomalies)?c.anomalies.length:0}</td></tr>`; }).join('')}</tbody></table></div>`;

    els.tabDiagnosis.innerHTML = `<h2 class="text-2xl font-bold mb-4">Diagnóstico consolidado</h2>${calls.map(c => { const anomalies=Array.isArray(c.anomalies)?c.anomalies:[]; if(!anomalies.length)return ''; return `<div class="border border-slate-800 rounded-xl p-4 mb-3"><div class="font-mono text-xs mb-2">${escapeHtml(c.call_id)}</div>${anomalies.map(a => `<div class="mb-3"><div class="font-bold">${escapeHtml(String(a.severity||'').toUpperCase())} / ${escapeHtml(a.confidence||'')}</div><p>${escapeHtml(a.finding||'')}</p><p class="text-slate-400 text-sm">Impacto: ${escapeHtml(a.impact||'')}</p><p class="text-cyan-400 text-sm">Recomendação: ${escapeHtml(a.recommendation||'')}</p></div>`).join('')}</div>`; }).join('') || '<p class="text-slate-400">Nenhuma anomalia diagnosticada.</p>'}`;
    els.tabMethod.innerHTML = `<h2 class="text-2xl font-bold mb-4">Metodologia e limitações</h2><p class="text-slate-300">Os fatos observados são separados das métricas calculadas e das inferências. Jitter usa cálculo de interarrival quando o clock rate pode ser inferido. MOS e NER não são inventados. O ponto de captura limita conclusões sobre o caminho remoto.</p><div class="mt-5 text-sm text-slate-400 space-y-2"><p><b>Como usar:</b> selecione ou arraste uma captura .cap/.pcap/.pcapng, clique em “Analisar captura”, acompanhe o processamento e consulte as abas de resultado. REGISTER e OPTIONS aparecem como controle SIP, mas não contam como chamadas.</p><p><b>Rastreabilidade:</b> o nome original do arquivo enviado é preservado no relatório.</p><p><b>Exportação:</b> use o menu PDF/DOCX para baixar ou abrir o arquivo em nova janela.</p></div>`;

    const glossary = Array.isArray(data.glossary) ? data.glossary : [
      ['SIP','Protocolo de sinalização de sessões VoIP.'], ['SDP','Descrição da sessão, codec, IP e portas de mídia.'],
      ['RTP','Transporte de mídia em tempo real.'], ['RTCP','Controle e estatísticas complementares ao RTP.'],
      ['ASR','Proporção de tentativas de chamada que chegam a atendimento.'], ['PDD','Tempo entre o início da tentativa e o atendimento, conforme a definição operacional do Analyzer.'],
      ['Jitter','Variação do intervalo de chegada dos pacotes RTP.'], ['Bitrate','Taxa média de bits por segundo.'], ['Codec','Formato/algoritmo de codificação de áudio.'],
      ['B2BUA','Elemento que mantém pernas SIP relacionadas de uma mesma chamada lógica.'], ['SBC','Session Border Controller.'], ['PBX','Central telefônica privada.'],
      ['Firewall','Controle de tráfego baseado em regras.'], ['QoS','Mecanismos de priorização de tráfego.'], ['DSCP','Marcação de classe/prioridade IP.'],
      ['SSRC','Identificador da fonte RTP.'], ['Payload Type','Identificador do formato de carga RTP.'], ['Call-ID','Identificador SIP de correlação da sessão.'],
      ['Re-INVITE','INVITE dentro de uma sessão já estabelecida.'], ['One-way RTP','RTP observado em apenas um sentido.']
    ];
    els.tabGlossary.innerHTML = `<h2 class="text-2xl font-bold mb-4">Glossário</h2><div class="overflow-auto"><table class="w-full text-sm"><thead><tr class="border-b border-slate-700 text-left"><th class="p-3">Termo</th><th class="p-3">Explicação</th></tr></thead><tbody>${glossary.map(g => `<tr class="border-b border-slate-800"><td class="p-3 font-semibold">${escapeHtml(g[0])}</td><td class="p-3 text-slate-300">${escapeHtml(g[1])}</td></tr>`).join('')}</tbody></table></div>`;

    els.reportSection.classList.remove('hidden');
    showTab('exec');
  }

  function dataUrl(value) {
    if (!value) return '';
    if (String(value).startsWith('data:image/')) return value;
    return '';
  }

  function showTab(tab) {
    state.tab = tab;
    const tabs = [ ['exec','Executivo'], ['calls','Chamadas'], ['diagnosis','Diagnóstico'], ['method','Metodologia'], ['glossary','Glossário'] ];
    els.tabs.innerHTML = tabs.map(t => `<button type="button" data-tab="${t[0]}" class="px-4 py-2 rounded-lg ${tab===t[0]?'bg-cyan-700':'bg-slate-800 hover:bg-slate-700'}">${t[1]}</button>`).join('');
    tabs.forEach(t => els['tab'+t[0].charAt(0).toUpperCase()+t[0].slice(1)].classList.toggle('hidden', tab !== t[0]));
    els.tabs.querySelectorAll('[data-tab]').forEach(btn => btn.addEventListener('click', () => showTab(btn.dataset.tab)));
  }

  function toggleMenu(menu) {
    if (!menu) return;
    menu.classList.toggle('hidden');
  }

  function reportUrl(kind, open = false) {
    if (!state.job) return '';
    return `/api/jobs/${encodeURIComponent(state.job)}/download/${kind}${open ? '?mode=open' : ''}`;
  }

  function downloadReport(kind) {
    const url = reportUrl(kind);
    if (!url) return;
    window.location.href = url;
  }

  function openReport(kind) {
    const url = reportUrl(kind, true);
    if (!url) return;
    window.open(url, '_blank', 'noopener');
  }

  function reset() {
    state.file = null; state.report = null; state.job = null; state.progress = 0;
    els.fileInput.value = ''; els.fileName.textContent = 'Arraste a captura aqui ou clique para selecionar';
    els.selectionMessage.textContent = ''; els.reportSection.classList.add('hidden'); els.progressSection.classList.add('hidden');
    setBusy(false); setProgress(0, 'Aguardando arquivo...');
  }

  function init() {
    ['dropzone','fileInput','fileName','selectionMessage','analyzeButton','progressSection','progressMessage','progressPercent','progressBar','stages','reportSection','pdfButton','pdfDownload','pdfOpen','pdfMenu','docxButton','docxDownload','docxOpen','docxMenu','newAnalysisButton','kpis','tabs','tabExec','tabCalls','tabDiagnosis','tabMethod','tabGlossary','healthBadge','helpButton','helpMenu'].forEach(id => els[id] = $(id));
    els.fileInput.addEventListener('change', e => setFile(e.target.files?.[0]));
    els.dropzone.addEventListener('dragover', e => { e.preventDefault(); els.dropzone.classList.add('border-cyan-500'); });
    els.dropzone.addEventListener('dragleave', () => els.dropzone.classList.remove('border-cyan-500'));
    els.dropzone.addEventListener('drop', e => { e.preventDefault(); els.dropzone.classList.remove('border-cyan-500'); setFile(e.dataTransfer.files?.[0]); });
    els.analyzeButton.addEventListener('click', upload);
    els.pdfButton.addEventListener('click', () => toggleMenu(els.pdfMenu));
    els.docxButton.addEventListener('click', () => toggleMenu(els.docxMenu));
    els.pdfDownload.addEventListener('click', () => downloadReport('pdf'));
    els.pdfOpen.addEventListener('click', () => openReport('pdf'));
    els.docxDownload.addEventListener('click', () => downloadReport('docx'));
    els.docxOpen.addEventListener('click', () => openReport('docx'));
    els.helpButton.addEventListener('click', () => toggleMenu(els.helpMenu));
    document.addEventListener('click', (event) => {
      if (!event.target.closest('#helpButton') && !event.target.closest('#helpMenu')) els.helpMenu.classList.add('hidden');
      if (!event.target.closest('#pdfButton') && !event.target.closest('#pdfMenu')) els.pdfMenu.classList.add('hidden');
      if (!event.target.closest('#docxButton') && !event.target.closest('#docxMenu')) els.docxMenu.classList.add('hidden');
    });
    els.newAnalysisButton.addEventListener('click', reset);
    renderStages(); setProgress(0, 'Aguardando arquivo...'); setBusy(false); checkHealth();
  }

  document.addEventListener('DOMContentLoaded', init);
})();
