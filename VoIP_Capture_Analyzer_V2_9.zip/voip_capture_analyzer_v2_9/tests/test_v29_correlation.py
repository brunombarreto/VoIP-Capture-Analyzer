from app.analyzers.engine import CaptureAnalyzer
from app.analyzers.models import Call, SipMessage

def msg(ts, cid, method="", status=None, cseq="", cm="", src="", dst="", sp="5060", dp="5060", fr="sip:2001@x", to="sip:2002@y"):
    return SipMessage(ts, cid, method, status, cm, cseq, src=src, dst=dst, src_port=sp, dst_port=dp, from_uri=fr, to_uri=to)

def sample_calls():
    a = Call("A")
    b = Call("B")
    a.messages = [
        msg(8.104,"A","INVITE",None,"24205","INVITE","192.168.0.101","192.168.0.105"),
        msg(8.106,"A",status=401,cseq="24205",cm="INVITE",src="192.168.0.105",dst="192.168.0.101"),
        msg(8.107,"A","INVITE",None,"24206","INVITE","192.168.0.101","192.168.0.105"),
        msg(15.352,"A",status=200,cseq="24206",cm="INVITE",src="192.168.0.105",dst="192.168.0.101"),
        msg(60.106,"A","BYE",None,"13088","BYE","192.168.0.105","192.168.0.101"),
    ]
    b.messages = [
        msg(8.363,"B","INVITE",None,"10381","INVITE","192.168.0.105","192.168.0.101","5061","5060"),
        msg(8.380,"B",status=180,cseq="10381",cm="INVITE",src="192.168.0.101",dst="192.168.0.105",sp="5060",dp="5061"),
        msg(15.336,"B",status=200,cseq="10381",cm="INVITE",src="192.168.0.101",dst="192.168.0.105",sp="5060",dp="5061"),
        msg(58.542,"B","BYE",None,"15350","BYE","192.168.0.105","192.168.0.101","5061","5060"),
    ]
    return a,b

def test_b2bua_legs_are_merged():
    analyzer = CaptureAnalyzer()
    a,b = sample_calls()
    calls = analyzer._merge_logical_legs({"A":a,"B":b})
    assert list(calls) == ["A"]
    call = calls["A"]
    assert call.leg_call_ids == ["A","B"]
    assert call.correlation["type"] == "B2BUA/multi-leg"

def test_authenticated_invite_is_same_call_and_answered():
    analyzer = CaptureAnalyzer()
    a,b = sample_calls()
    calls = analyzer._merge_logical_legs({"A":a,"B":b})
    call = calls["A"]
    analyzer._metrics(call)
    assert call.metrics["answered"] is True
    assert call.metrics["effective_invite_cseq"] == "24206"
    assert call.metrics["authentication_challenges"] == 1
    assert call.metrics["bye_count"] == 2
    assert abs(call.metrics["end"] - 60.106) < 0.001
