# VoIP Capture Analyzer v2.2

V2.2 mantém o backend SIP/SDP/RTP/RTCP da V2 e substitui o frontend Alpine por JavaScript vanilla servido como arquivo estático. Isso elimina problemas de escopo/ordem de execução de Alpine (`voipAnalyzer is not defined`, `pick is not defined`, `upload is not defined`).

A aplicação usa FastAPI/Uvicorn, WebSocket, TShark, Matplotlib, WeasyPrint e python-docx.

## Execução

```bash
python3.11 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
tshark --version
IP=$(hostname -I | awk '{print $1}')
uvicorn app.main:app --host "$IP" --port 8000
```

Acesse `http://IP:8000`.

## Frontend

O JavaScript está em `app/static/app.js` e é servido por FastAPI em `/static/app.js`. Não há dependência de Alpine para o funcionamento do upload, WebSocket ou dashboard.


## V2.4 — Reconstrução SIP/RTP robusta

A V2.4 mantém o TShark como decodificador primário, mas adiciona um fallback conservador em Python para PCAP clássico com Linux SLL/IPv4/UDP quando a exportação de campos do TShark estiver vazia ou incompleta. O fallback reconstrói Call-ID/CSeq/From/To, extrai SDP, identifica portas de mídia e correlaciona RTP/RTCP por portas, evitando falsos zero-call e erros causados por IPs anonimizados/NAT.

Também corrige a contagem de re-INVITE: somente requisições INVITE sem código de resposta são consideradas re-INVITE. A análise RTP passa a usar direção por portas e registra interrupções assimétricas de mídia, além de one-way RTP completo.
