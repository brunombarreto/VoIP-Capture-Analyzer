# VoIP Capture Analyzer V2.7

## Architecture change

V2.7 makes TShark/Wireshark the sole packet dissector.

- No physical PCAP/PCAPNG parsing in the application analysis path.
- SIP/SDP are extracted through TShark.
- RTP/RTCP are extracted through TShark dissectors.
- If RTP is not auto-dissected, the application derives candidate UDP media ports from SDP and asks TShark for those UDP frames.
- Python is responsible for correlation, KPI calculation, diagnostics, graphs and report generation.
- A failure in a secondary fallback must not mask the original analysis error.

This avoids rejecting valid PCAP/PCAPNG captures that TShark, Wireshark, tcpdump or sngrep can read.
