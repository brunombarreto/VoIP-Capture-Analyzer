# VoIP Capture Analyzer V2.9.1

## Objetivo
Dashboard Web para análise de capturas `.cap`, `.pcap` e `.pcapng`, com TShark como decodificador primário de SIP/SDP/RTP/RTCP.

## Principais correções da V2.9.1

### Correção de compatibilidade TShark
- Corrigido o argumento `-E quote` usado na extração de payload UDP. A implementação anterior emitia `quote="`, que não é uma opção válida do TShark. O valor correto é `quote=d`.
- Esse erro afetava justamente a etapa de recuperação do SIP/SDP via payload UDP e, por consequência, podia impedir a descoberta das portas RTP dinâmicas.
- O aviso `Running as user "root"...` é apenas um aviso de segurança do TShark; não representa, por si só, falha da análise.

## Principais correções da V2.9
- RTP agora possui uma cadeia de extração em quatro níveis, sempre mantendo TShark responsável pelo framing da captura:
  1. dissector RTP normal do TShark;
  2. Decode-As RTP nas portas de áudio negociadas no SDP;
  3. Decode-As RTCP nas portas RTP+1 e extração de payload UDP pelo TShark;
  4. parser somente do cabeçalho RTP/RTCP sobre payloads já entregues pelo TShark.
- SDP é recuperado também a partir do payload SIP extraído pelo TShark, evitando dependência exclusiva dos campos `sdp.*` exportados.
- Não existe mais fallback físico obrigatório para leitura do container PCAP/PCAPNG durante a análise de mídia.
- Métricas RTP incluem SSRC, direção, perda por gaps de sequência, jitter, p95, delta, PPS e bitrate quando `frame.len` está disponível.
- REGISTER e OPTIONS são contabilizados como tráfego SIP de controle/health-check, mas não entram no número de tentativas de chamada.
- Distribuição de códigos SIP passa a considerar respostas observadas, incluindo desafios 401/407, sem confundi-los com falhas finais de chamada.
- Gráficos adicionais: métodos SIP, ladder SIP por chamada e linha do tempo RTP por chamada.
- Relatórios PDF e DOCX incorporam as novas evidências.

## Instalação
```bash
cd /home/bbarreto
unzip VoIP_Capture_Analyzer_V2_8_1.zip
cd voip_capture_analyzer_v2_9
python3.11 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
tshark --version
IP=$(hostname -I | awk '{print $1}')
uvicorn app.main:app --host "$IP" --port 8000
```

## Teste rápido
```bash
curl -s http://127.0.0.1:8000/api/health
```

## Evidência de RTP
Quando a captura possui SDP com, por exemplo, `m=audio 10000 ...`, a V2.9 pode executar Decode-As equivalente a:
```text
udp.port==10000 -> RTP
udp.port==10001 -> RTCP
```
O conjunto de portas é obtido automaticamente do SDP; os valores acima são apenas um exemplo.

## Observação sobre REGISTER/OPTIONS
Esses pacotes são relevantes para a saúde da sinalização e aparecem nas estatísticas SIP, mas não representam chamadas. O relatório os separa para evitar inflar ASR, PDD e contagem de chamadas.

## Validação
A suíte local da V2.9.1 foi executada com:
```text
2 passed
```
