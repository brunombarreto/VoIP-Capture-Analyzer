import asyncio
import csv
import io
import json

_FIELD_CACHE: set[str] | None = None
from pathlib import Path
from typing import Iterable
from app.config import TSHARK_BIN, ANALYSIS_TIMEOUT_SECONDS

class TSharkError(RuntimeError):
    pass

async def run_tshark(args: list[str], timeout: int = ANALYSIS_TIMEOUT_SECONDS) -> tuple[str, str]:
    try:
        proc = await asyncio.create_subprocess_exec(
            TSHARK_BIN, *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except FileNotFoundError as exc:
        raise TSharkError(f"TShark não encontrado: {TSHARK_BIN}") from exc
    try:
        out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError as exc:
        proc.kill()
        await proc.wait()
        raise TSharkError(f"TShark excedeu o tempo limite de {timeout}s") from exc
    stdout = out.decode(errors="replace")
    stderr = err.decode(errors="replace")
    if proc.returncode != 0:
        raise TSharkError(stderr[-8000:] or f"TShark retornou código {proc.returncode}")
    return stdout, stderr

async def check_tshark() -> str:
    out, _ = await run_tshark(["--version"], timeout=20)
    return out.splitlines()[0] if out else "unknown"


async def available_fields() -> set[str]:
    global _FIELD_CACHE
    if _FIELD_CACHE is not None:
        return _FIELD_CACHE
    out, _ = await run_tshark(["-G", "fields"], timeout=60)
    fields = set()
    for line in out.splitlines():
        parts = line.split("\t")
        if len(parts) >= 2 and parts[0] == "F":
            fields.add(parts[1])
    _FIELD_CACHE = fields
    return fields

async def fields(capture: Path, display_filter: str, field_list: Iterable[str], occurrence: str = "f") -> list[dict[str, str]]:
    available = await available_fields()
    selected = [field for field in field_list if field in available]
    if not selected:
        return []
    args = [
        "-n", "-r", str(capture), "-Y", display_filter,
        "-T", "fields", "-E", "header=y", "-E", "separator=\\t",
        "-E", "quote=d", "-E", f"occurrence={occurrence}", "-E", "aggregator=;",
    ]
    for field in selected:
        args += ["-e", field]
    out, _ = await run_tshark(args)
    if not out.strip():
        return []
    reader = csv.DictReader(io.StringIO(out), delimiter="\t", quotechar='"')
    return [dict(row) for row in reader]

async def raw_udp_payloads(capture: Path, port_filter: str = "udp.port==5060") -> list[dict]:
    """Return UDP payloads as hex using TShark, independent of PCAP/PCAPNG link type.

    TShark is deliberately kept responsible for link-layer/IP decoding.  This is
    important for captures that Wireshark can read but a small Python PCAP parser
    cannot (pcapng, SLL2, VLAN, cooked captures, etc.).
    """
    out, _ = await run_tshark([
        "-n", "-r", str(capture), "-Y", port_filter, "-T", "fields",
        "-E", "header=y", "-E", "separator=\t", "-E", "quote=d",
        "-e", "frame.number", "-e", "frame.time_epoch",
        "-e", "ip.src", "-e", "ip.dst", "-e", "ipv6.src", "-e", "ipv6.dst",
        "-e", "udp.srcport", "-e", "udp.dstport", "-e", "udp.payload",
    ], timeout=600)
    if not out.strip():
        return []
    reader = csv.DictReader(io.StringIO(out), delimiter="\t", quotechar='"')
    return [dict(row) for row in reader if row.get("udp.payload")]

async def capture_info(capture: Path) -> dict:
    out, _ = await run_tshark([
        "-n", "-r", str(capture), "-T", "fields",
        "-e", "frame.number", "-e", "frame.time_epoch", "-e", "frame.len",
    ], timeout=300)
    first_ts = last_ts = None
    packets = bytes_total = 0
    for line in out.splitlines():
        parts = line.split("\t")
        if len(parts) < 2:
            continue
        try:
            ts = float(parts[1])
        except (TypeError, ValueError):
            continue
        try:
            size = int(parts[2]) if len(parts) > 2 and parts[2] else 0
        except (TypeError, ValueError):
            size = 0
        first_ts = ts if first_ts is None else first_ts
        last_ts = ts
        packets += 1
        bytes_total += size
    duration = max((last_ts - first_ts) if first_ts is not None and last_ts is not None else 0.0, 0.0)
    return {
        "packets": packets,
        "bytes": bytes_total,
        "first_ts": first_ts,
        "last_ts": last_ts,
        "duration": duration,
    }


async def json_packets(capture: Path, display_filter: str) -> list[dict]:
    """Decode packets through TShark JSON as a compatibility fallback."""
    out, _ = await run_tshark(["-n", "-r", str(capture), "-Y", display_filter, "-T", "json"], timeout=600)
    try:
        payload = json.loads(out)
    except json.JSONDecodeError as exc:
        raise TSharkError(f"Falha ao interpretar JSON do TShark: {exc}") from exc
    result = []
    for packet in payload if isinstance(payload, list) else []:
        layers = ((packet.get("_source") or {}).get("layers") or {}) if isinstance(packet, dict) else {}
        flat = {}
        def walk(obj):
            if isinstance(obj, dict):
                for key, value in obj.items():
                    if key.startswith(("frame.", "ip.", "ipv6.", "udp.", "tcp.", "sip.", "sdp.", "rtp.", "rtcp.")):
                        if isinstance(value, list):
                            flat[key] = ";".join(str(v) for v in value)
                        elif isinstance(value, (str, int, float)):
                            flat[key] = str(value)
                    if isinstance(value, (dict, list)):
                        walk(value)
            elif isinstance(obj, list):
                for item in obj:
                    walk(item)
        walk(layers)
        if flat:
            result.append(flat)
    return result


async def protocol_inventory(capture: Path) -> dict:
    """Inventory protocols actually decoded by TShark, independent of SIP/RTP correlation."""
    out, _ = await run_tshark([
        "-n", "-r", str(capture), "-T", "fields",
        "-E", "header=n", "-E", "separator=|",
        "-e", "frame.number", "-e", "frame.time_epoch", "-e", "frame.protocols",
    ], timeout=300)
    counts = {"sip": 0, "sdp": 0, "rtp": 0, "rtcp": 0, "udp": 0, "tcp": 0}
    protocol_rows = []
    for line in out.splitlines():
        parts = line.split("|", 2)
        if len(parts) < 3:
            continue
        protocols = parts[2].lower().split(":")
        for proto in counts:
            if proto in protocols:
                counts[proto] += 1
        protocol_rows.append({"frame": parts[0], "ts": parts[1], "protocols": protocols})
    return {"counts": counts, "decoded_packets": len(protocol_rows)}
