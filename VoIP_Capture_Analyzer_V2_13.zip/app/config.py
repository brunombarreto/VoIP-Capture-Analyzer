# Copyright (c) 2026 Bruno Barreto
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = DATA_DIR / "uploads"
REPORT_DIR = DATA_DIR / "reports"
CHART_DIR = DATA_DIR / "charts"
for path in (UPLOAD_DIR, REPORT_DIR, CHART_DIR):
    path.mkdir(parents=True, exist_ok=True)

TSHARK_BIN = os.getenv("TSHARK_BIN", "tshark")
VERSION = "2.13.0"
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "500"))
ANALYSIS_TIMEOUT_SECONDS = int(os.getenv("ANALYSIS_TIMEOUT_SECONDS", "1800"))
