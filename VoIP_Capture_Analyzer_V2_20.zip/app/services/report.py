# Copyright (c) 2026 Bruno Barreto
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

from datetime import datetime
from io import BytesIO
import base64
from pathlib import Path
from jinja2 import Environment, FileSystemLoader, select_autoescape
from docx import Document
from docx.shared import Inches, Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from weasyprint import HTML
from app.config import REPORT_DIR, VERSION, VERSION_DISPLAY

TEMPLATE_DIR = Path(__file__).resolve().parent.parent / "templates"

GLOSSARY = [
    ("SIP", "Session Initiation Protocol; protocolo de sinalização usado para iniciar, modificar e encerrar sessões VoIP."),
    ("SDP", "Session Description Protocol; descrição da sessão negociada no SIP, incluindo codec, endereço IP, portas e direção da mídia."),
    ("RTP", "Real-time Transport Protocol; protocolo usado para transportar mídia em tempo real, como áudio."),
    ("RTCP", "RTP Control Protocol; protocolo complementar ao RTP, usado para relatórios de controle e métricas de qualidade."),
    ("ASR", "Answer-Seizure Ratio; proporção de tentativas de chamada que chegam a atendimento (200 OK do INVITE), conforme a definição operacional do Analyzer."),
    ("PDD", "Post Dial Delay; tempo entre o início efetivo da tentativa e um marco de progresso/atendimento. O Analyzer também separa PDD até 100 Trying, 180/183 e 200 OK."),
    ("Jitter", "Variação do tempo de chegada dos pacotes RTP em relação ao ritmo indicado pelos timestamps RTP; no Analyzer, é calculado por interarrival quando o clock rate é conhecido."),
    ("p95", "Percentil 95; valor abaixo do qual estão aproximadamente 95% das observações. Ajuda a representar a cauda da distribuição sem depender apenas da média."),
    ("RTT", "Round-Trip Time; tempo decorrido entre uma mensagem/requisição e sua resposta correspondente. No Analyzer pode ser calculado para transações SIP e, quando disponível, reportado por RTCP."),
    ("Bitrate", "Taxa de bits por unidade de tempo. No perfil RTP do Analyzer, representa o bitrate observado a partir dos bytes dos frames capturados e do intervalo observado."),
    ("PPS", "Packets Per Second; quantidade média de pacotes por segundo."),
    ("KPI", "Key Performance Indicator; indicador-chave de desempenho usado para resumir o estado ou comportamento da análise."),
    ("Codec", "Algoritmo/formato utilizado para codificar e decodificar áudio, como G.711, G.729 ou Opus."),
    ("B2BUA", "Back-to-Back User Agent; elemento que mantém duas ou mais pernas SIP relacionadas a uma mesma chamada lógica."),
    ("SBC", "Session Border Controller; elemento que controla, intermedeia e protege sessões VoIP entre domínios de comunicação."),
    ("PBX", "Private Branch Exchange; central telefônica privada responsável por funções de telefonia e encaminhamento."),
    ("Firewall", "Controle de segurança que permite ou bloqueia tráfego conforme regras configuradas."),
    ("QoS", "Quality of Service; mecanismos e políticas para classificação, priorização e tratamento de tráfego de rede."),
    ("DSCP", "Differentiated Services Code Point; campo usado para marcar a classe/prioridade de serviço em pacotes IP."),
    ("SSRC", "Synchronization Source; identificador de uma fonte de sincronização RTP."),
    ("Payload Type", "Identificador RTP associado ao formato/tipo de carga transportada pelo pacote."),
    ("Call-ID", "Identificador SIP usado para relacionar mensagens de uma sessão ou diálogo."),
    ("CSeq", "Command Sequence; número e método usados no SIP para ordenar transações dentro de uma sessão."),
    ("Re-INVITE", "Novo INVITE dentro de uma sessão já estabelecida, frequentemente usado para alteração de SDP ou estado da sessão."),
    ("One-way RTP", "Situação em que a captura evidencia mídia RTP em apenas um sentido."),
    ("RTP gap", "Intervalo em que não foram observados pacotes RTP de uma direção por um período relevante; pode indicar interrupção de mídia, mas depende do ponto de captura."),
    ("Media Establishment Delay", "Tempo entre o atendimento (200 OK) e o primeiro pacote RTP observado após o atendimento."),
    ("SIP Transaction RTT", "Tempo de ida e volta entre uma requisição SIP e a primeira resposta correspondente identificada pelo Analyzer."),
    ("SDP/RTP Consistency", "Verificação que compara endpoints de mídia anunciados no SDP com endpoints RTP observados na captura."),
    ("Call State", "Estado reconstruído da chamada a partir da sinalização observada, como ESTABLISHED, COMPLETED, FAILED, CANCELLED ou INCOMPLETE."),
    ("Call Anomaly Score", "Indicador próprio do Analyzer, de 0 a 100, usado para priorizar chamadas conforme anomalias detectadas; não é uma métrica definida por RFC."),
    ("RTP_UNILATERAL", "Classificação usada quando apenas uma direção RTP é observada para a chamada no ponto de captura."),
    ("RTP_BIDIRECTIONAL", "Classificação usada quando duas direções RTP são observadas na chamada."),
    ("2xx", "Classe de respostas SIP de sucesso. Por exemplo, 200 OK indica aceitação/conclusão bem-sucedida da transação correspondente."),
    ("4xx", "Classe de respostas SIP que indica erro relacionado à requisição ou ao processamento pelo servidor/endpoint."),
    ("5xx", "Classe de respostas SIP que indica falha de servidor ou de processamento no elemento SIP."),
    ("6xx", "Classe de respostas SIP que indica falha/rejeição global para o destino da requisição."),
    ("N/A", "Não disponível ou não calculável com segurança a partir dos dados presentes na captura."),
]


def add_hyperlink(paragraph, text, url):
    part = paragraph.part
    r_id = part.relate_to(url, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink", is_external=True)
    hyperlink = OxmlElement("w:hyperlink")
    hyperlink.set(qn("r:id"), r_id)
    run = OxmlElement("w:r")
    rPr = OxmlElement("w:rPr")
    color = OxmlElement("w:color"); color.set(qn("w:val"), "2563EB")
    underline = OxmlElement("w:u"); underline.set(qn("w:val"), "single")
    rPr.append(color); rPr.append(underline)
    run.append(rPr)
    text_el = OxmlElement("w:t"); text_el.text = text
    run.append(text_el); hyperlink.append(run)
    paragraph._p.append(hyperlink)
    return hyperlink

def fmt(v, suffix="", decimals=2):
    if v is None:
        return "N/A"
    if isinstance(v, float):
        return f"{v:.{decimals}f}{suffix}"
    return f"{v}{suffix}"

def build_context(data, charts, filename):
    return {
        "data": data, "charts": charts, "filename": filename,
        "generated": datetime.now().astimezone().strftime("%d/%m/%Y %H:%M:%S"), "generated_year": datetime.now().year, "fmt": fmt, "version": VERSION_DISPLAY, "glossary": GLOSSARY,
    }

def render_html(data, charts, filename):
    env = Environment(loader=FileSystemLoader(str(TEMPLATE_DIR)), autoescape=select_autoescape(["html", "xml"]))
    return env.get_template("report.html").render(**build_context(data, charts, filename))

def export_pdf(html, job_id):
    path = REPORT_DIR / f"{job_id}.pdf"
    HTML(string=html, base_url=str(TEMPLATE_DIR.parent)).write_pdf(str(path))
    return path

def _set_cell_shading(cell, fill="EEF6F8"):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = tcPr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tcPr.append(shd)
    shd.set(qn("w:fill"), fill)


def _style_heading(paragraph, level):
    color = "0F3D56" if level == 1 else "164E63"
    for run in paragraph.runs:
        run.font.name = "Arial"
        run.font.color.rgb = __import__("docx").shared.RGBColor.from_string(color)


def _add_chart(doc, charts, name, title=None):
    if name not in charts:
        return
    if title:
        h = doc.add_heading(title, 2)
        _style_heading(h, 2)
    raw = base64.b64decode(charts[name].split(",", 1)[1])
    doc.add_picture(BytesIO(raw), width=Inches(6.65))


def export_docx(data, charts, filename, job_id):
    """Export a DOCX whose structure/content follows the PDF/HTML report."""
    path = REPORT_DIR / f"{job_id}.docx"
    doc = Document()
    sec = doc.sections[0]
    sec.top_margin = Inches(.55); sec.bottom_margin = Inches(.55)
    sec.left_margin = Inches(.65); sec.right_margin = Inches(.65)
    styles = doc.styles
    styles["Normal"].font.name = "Arial"; styles["Normal"].font.size = Pt(9.5)
    styles["Title"].font.name = "Arial"; styles["Title"].font.size = Pt(25)
    styles["Heading 1"].font.name = "Arial"; styles["Heading 1"].font.size = Pt(17)
    styles["Heading 2"].font.name = "Arial"; styles["Heading 2"].font.size = Pt(12)

    footer = sec.footer.paragraphs[0]
    footer.alignment = 1
    mark_path = TEMPLATE_DIR.parent / "static" / "voip-capture-analyzer-mark.png"
    if mark_path.exists():
        footer.add_run().add_picture(str(mark_path), width=Inches(.18))
    add_hyperlink(footer, f" VoIP Capture Analyzer V{VERSION_DISPLAY}", "/download/source")
    r = footer.add_run(" · Copyright (c) ")
    r.font.size = Pt(8)
    r = footer.add_run(f"{datetime.now().year} · ")
    r.font.size = Pt(8)
    add_hyperlink(footer, "Bruno Barreto", "https://linktr.ee/brunombarreto")

    logo_path = TEMPLATE_DIR.parent / "static" / "voip-capture-analyzer-logo.png"
    if logo_path.exists():
        p_logo = doc.add_paragraph(); p_logo.alignment = 0
        p_logo.add_run().add_picture(str(logo_path), width=Inches(5.8))
    title = doc.add_heading("VoIP Capture Analyzer", 0)
    doc.add_paragraph("Relatório Técnico Profissional de Análise SIP / SDP / RTP / RTCP")
    doc.add_paragraph(f"Versão: V{VERSION_DISPLAY}")
    doc.add_paragraph(f"Captura: {filename}")
    doc.add_paragraph(f"Gerado: {datetime.now().astimezone():%d/%m/%Y %H:%M:%S}")
    doc.add_paragraph(f"Saúde geral: {data['macro'].get('health','N/A')}")
    if data["macro"].get("health_reason"):
        doc.add_paragraph(f"Observação: {data['macro']['health_reason']}")

    h=doc.add_heading("1. Resumo Executivo",1); _style_heading(h,1)
    doc.add_paragraph("A análise reconstrói a sinalização SIP, negociação SDP e mídia RTP/RTCP observadas no ponto de captura. O relatório distingue evidências observadas, métricas calculadas e inferências diagnósticas. Indicadores que não podem ser obtidos com segurança são apresentados como N/A.")
    t=doc.add_table(rows=1, cols=4); t.style="Table Grid"
    for i,hdr in enumerate(["KPI","Valor"]):
        t.rows[0].cells[i].text=hdr; _set_cell_shading(t.rows[0].cells[i])
    kpis=[
        ("Saúde", data['macro'].get('health','N/A'), "Chamadas", fmt(data['macro'].get('calls'))),
        ("ASR", fmt(data['macro'].get('asr_pct'), "%"), "PDD médio", fmt(data['macro'].get('pdd_avg_s'), " s")),
        ("Jitter p95", fmt(data['macro'].get('jitter_p95_ms'), " ms"), "Perda média", fmt(data['macro'].get('loss_avg_pct'), "%")),
        ("RTP unilateral", fmt(data['macro'].get('one_way_calls')), "Pico simultâneo", fmt(data['macro'].get('concurrent_peak'))),
    ]
    # Match the dashboard's 8 executive KPIs in a compact 4-column table.
    t = doc.tables[-1]
    t.rows[0].cells[0].text="KPI"; t.rows[0].cells[1].text="Valor"; t.rows[0].cells[2].text="KPI"; t.rows[0].cells[3].text="Valor"
    for row in kpis:
        cells=t.add_row().cells
        cells[0].text=row[0]; cells[1].text=row[1]; cells[2].text=row[2]; cells[3].text=row[3]
        for cell in cells: _set_cell_shading(cell) if cell in (cells[0],cells[2]) else None

    h=doc.add_heading("2. Metodologia",1); _style_heading(h,1)
    doc.add_paragraph("Ferramenta: TShark em subprocessos assíncronos. Protocolos: SIP, SDP, RTP e RTCP quando identificados. Limiar operacional: PDD > 3s, jitter > 30ms e perda RTP > 1%. Esses valores são critérios operacionais e devem ser ajustados ao ambiente.")
    doc.add_paragraph("Limitação: métricas representam o ponto de captura. Uma captura unilateral não permite afirmar, sozinha, o comportamento do caminho remoto.")

    h=doc.add_heading("3. Análise Macro",1); _style_heading(h,1)
    cap=data["capture"]; macro=data["macro"]
    doc.add_paragraph(f"Pacotes: {cap.get('packets',0)} · Bytes: {cap.get('bytes',0)} · Duração: {fmt(cap.get('duration'),' s')} · PPS: {fmt(macro.get('pps'))} · Bitrate médio da captura: {fmt((macro.get('bps') or 0)/1000,' kbps')}")
    doc.add_paragraph(f"RTP observado por chamada: bitrate médio {fmt(macro.get('rtp_bitrate_avg_kbps'),' kbps')} · p95 {fmt(macro.get('rtp_bitrate_p95_kbps'),' kbps')} · PPS médio {fmt(macro.get('rtp_pps_avg'))} · PPS p95 {fmt(macro.get('rtp_pps_p95'))}.")
    cq=macro.get('concurrency_quality_correlation')
    if cq is not None:
        doc.add_paragraph(f"Correlação entre simultaneidade e Call Anomaly Score: {fmt(cq)}. Este valor é estatístico e não prova causalidade.")
    doc.add_paragraph(f"Interrupções RTP: {macro.get('rtp_gap_events',0)} evento(s) em {macro.get('rtp_gap_calls',0)} chamada(s) · maior intervalo: {fmt(macro.get('rtp_gap_max_s'),' s')}.")
    inv=macro.get('protocol_inventory',{})
    doc.add_paragraph(f"Inventário de protocolos: SIP {inv.get('sip_packets',0)} · SDP {inv.get('sdp_packets',0)} · RTP {inv.get('rtp_packets',0)} · RTCP {inv.get('rtcp_packets',0)} · RTP não associado {macro.get('rtp_unassociated_packets',0)}")
    doc.add_paragraph(f"Tráfego de controle: REGISTER {macro.get('register_packets',0)} · OPTIONS {macro.get('options_packets',0)}. Esses métodos não são contabilizados como tentativas de chamada.")
    doc.add_paragraph(f"SIP Transaction RTT médio: {fmt(macro.get('sip_transaction_rtt_avg_ms'),' ms')} · p95: {fmt(macro.get('sip_transaction_rtt_p95_ms'),' ms')}")
    oh=macro.get('options_health',{})
    doc.add_paragraph(f"Saúde OPTIONS: {oh.get('requests',0)} requisição(ões) · {oh.get('responses',0)} resposta(s) · sucesso 2xx: {oh.get('success',0)} · taxa: {fmt(oh.get('success_pct'),'%')} · RTT médio: {fmt(oh.get('rtt_avg_ms'),' ms')}")
    for name,title in [("response_codes","Códigos SIP observados"),("sip_methods","Métodos SIP"),("pdd","PDD"),("loss_jitter","Perda × Jitter"),("jitter_calls","Jitter por chamada"),("loss_calls","Perda por chamada"),("codecs","Codecs"),("concurrency","Chamadas simultâneas"),("quality_matrix","Matriz de qualidade"),("anomaly_score","Call Anomaly Score"),("sip_timing","Tempos SIP"),("sip_transaction_rtt","SIP Transaction RTT"),("media_establishment","Media Establishment Delay"),("sdp_consistency","Consistência SDP × RTP"),("options_health","Saúde SIP OPTIONS"),("rtp_bandwidth","Perfil de banda RTP por chamada"),("concurrency_quality","Chamadas simultâneas × qualidade")]:
        _add_chart(doc,charts,name,title)

    h=doc.add_heading("4. Diagnóstico Consolidado",1); _style_heading(h,1)
    doc.add_paragraph(f"Chamadas com anomalias: {macro.get('degraded_calls',0)} · Chamadas críticas: {macro.get('critical_calls',0)} · Pico de simultaneidade: {macro.get('concurrent_peak',0)}.")
    for idx in range(1,7):
        for name,title in ((f"call_flow_{idx}",f"Fluxo SIP — chamada {idx}"),(f"rtp_timeline_{idx}",f"Linha do tempo RTP — chamada {idx}"),(f"sip_rtp_timeline_{idx}",f"Linha do tempo correlacionada SIP + RTP — chamada {idx}")):
            _add_chart(doc,charts,name,title)

    h=doc.add_heading("5. Análise Micro",1); _style_heading(h,1)
    for index,call in enumerate(data["calls"],1):
        h=doc.add_heading(f"5.{index} — Chamada correlacionada",2); _style_heading(h,2)
        m=call["metrics"]; r=m["rtp"]; corr=call.get("correlation",{})
        doc.add_paragraph(f"Call-ID: {call.get('call_id','N/A')}")
        doc.add_paragraph(f"From: {call.get('from') or 'N/A'} · To: {call.get('to') or 'N/A'} · Status: {m.get('final_status') or 'N/A'}")
        doc.add_paragraph(f"Estado: {m.get('call_state','N/A')} · Score: {m.get('anomaly_score','N/A')} · Classificação: {m.get('anomaly_classification','N/A')}")
        doc.add_paragraph(f"Correlação: {corr.get('type','single-leg')} · Pernas: {corr.get('leg_count',1)} · Call-IDs: {', '.join(call.get('leg_call_ids',[call.get('call_id','N/A')]))}")
        if corr.get("evidence"): doc.add_paragraph("Evidências da correlação: " + "; ".join(corr["evidence"]))
        t=doc.add_table(rows=1,cols=4); t.style="Table Grid"
        for i,hdr in enumerate(["Indicador","Valor","Indicador","Valor"]): t.rows[0].cells[i].text=hdr; _set_cell_shading(t.rows[0].cells[i])
        pairs=[("Duração",fmt(m.get('duration'),' s'),"Conversação",fmt(m.get('conversation_duration'),' s')),("PDD",fmt(m.get('pdd_to_answer'),' s'),"Re-INVITE",str(m.get('re_invites',0))),("RTP",f"{r.get('packets',0)} pacotes / {r.get('streams',0)} streams","Perda",fmt(r.get('loss_pct'),'%')),("Jitter",fmt(r.get('jitter_ms'),' ms'),"Jitter p95",fmt(r.get('jitter_p95_ms'),' ms')),("Gaps RTP",str(m.get('rtp_gap_count',0)),"Maior gap",fmt(m.get('rtp_gap_max_s'),' s')),("SIP RTT médio",fmt(m.get('sip_transaction_rtt_avg_ms'),' ms'),"SIP RTT p95",fmt(m.get('sip_transaction_rtt_p95_ms'),' ms')),("Media start",fmt(r.get('media_start_delay_s'),' s'),"One-way",r.get('one_way_classification','N/A'))]
        for row in pairs:
            cells=t.add_row().cells
            for i,v in enumerate(row): cells[i].text=v
        if m.get("sdp_consistency"):
            doc.add_paragraph(f"SDP/RTP consistency: {m['sdp_consistency'].get('status','N/A')} · Declarados: {m['sdp_consistency'].get('declared',[])} · Observados: {m['sdp_consistency'].get('observed',[])}")
        if m.get("rtcp",{}).get("packets"):
            rt=m["rtcp"]; doc.add_paragraph(f"RTCP: {rt.get('packets',0)} pacotes · fraction lost médio: {fmt(rt.get('fraction_lost_avg'))} · jitter reportado: {fmt(rt.get('jitter_avg'))} · RTT reportado: {fmt(rt.get('rtt_avg'))}")
        if r.get("directions"):
            doc.add_paragraph("Direções RTP observadas")
            dt=doc.add_table(rows=1,cols=5); dt.style="Table Grid"
            for i,hdr in enumerate(["Origem","Destino","Pacotes","Duração","Payload"]): dt.rows[0].cells[i].text=hdr; _set_cell_shading(dt.rows[0].cells[i])
            for d in r["directions"]:
                cells=dt.add_row().cells; vals=[f"{d.get('src','')}:{d.get('src_port','')}",f"{d.get('dst','')}:{d.get('dst_port','')}",str(d.get('packets',0)),fmt(d.get('duration_s'),' s'),", ".join(d.get('payload_types',[]))]
                for i,v in enumerate(vals): cells[i].text=v
        if call.get("timeline"):
            doc.add_paragraph("Linha do tempo correlacionada SIP + RTP")
            tt=doc.add_table(rows=1,cols=3); tt.style="Table Grid"
            for i,hdr in enumerate(["Tempo","Evento","Detalhe"]): tt.rows[0].cells[i].text=hdr; _set_cell_shading(tt.rows[0].cells[i])
            for e in call["timeline"][:40]:
                cells=tt.add_row().cells; cells[0].text=fmt(e.get('offset_s'),' s'); cells[1].text=str(e.get('type','')); cells[2].text=str(e.get('label',''))
        if call.get("anomalies"):
            h=doc.add_heading("Achados",3); _style_heading(h,2)
            for a in call["anomalies"]:
                doc.add_paragraph(f"[{a['severity'].upper()} / {a['confidence']}] {a['finding']} Impacto: {a['impact']} Recomendação: {a['recommendation']}",style="List Bullet")
        else:
            doc.add_paragraph("Não foram detectadas anomalias segundo as regras implementadas.")

    h=doc.add_heading("6. Recomendações",1); _style_heading(h,1)
    doc.add_paragraph("Priorizar chamadas com perda RTP, RTP unilateral, ausência de mídia após atendimento, retransmissões SIP, RTT de transações elevado e PDD elevado. Correlacionar timestamps com interfaces de rede, SBC/PBX, firewall, QoS/DSCP e utilização de enlaces antes de afirmar causa raiz definitiva.")
    h=doc.add_heading("7. Limitações e Reprodutibilidade",1); _style_heading(h,1)
    doc.add_paragraph("A perda RTP é estimada por gaps de sequência. Jitter é calculado pelo algoritmo de interarrival quando o clock rate é inferível; sem timestamp/clock suficiente, a métrica é N/A. MOS/NER não são inventados. RTP não associado de forma confiável a um Call-ID é tratado conservadoramente. A disponibilidade dos campos depende da versão do TShark.")
    h=doc.add_heading("8. Glossário",1); _style_heading(h,1)
    gt=doc.add_table(rows=1,cols=2); gt.style="Table Grid"; gt.rows[0].cells[0].text="Termo"; gt.rows[0].cells[1].text="Explicação"; _set_cell_shading(gt.rows[0].cells[0]); _set_cell_shading(gt.rows[0].cells[1])
    for term,definition in GLOSSARY:
        cells=gt.add_row().cells; cells[0].text=term; cells[1].text=definition
    doc.add_paragraph("O rodapé de cada página identifica a versão, o acesso ao download da suíte e a autoria do Analyzer. A Licença MIT permanece disponível no menu Ajuda da aplicação.")
    doc.save(path)
    return path
