# Copyright (c) 2026 Bruno Barreto
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

import base64
import io
from collections import Counter
import hashlib
import textwrap
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def img_data(fig):
    buf = io.BytesIO()
    fig.tight_layout()
    fig.savefig(buf, format="png", dpi=150, bbox_inches="tight")
    plt.close(fig)
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def empty(ax, message="Sem dados suficientes"):
    ax.text(0.5, 0.5, message, ha="center", va="center", transform=ax.transAxes)


def endpoint_label(ip, port=None):
    """Format an IP/port pair for technical charts without horizontal overlap."""
    address = str(ip or "?")
    port_text = str(port or "")
    # Keep the complete address, but put the port on a separate line.
    return f"{address}\n:{port_text}" if port_text else address


def _color_for_key(key, cmap="tab20"):
    """Return a deterministic matplotlib color for a call/event key."""
    digest = hashlib.md5(str(key).encode("utf-8")).hexdigest()
    idx = int(digest[:8], 16) % 20
    return plt.get_cmap(cmap)(idx)


def _legend_below(ax, handles, labels, columns=2, fontsize=7):
    if not handles:
        return
    ax.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.5, -0.20),
              ncol=max(1, min(columns, len(handles))), fontsize=fontsize,
              frameon=False, title="Legenda", title_fontsize=8)


def make_charts(data, job_id=None):
    macro = data["macro"]
    calls = data["calls"]
    charts = {}

    codes = macro.get("all_response_codes") or macro.get("response_codes", {})
    fig, ax = plt.subplots(figsize=(7, 4))
    if codes:
        ax.bar(list(codes.keys()), list(codes.values()))
    else:
        empty(ax)
    ax.set_title("Distribuição de códigos de resposta SIP")
    ax.set_xlabel("Código")
    ax.set_ylabel("Chamadas")
    charts["response_codes"] = img_data(fig)

    methods = macro.get("sip_methods", {})
    fig, ax = plt.subplots(figsize=(8, 4))
    if methods:
        keys = list(methods.keys())
        ax.bar(keys, [methods[k] for k in keys]); ax.tick_params(axis="x", rotation=35)
    else:
        empty(ax)
    ax.set_title("Métodos SIP observados")
    ax.set_xlabel("Método")
    ax.set_ylabel("Pacotes")
    charts["sip_methods"] = img_data(fig)

    pdds = [c["metrics"].get("pdd_to_answer") for c in calls if c["metrics"].get("pdd_to_answer") is not None]
    fig, ax = plt.subplots(figsize=(7, 4))
    if pdds:
        ax.hist(pdds, bins=min(12, max(4, len(pdds))))
    else:
        empty(ax)
    ax.set_title("Distribuição de PDD até atendimento")
    ax.set_xlabel("Segundos")
    ax.set_ylabel("Chamadas")
    charts["pdd"] = img_data(fig)

    loss_points = []
    for c in calls:
        loss = c["metrics"]["rtp"].get("loss_pct")
        jitter = c["metrics"]["rtp"].get("jitter_ms")
        if loss is not None and jitter is not None:
            loss_points.append((loss, jitter, str(c.get("call_id") or "N/A")))
    fig, ax = plt.subplots(figsize=(9, 5.5))
    if loss_points:
        handles = []
        labels_legend = []
        for x, y, call_id in loss_points:
            color = _color_for_key(call_id)
            point = ax.scatter([x], [y], alpha=0.85, s=55, color=color, label=call_id)
            handles.append(point); labels_legend.append(call_id)
        _legend_below(ax, handles, labels_legend, columns=2, fontsize=6.5)
    else:
        empty(ax)
    ax.set_title("Perda RTP × Jitter")
    ax.set_xlabel("Perda estimada (%)")
    ax.set_ylabel("Jitter RTP (ms)")
    charts["loss_jitter"] = img_data(fig)

    # Per-call quality bars use short visual labels while keeping full Call-IDs in a legend.
    jitter_points = [(c["metrics"]["rtp"].get("jitter_ms"), str(c.get("call_id") or "N/A")) for c in calls if c["metrics"]["rtp"].get("jitter_ms") is not None]
    fig, ax = plt.subplots(figsize=(9, 5.8))
    if jitter_points:
        handles=[]
        for idx,(value,cid) in enumerate(jitter_points,1):
            h=ax.bar([idx], [value], color=_color_for_key(cid), width=.72)
            handles.append(h[0])
        ax.set_xticks(range(1,len(jitter_points)+1)); ax.set_xticklabels([str(i) for i in range(1,len(jitter_points)+1)])
        _legend_below(ax, handles, [cid for _,cid in jitter_points], columns=2, fontsize=6.5)
    else:
        empty(ax)
    ax.set_title("Jitter por chamada")
    ax.set_xlabel("Chamada (consulte a legenda pelo Call-ID)")
    ax.set_ylabel("ms")
    charts["jitter_calls"] = img_data(fig)

    loss_points = [(c["metrics"]["rtp"].get("loss_pct"), str(c.get("call_id") or "N/A")) for c in calls if c["metrics"]["rtp"].get("loss_pct") is not None]
    fig, ax = plt.subplots(figsize=(9, 5.8))
    if loss_points:
        handles=[]
        for idx,(value,cid) in enumerate(loss_points,1):
            h=ax.bar([idx], [value], color=_color_for_key(cid), width=.72)
            handles.append(h[0])
        ax.set_xticks(range(1,len(loss_points)+1)); ax.set_xticklabels([str(i) for i in range(1,len(loss_points)+1)])
        _legend_below(ax, handles, [cid for _,cid in loss_points], columns=2, fontsize=6.5)
    else:
        empty(ax)
    ax.set_title("Perda RTP por chamada")
    ax.set_xlabel("Chamada (consulte a legenda pelo Call-ID)")
    ax.set_ylabel("% estimado")
    charts["loss_calls"] = img_data(fig)

    # Application-specific anomaly score distribution.
    score_points=[(str(c.get("call_id") or "N/A"), c["metrics"].get("anomaly_score")) for c in calls if c["metrics"].get("anomaly_score") is not None]
    fig, ax = plt.subplots(figsize=(9, 5.8))
    if score_points:
        handles=[]
        for idx,(cid,score) in enumerate(score_points,1):
            h=ax.bar([idx], [score], color=_color_for_key(cid), width=.72)
            handles.append(h[0])
        ax.axhline(90, linestyle="--", linewidth=.8); ax.axhline(75, linestyle="--", linewidth=.8); ax.axhline(50, linestyle="--", linewidth=.8)
        ax.set_xticks(range(1,len(score_points)+1)); ax.set_xticklabels([str(i) for i in range(1,len(score_points)+1)])
        _legend_below(ax, handles, [cid for cid,_ in score_points], columns=2, fontsize=6.5)
    else:
        empty(ax)
    ax.set_ylim(0,100); ax.set_title("Call Anomaly Score")
    ax.set_xlabel("Chamada (consulte a legenda pelo Call-ID)")
    ax.set_ylabel("Score (0–100)")
    charts["anomaly_score"] = img_data(fig)

    codecs = macro.get("codecs", {})
    fig, ax = plt.subplots(figsize=(7, 4))
    if codecs:
        keys = list(codecs)[:15]
        ax.bar(keys, [codecs[k] for k in keys]); ax.tick_params(axis="x", rotation=45)
    else:
        empty(ax)
    ax.set_title("Distribuição de codecs / payloads SDP")
    ax.set_ylabel("Ocorrências")
    charts["codecs"] = img_data(fig)

    # Temporal concurrency profile.
    events = []
    for c in calls:
        if c.get("start") is not None:
            events.append((c["start"], 1))
        if c.get("end") is not None:
            events.append((c["end"], -1))
    fig, ax = plt.subplots(figsize=(9, 4))
    if events:
        events.sort(key=lambda x: (x[0], -x[1]))
        active = 0; xs = []; ys = []
        for ts, delta in events:
            active += delta; xs.append(ts - events[0][0]); ys.append(active)
        ax.step(xs, ys, where="post")
    else:
        empty(ax)
    ax.set_title("Chamadas simultâneas ao longo da captura")
    ax.set_xlabel("Tempo desde o início (s)")
    ax.set_ylabel("Chamadas simultâneas")
    charts["concurrency"] = img_data(fig)

    # Descriptive correlation between simultaneous calls and the Analyzer's own
    # per-call quality score. The engine supplies the midpoint concurrency value.
    cq = macro.get("concurrency_quality_profile") or []
    fig, ax = plt.subplots(figsize=(9, 5.5))
    if cq:
        handles=[]; labels=[]
        for point in cq:
            cid = str(point.get("call_id") or "N/A")
            h=ax.scatter([point.get("concurrent", 0)], [point.get("score", 0)], s=70, color=_color_for_key(cid), alpha=.9, edgecolors="black", linewidths=.35)
            handles.append(h); labels.append(cid)
        _legend_below(ax, handles, labels, columns=2, fontsize=6.5)
    else:
        empty(ax)
    corr=macro.get("concurrency_quality_correlation")
    title="Chamadas simultâneas × qualidade"
    if corr is not None:
        title += f" (correlação r={corr:.2f})"
    ax.set_title(title)
    ax.set_xlabel("Chamadas simultâneas no ponto médio da chamada")
    ax.set_ylabel("Call Anomaly Score (0–100)")
    ax.set_ylim(0,105)
    ax.grid(True, linestyle=":", linewidth=.5)
    charts["concurrency_quality"] = img_data(fig)

    # Quality matrix: each call has a deterministic color and the full Call-ID
    # is moved to a legend below the plot so it remains readable.
    fig, ax = plt.subplots(figsize=(9, 6.2))
    points = []
    for c in calls:
        x = c["metrics"]["rtp"].get("loss_pct")
        y = c["metrics"]["rtp"].get("jitter_ms")
        if x is not None and y is not None:
            points.append((x, y, str(c.get("call_id") or "N/A")))
    if points:
        handles = []
        legend_labels = []
        for x, y, call_id in points:
            color = _color_for_key(call_id)
            h = ax.scatter([x], [y], s=65, alpha=.88, color=color, edgecolors="black", linewidths=.35)
            handles.append(h); legend_labels.append(call_id)
        ax.axvline(1, linestyle="--", linewidth=.8); ax.axvline(3, linestyle="--", linewidth=.8)
        ax.axhline(20, linestyle="--", linewidth=.8); ax.axhline(30, linestyle="--", linewidth=.8)
        _legend_below(ax, handles, legend_labels, columns=2, fontsize=6.5)
    else:
        empty(ax)
    ax.set_title("Matriz de qualidade: perda × jitter")
    ax.set_xlabel("Perda RTP (%)")
    ax.set_ylabel("Jitter RTP (ms)")
    charts["quality_matrix"] = img_data(fig)

    # SIP timing summary.
    vals=[]; labels=[]
    for c in calls:
        for key, label in (("pdd_to_trying","100 Trying"),("pdd_to_progress","180/183"),("pdd_to_answer","200 OK")):
            v=c["metrics"].get(key)
            if v is not None:
                vals.append(v); labels.append(label)
    fig, ax = plt.subplots(figsize=(8,4))
    if vals:
        ax.boxplot(vals)
        ax.set_xticklabels(["SIP timing"])
    else:
        empty(ax)
    ax.set_title("Distribuição dos tempos de estabelecimento SIP")
    ax.set_ylabel("Segundos")
    charts["sip_timing"] = img_data(fig)

    # SIP ladder diagrams for the first six calls. This is deliberately compact
    # so it remains readable in PDF/DOCX as well as in the web dashboard.
    for idx, call in enumerate(calls[:6], 1):
        msgs = call.get("messages", [])[:18]
        nodes = []
        for m in msgs:
            for n in (m.get("src") or "?", m.get("dst") or "?"):
                if n not in nodes:
                    nodes.append(n)
        if len(nodes) < 2 or not msgs:
            continue
        node_width = max(11, 2.2 * len(nodes))
        fig, ax = plt.subplots(figsize=(node_width, max(5.5, len(msgs) * 0.50)))
        positions = {n: i for i, n in enumerate(nodes)}
        for n, x in positions.items():
            ax.plot([x, x], [0, len(msgs)+1], linestyle=":", linewidth=0.8)
            # IP and port are deliberately separated to remain readable.
            node_port = ""
            for m in msgs:
                if m.get("src") == n and m.get("src_port"):
                    node_port = m.get("src_port"); break
                if m.get("dst") == n and m.get("dst_port"):
                    node_port = m.get("dst_port"); break
            endpoint = endpoint_label(n, node_port)
            ax.text(x, len(msgs)+0.55, endpoint, ha="center", va="bottom", fontsize=8,
                    linespacing=1.15, bbox={"boxstyle": "round,pad=0.18", "alpha": 0.08})
        for row, m in enumerate(msgs, start=1):
            src, dst = m.get("src") or "?", m.get("dst") or "?"
            x1, x2 = positions[src], positions[dst]
            status = m.get("status")
            label = (str(status) if status else (m.get("method") or "SIP"))
            if m.get("cseq"):
                label += f" CSeq {m['cseq']}"
            ax.annotate("", xy=(x2, len(msgs)-row+1), xytext=(x1, len(msgs)-row+1),
                        arrowprops={"arrowstyle": "->", "linewidth": 0.9})
            ax.text((x1+x2)/2, len(msgs)-row+1+0.14, label, ha="center", fontsize=7)
        ax.set_xlim(-0.8, max(positions.values())+0.8); ax.set_ylim(0, len(msgs)+1.55)
        ax.set_title(f"Fluxo SIP — chamada {idx}", pad=18)
        ax.text(0.5, 1.015, f"Call-ID: {call.get('call_id','N/A')}", transform=ax.transAxes,
                ha="center", va="bottom", fontsize=8, family="monospace")
        ax.axis("off")
        charts[f"call_flow_{idx}"] = img_data(fig)

    # Correlated SIP + RTP timeline. Events use deterministic colors and a
    # legend below the chart, avoiding overlapping text at dense timestamps.
    for idx, call in enumerate(calls[:6], 1):
        timeline = call.get("timeline") or call.get("metrics", {}).get("timeline", [])
        if not timeline:
            continue
        base = min(float(e.get("offset_s", 0.0)) for e in timeline)
        fig, ax = plt.subplots(figsize=(13, 7))
        event_types = []
        for e in timeline:
            t = str(e.get("type", "EVENT"))
            if t not in event_types:
                event_types.append(t)
        y_by_type = {}
        for i, t in enumerate(event_types):
            y_by_type[t] = 1.0 - i * 0.28
        handles = []
        labels_legend = []
        for e in timeline:
            etype = str(e.get("type", "EVENT"))
            x = float(e.get("offset_s", 0.0)) - base
            y = y_by_type[etype]
            color = _color_for_key(etype)
            marker = "o" if etype.startswith("SIP_") else "|"
            size = 32 if marker == "o" else 100
            point = ax.scatter([x], [y], marker=marker, s=size, color=color, alpha=.9)
            label = str(e.get("label", ""))
            if etype in {"RTP_GAP_START", "RTP_GAP_END", "RTP_START_DELAY"} or etype.startswith("SIP_"):
                short = textwrap.shorten(label, width=38, placeholder="…")
                ax.annotate(short, (x, y), xytext=(0, 7 if marker == "o" else -12),
                            textcoords="offset points", fontsize=6.2, rotation=35, ha="left")
            if etype not in labels_legend:
                handles.append(point)
                labels_legend.append(etype)
        _legend_below(ax, handles, labels_legend, columns=2, fontsize=6.5)
        call_id = str(call.get("call_id") or "N/A")
        ax.set_yticks(list(y_by_type.values()))
        ax.set_yticklabels(list(y_by_type.keys()), fontsize=7)
        ax.set_xlabel("Tempo desde o início da chamada (s)")
        ax.set_title(f"Linha do tempo correlacionada SIP + RTP — chamada {idx}", pad=18)
        ax.text(0.5, 1.015, f"Call-ID: {call_id}", transform=ax.transAxes,
                ha="center", va="bottom", fontsize=8, family="monospace")
        ax.grid(axis="x", linestyle=":", linewidth=0.5)
        charts[f"sip_rtp_timeline_{idx}"] = img_data(fig)

    # Detailed RTP timeline for the most relevant calls (up to six). The data is
    # generated from packet-level evidence, not synthetic samples.
    for idx, call in enumerate(calls[:6], 1):
        timeline = call.get("metrics", {}).get("rtp", {}).get("timeline", [])
        if not timeline:
            continue
        base = timeline[0]["ts"]
        xs = [(p["ts"] - base) for p in timeline]
        ys = [p.get("delta_ms", 0) for p in timeline]
        lost = [p for p in timeline if p.get("loss", 0)]
        fig, ax = plt.subplots(figsize=(9, 4))
        ax.plot(xs, ys, linewidth=0.8)
        if lost:
            ax.scatter([(p["ts"]-base) for p in lost], [p.get("delta_ms",0) for p in lost], marker="x", s=24)
        ax.set_title(f"RTP — delta entre pacotes — chamada {idx}")
        ax.set_xlabel("Tempo desde início do RTP (s)")
        ax.set_ylabel("Delta (ms)")
        charts[f"rtp_timeline_{idx}"] = img_data(fig)

    # SIP transaction RTT by call.
    rtt_points=[]
    for c in calls:
        v=c.get("metrics",{}).get("sip_transaction_rtt_avg_ms")
        if v is not None:
            rtt_points.append((v, str(c.get("call_id") or "N/A")))
    fig, ax = plt.subplots(figsize=(9, 5.5))
    if rtt_points:
        handles=[]
        for idx,(v,cid) in enumerate(rtt_points,1):
            h=ax.bar([idx],[v],color=_color_for_key(cid),width=.72); handles.append(h[0])
        ax.set_xticks(range(1,len(rtt_points)+1)); ax.set_xticklabels([str(i) for i in range(1,len(rtt_points)+1)])
        _legend_below(ax,handles,[cid for _,cid in rtt_points],columns=2,fontsize=6.5)
    else: empty(ax)
    ax.axhline(1000,linestyle="--",linewidth=.8)
    ax.set_title("SIP Transaction RTT por chamada")
    ax.set_xlabel("Chamada (consulte a legenda pelo Call-ID)"); ax.set_ylabel("RTT médio (ms)")
    charts["sip_transaction_rtt"] = img_data(fig)

    # Media establishment delay after answer.
    media_points=[]
    for c in calls:
        v=c.get("metrics",{}).get("rtp",{}).get("media_start_delay_s")
        if v is not None:
            media_points.append((v,str(c.get("call_id") or "N/A")))
    fig, ax=plt.subplots(figsize=(9,5.2))
    if media_points:
        handles=[]
        for idx,(v,cid) in enumerate(media_points,1):
            h=ax.bar([idx],[v],color=_color_for_key(cid),width=.72); handles.append(h[0])
        ax.set_xticks(range(1,len(media_points)+1)); ax.set_xticklabels([str(i) for i in range(1,len(media_points)+1)])
        _legend_below(ax,handles,[cid for _,cid in media_points],columns=2,fontsize=6.5)
    else: empty(ax)
    ax.axhline(2,linestyle="--",linewidth=.8)
    ax.set_title("Media Establishment Delay")
    ax.set_xlabel("Chamada (consulte a legenda pelo Call-ID)"); ax.set_ylabel("Segundos após 200 OK")
    charts["media_establishment"] = img_data(fig)

    # SDP/RTP consistency status.
    statuses=Counter(str(c.get("metrics",{}).get("sdp_consistency",{}).get("status","INDETERMINATE")) for c in calls)
    fig, ax=plt.subplots(figsize=(7,4.2))
    if statuses:
        ax.bar(list(statuses.keys()),list(statuses.values()))
    else: empty(ax)
    ax.set_title("Consistência SDP × RTP"); ax.set_xlabel("Status"); ax.set_ylabel("Chamadas")
    charts["sdp_consistency"] = img_data(fig)

    # RTP bandwidth and packet-rate profile by call. This exposes observed media
    # consumption without inventing codec/network overhead; values come from
    # captured frame sizes and observed packet timing.
    bandwidth_points=[]
    for c in calls:
        r=c.get("metrics",{}).get("rtp",{})
        b=r.get("bitrate_kbps")
        pps=r.get("pps")
        if b is not None:
            bandwidth_points.append((b, pps, str(c.get("call_id") or "N/A")))
    fig, ax = plt.subplots(figsize=(10, 5.8))
    if bandwidth_points:
        handles=[]
        for idx,(b,pps,cid) in enumerate(bandwidth_points,1):
            h=ax.scatter([idx],[b],s=70,color=_color_for_key(cid),alpha=.9,edgecolors="black",linewidths=.35)
            handles.append(h)
        ax.set_xticks(range(1,len(bandwidth_points)+1))
        ax.set_xticklabels([str(i) for i in range(1,len(bandwidth_points)+1)])
        _legend_below(ax, handles, [cid for _,_,cid in bandwidth_points], columns=2, fontsize=6.5)
        for idx,(b,pps,cid) in enumerate(bandwidth_points,1):
            if pps is not None:
                ax.annotate(f"{pps:.1f} pps", (idx,b), xytext=(0,7), textcoords="offset points", ha="center", fontsize=6.5)
    else:
        empty(ax)
    ax.set_title("Perfil de banda RTP por chamada")
    ax.set_xlabel("Chamada (consulte a legenda pelo Call-ID)")
    ax.set_ylabel("Bitrate observado (kbps) · tamanho de frame")
    ax.grid(axis="y", linestyle=":", linewidth=.5)
    charts["rtp_bandwidth"] = img_data(fig)

    # OPTIONS health summary.
    oh=macro.get("options_health",{})
    fig, ax=plt.subplots(figsize=(7,4.2))
    labels=["Requisições","Respostas","Sucesso 2xx"]
    vals=[oh.get("requests",0),oh.get("responses",0),oh.get("success",0)]
    ax.bar(labels,vals)
    ax.set_title("Saúde SIP OPTIONS"); ax.set_ylabel("Quantidade")
    charts["options_health"] = img_data(fig)

    return charts
