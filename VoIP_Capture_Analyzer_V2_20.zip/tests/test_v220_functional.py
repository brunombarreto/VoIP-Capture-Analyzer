# Copyright (c) 2026 Bruno Barreto
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

from pathlib import Path
from app.analyzers.engine import CaptureAnalyzer
from app.analyzers.models import Call
from app.services.report import GLOSSARY


def test_v220_concurrency_quality_profile_and_correlation():
    c = CaptureAnalyzer()
    calls = []
    for start, end, score in [(0.0, 10.0, 95), (5.0, 15.0, 80), (6.0, 16.0, 70)]:
        call = Call(f"cid-{len(calls)+1}")
        call.metrics = {"start": start, "end": end, "anomaly_score": score}
        calls.append(call)
    points, corr = c._concurrency_quality_profile(calls)
    assert len(points) == 3
    assert corr is not None
    assert corr < 0
    assert max(p["concurrent"] for p in points) == 3


def test_v220_glossary_covers_new_interface_terms():
    terms = {term for term, _ in GLOSSARY}
    for expected in {"p95", "RTT", "Bitrate", "PPS", "KPI", "Call Anomaly Score", "Media Establishment Delay", "SIP Transaction RTT"}:
        assert expected in terms


def test_v220_report_contains_all_dashboard_kpis_and_new_chart():
    root = Path(__file__).resolve().parents[1]
    report = (root / "app" / "templates" / "report.html").read_text(encoding="utf-8")
    for expected in ["Saúde", "Chamadas", "ASR", "PDD médio", "Jitter p95", "Perda média", "RTP unilateral", "Pico simultâneo"]:
        assert expected in report
    assert "concurrency_quality" in report
